// Access code that unlocks the Admin panel.
// NOTE: this is a client-side gate. Firestore data/writes are still protected by firestore.rules.
export const ADMIN_ACCESS_CODE = 'CBLSTYW23';

export function isValidAdminCode(input: string): boolean {
  return input.trim().toUpperCase() === ADMIN_ACCESS_CODE;
}
