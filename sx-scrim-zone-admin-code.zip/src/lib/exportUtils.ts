import * as XLSX from 'xlsx';
import { jsPDF } from 'jspdf';
import { Registration, Scrim } from '../types';
import { renderTeamCardPng } from '../utils/imageProcessing';

function escapeCsvCell(value: string | number | undefined): string {
  const str = String(value ?? '');
  if (str.includes(',') || str.includes('"') || str.includes('\n')) {
    return `"${str.replace(/"/g, '""')}"`;
  }
  return str;
}

export function exportRegistrationsCsv(registrations: Registration[], filename = 'sx-scrim-teams.csv') {
  const headers = [
    'Team Name',
    'Scrim',
    'Captain IGN',
    'Captain UID',
    'WhatsApp/Phone',
    'Status',
    'Payment Method',
    'Amount',
    'Transaction ID',
    'Players & UIDs',
  ];

  const rows = registrations.map((r) => [
    r.teamName,
    r.scrimTitle || r.scrimId,
    r.captainName,
    r.captainUid,
    r.captainPhone,
    r.status,
    r.paymentMethod || '',
    r.paymentAmount ?? 0,
    r.transactionId || '',
    r.players.map((p) => `${p.ign} (${p.uid})`).join(' | '),
  ]);

  const csv = [headers.map(escapeCsvCell).join(','), ...rows.map((row) => row.map(escapeCsvCell).join(','))].join('\n');
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  triggerDownload(URL.createObjectURL(blob), filename);
}

export function exportRegistrationsExcel(registrations: Registration[], filename = 'sx-scrim-teams.xlsx') {
  const data = registrations.map((r) => ({
    TeamName: r.teamName,
    Scrim: r.scrimTitle || r.scrimId,
    CaptainIGN: r.captainName,
    CaptainUID: r.captainUid,
    WhatsApp: r.captainPhone,
    Status: r.status,
    Method: r.paymentMethod || '',
    Amount: r.paymentAmount ?? 0,
    TransactionID: r.transactionId || '',
    Roster: r.players.map((p) => `${p.ign} [${p.uid}]`).join(', '),
  }));

  const ws = XLSX.utils.json_to_sheet(data);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Registered Teams');
  XLSX.writeFile(wb, filename);
}

export function exportRegistrationsPdf(registrations: Registration[], filename = 'sx-scrim-teams.pdf') {
  const doc = new jsPDF({ orientation: 'landscape' });
  doc.setFontSize(16);
  doc.text('SX SCRIM ZONE — Registered Teams Roster', 14, 18);
  doc.setFontSize(10);
  doc.text(`Generated ${new Date().toLocaleString()} · Total Teams: ${registrations.length}`, 14, 25);

  let y = 35;
  registrations.forEach((r, idx) => {
    if (y > 185) {
      doc.addPage();
      y = 20;
    }
    const line = `${idx + 1}. ${r.teamName} [${r.status}] · Capt: ${r.captainName} (${r.captainUid}) · Txn: ${r.transactionId || 'N/A'}`;
    doc.setFontSize(10);
    doc.text(line.slice(0, 120), 14, y);
    y += 5;
    const rosterLine = `   Roster: ${r.players.map((p) => `${p.ign}:${p.uid}`).join(' | ')}`;
    doc.setFontSize(8.5);
    doc.text(rosterLine.slice(0, 140), 14, y);
    y += 7;
  });

  doc.save(filename);
}

export async function downloadAllTeamCards(registrations: Registration[], scrimsMap: Record<string, Scrim>) {
  for (const reg of registrations) {
    const pngUrl = await renderTeamCardPng(reg, scrimsMap[reg.scrimId]);
    const safeName = reg.teamName.toLowerCase().replace(/[^a-z0-9]+/g, '-');
    triggerDownload(pngUrl, `${safeName}-team-card.png`);
    await new Promise((r) => setTimeout(r, 150));
  }
}

export function triggerDownload(url: string, filename: string) {
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
}
