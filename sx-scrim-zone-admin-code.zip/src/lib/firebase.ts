import { initializeApp } from 'firebase/app';
import { browserLocalPersistence, getAuth, setPersistence } from 'firebase/auth';
import { doc, getDocFromServer, getFirestore } from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';

if (!firebaseConfig?.apiKey || !firebaseConfig?.authDomain || !firebaseConfig?.projectId || !firebaseConfig?.appId) {
  console.error(
    '[SX Auth] Firebase configuration is incomplete in firebase-applet-config.json. Check apiKey, authDomain, projectId, and appId.'
  );
}

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
export const auth = getAuth(app);

export const authPersistenceReady = setPersistence(auth, browserLocalPersistence).catch((err) => {
  console.error('[SX Auth] Failed to enforce browserLocalPersistence:', err);
});

export const BOOTSTRAPPED_ADMIN_EMAIL = 'kaflesafal13@gmail.com';

export async function testFirestoreConnection(): Promise<boolean> {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
    return true;
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.error('Firestore connection failed: the client is offline. Check firebase-applet-config.json.');
    }
    return false;
  }
}

testFirestoreConnection();
