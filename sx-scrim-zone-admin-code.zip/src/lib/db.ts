import {
  Timestamp,
  collection,
  deleteDoc,
  doc,
  getDoc,
  getDocs,
  increment,
  onSnapshot,
  orderBy,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  where,
  writeBatch,
} from 'firebase/firestore';
import {
  AIPaymentAnalysis,
  Announcement,
  AppNotification,
  FraudLayer,
  FraudLog,
  PaymentHash,
  PaymentMethod,
  Registration,
  Scrim,
  ScrimResult,
  ScrimRoom,
  ScrimRoster,
  TransactionRecord,
  UserProfile,
} from '../types';
import { db } from './firebase';
import { OperationType, handleFirestoreError } from './firestoreErrors';
import { SEED_ANNOUNCEMENTS, SEED_PAYMENT_METHODS, SEED_RESULTS, SEED_ROSTERS, SEED_SCRIMS } from '../data/seedData';
import { buildPaymentComboKey, normalizeTransactionId } from '../utils/fraud';

export function makeSafeId(prefix: string): string {
  const rand = Math.random().toString(36).slice(2, 8);
  return `${prefix}-${Date.now()}-${rand}`.replace(/[^a-zA-Z0-9_-]/g, '');
}

const inFlightProfileSync = new Map<string, Promise<UserProfile>>();

export async function ensureUserProfile(
  uid: string,
  email: string,
  displayName?: string | null,
  isAdminEmail?: boolean,
  photoURL?: string | null
): Promise<UserProfile> {
  const existingPromise = inFlightProfileSync.get(uid);
  if (existingPromise) {
    return existingPromise;
  }

  const task: Promise<UserProfile> = (async (): Promise<UserProfile> => {
    const path = `users/${uid}`;
    const ref = doc(db, 'users', uid);
    try {
      const snap = await getDoc(ref);
      if (snap.exists()) {
        await updateDoc(ref, {
          lastLogin: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
        const existingData = snap.data() as UserProfile;
        return {
          ...existingData,
          role: (isAdminEmail || existingData.role === 'admin' ? 'admin' : 'captain') as 'admin' | 'captain',
        };
      }

      const profile: UserProfile = {
        uid,
        email,
        displayName: (displayName || email.split('@')[0] || 'Captain').slice(0, 80),
        photoURL: (photoURL || '').slice(0, 500),
        inGameName: '',
        gameUid: '',
        whatsapp: '',
        role: 'captain',
        strikes: 0,
        isBanned: false,
        savedTeams: [],
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
        lastLogin: serverTimestamp(),
      };
      await setDoc(ref, profile);
      return {
        ...profile,
        role: isAdminEmail ? 'admin' : 'captain',
      };
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, path);
    }
  })().finally(() => {
    inFlightProfileSync.delete(uid);
  });

  inFlightProfileSync.set(uid, task);
  return task;
}

export async function updateUserProfileFields(
  uid: string,
  updates: Partial<Pick<UserProfile, 'displayName' | 'inGameName' | 'gameUid' | 'whatsapp' | 'savedTeams'>>
) {
  const path = `users/${uid}`;
  try {
    await updateDoc(doc(db, 'users', uid), {
      ...updates,
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function seedFirestoreIfEmpty() {
  try {
    const existingMethods = await getDocs(collection(db, 'paymentMethods'));
    if (!existingMethods.empty) return false;

    const batch = writeBatch(db);
    for (const pm of SEED_PAYMENT_METHODS) {
      batch.set(doc(db, 'paymentMethods', pm.id), {
        ...pm,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    }

    for (const ann of SEED_ANNOUNCEMENTS) {
      batch.set(doc(db, 'announcements', ann.id), {
        ...ann,
        createdBy: ann.createdBy || 'SX Tournament Ops',
        createdAt: serverTimestamp(),
      });
    }

    await batch.commit();
    return true;
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, 'paymentMethods');
  }
}

export async function fetchPublicScrimData(): Promise<{
  scrims: Scrim[];
  paymentMethods: PaymentMethod[];
  announcements: Announcement[];
  results: ScrimResult[];
  rosters: ScrimRoster[];
}> {
  const [scrimSnap, pmSnap, annSnap, resSnap, rosterSnap] = await Promise.all([
    getDocs(collection(db, 'scrims')).catch(() => null),
    getDocs(query(collection(db, 'paymentMethods'), where('enabled', '==', true))).catch(() => null),
    getDocs(collection(db, 'announcements')).catch(() => null),
    getDocs(collection(db, 'results')).catch(() => null),
    getDocs(collection(db, 'scrimRosters')).catch(() => null),
  ]);

  const scrims = scrimSnap && !scrimSnap.empty ? scrimSnap.docs.map((d) => d.data() as Scrim) : SEED_SCRIMS;
  const paymentMethods =
    pmSnap && !pmSnap.empty ? pmSnap.docs.map((d) => d.data() as PaymentMethod) : SEED_PAYMENT_METHODS;
  const announcements =
    annSnap && !annSnap.empty ? annSnap.docs.map((d) => d.data() as Announcement) : SEED_ANNOUNCEMENTS;
  const results = resSnap && !resSnap.empty ? resSnap.docs.map((d) => d.data() as ScrimResult) : SEED_RESULTS;
  const rosters = rosterSnap && !rosterSnap.empty ? rosterSnap.docs.map((d) => d.data() as ScrimRoster) : SEED_ROSTERS;

  return { scrims, paymentMethods, announcements, results, rosters };
}

export function subscribePublicCollections(callbacks: {
  onScrims: (scrims: Scrim[]) => void;
  onPaymentMethods: (methods: PaymentMethod[]) => void;
  onAnnouncements: (items: Announcement[]) => void;
  onResults: (items: ScrimResult[]) => void;
  onRosters: (items: ScrimRoster[]) => void;
}, isAdmin: boolean) {
  const unsubs: (() => void)[] = [];

  unsubs.push(
    onSnapshot(
      collection(db, 'scrims'),
      (snap) => {
        callbacks.onScrims(snap.docs.map((d) => d.data() as Scrim));
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'scrims')
    )
  );

  const pmQuery = isAdmin
    ? collection(db, 'paymentMethods')
    : query(collection(db, 'paymentMethods'), where('enabled', '==', true));
  unsubs.push(
    onSnapshot(
      pmQuery,
      (snap) => {
        if (!snap.empty || isAdmin) {
          callbacks.onPaymentMethods(snap.docs.map((d) => d.data() as PaymentMethod));
        }
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'paymentMethods')
    )
  );

  unsubs.push(
    onSnapshot(
      collection(db, 'announcements'),
      (snap) => {
        if (!snap.empty || isAdmin) {
          callbacks.onAnnouncements(snap.docs.map((d) => d.data() as Announcement));
        }
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'announcements')
    )
  );

  unsubs.push(
    onSnapshot(
      collection(db, 'results'),
      (snap) => {
        callbacks.onResults(snap.docs.map((d) => d.data() as ScrimResult));
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'results')
    )
  );

  unsubs.push(
    onSnapshot(
      collection(db, 'scrimRosters'),
      (snap) => {
        callbacks.onRosters(snap.docs.map((d) => d.data() as ScrimRoster));
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'scrimRosters')
    )
  );

  return () => unsubs.forEach((u) => u());
}

export function subscribeUserCollections(
  uid: string,
  isAdmin: boolean,
  callbacks: {
    onRegistrations: (regs: Registration[]) => void;
    onTransactions: (txns: TransactionRecord[]) => void;
    onNotifications: (notifs: AppNotification[]) => void;
    onPaymentHashes: (hashes: PaymentHash[]) => void;
    onFraudLogs: (logs: FraudLog[]) => void;
    onAllUsers?: (users: UserProfile[]) => void;
  }
) {
  const unsubs: (() => void)[] = [];

  const regRef = isAdmin
    ? collection(db, 'registrations')
    : query(collection(db, 'registrations'), where('userId', '==', uid));
  unsubs.push(
    onSnapshot(
      regRef,
      (snap) => callbacks.onRegistrations(snap.docs.map((d) => d.data() as Registration)),
      (err) => handleFirestoreError(err, OperationType.LIST, 'registrations')
    )
  );

  const txnRef = isAdmin
    ? collection(db, 'transactions')
    : query(collection(db, 'transactions'), where('userId', '==', uid));
  unsubs.push(
    onSnapshot(
      txnRef,
      (snap) => callbacks.onTransactions(snap.docs.map((d) => d.data() as TransactionRecord)),
      (err) => handleFirestoreError(err, OperationType.LIST, 'transactions')
    )
  );

  const notifRef = isAdmin
    ? collection(db, 'notifications')
    : query(collection(db, 'notifications'), where('userId', '==', uid));
  unsubs.push(
    onSnapshot(
      notifRef,
      (snap) => callbacks.onNotifications(snap.docs.map((d) => d.data() as AppNotification)),
      (err) => handleFirestoreError(err, OperationType.LIST, 'notifications')
    )
  );

  unsubs.push(
    onSnapshot(
      query(collection(db, 'paymentHashes'), where('type', 'in', ['sha256', 'dhash', 'txnid', 'combo'])),
      (snap) => callbacks.onPaymentHashes(snap.docs.map((d) => d.data() as PaymentHash)),
      (err) => handleFirestoreError(err, OperationType.LIST, 'paymentHashes')
    )
  );

  const fraudRef = isAdmin
    ? collection(db, 'fraudLogs')
    : query(collection(db, 'fraudLogs'), where('userId', '==', uid));
  unsubs.push(
    onSnapshot(
      fraudRef,
      (snap) => callbacks.onFraudLogs(snap.docs.map((d) => d.data() as FraudLog)),
      (err) => handleFirestoreError(err, OperationType.LIST, 'fraudLogs')
    )
  );

  if (isAdmin && callbacks.onAllUsers) {
    unsubs.push(
      onSnapshot(
        collection(db, 'users'),
        (snap) => callbacks.onAllUsers?.(snap.docs.map((d) => d.data() as UserProfile)),
        (err) => handleFirestoreError(err, OperationType.LIST, 'users')
      )
    );
  }

  return () => unsubs.forEach((u) => u());
}

export async function recordFraudIncident(params: {
  userId: string;
  userEmail: string;
  scrimId: string;
  layer: FraudLayer;
  reason: string;
  details?: string;
  currentStrikes: number;
}) {
  const logId = makeSafeId('fraud');
  const nextStrikes = params.currentStrikes + 1;
  try {
    const batch = writeBatch(db);
    batch.set(doc(db, 'fraudLogs', logId), {
      id: logId,
      userId: params.userId,
      userEmail: params.userEmail,
      scrimId: params.scrimId,
      layer: params.layer,
      reason: params.reason.slice(0, 250),
      details: (params.details || '').slice(0, 500),
      createdAt: serverTimestamp(),
    });
    batch.update(doc(db, 'users', params.userId), {
      strikes: nextStrikes,
      isBanned: nextStrikes >= 3,
      updatedAt: serverTimestamp(),
    });
    await batch.commit();
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, 'fraudLogs');
  }
}

export async function persistRegistrationAndHashes(params: {
  registration: Registration;
  isReupload: boolean;
  scrim: Scrim;
  aiAnalysis?: AIPaymentAnalysis;
  decisionStatus: 'slot_confirmed' | 'pending_review' | 'rejected';
  decisionReason: string;
}) {
  const { registration, isReupload, scrim, aiAnalysis, decisionStatus, decisionReason } = params;
  try {
    const batch = writeBatch(db);
    const regRef = doc(db, 'registrations', registration.id);
    const rosterId = `${scrim.id}_${registration.id}`;
    const rosterRef = doc(db, 'scrimRosters', rosterId);

    const regPayload = {
      ...registration,
      status: decisionStatus,
      reviewNotes: decisionReason.slice(0, 300),
      updatedAt: serverTimestamp(),
      ...(isReupload ? {} : { createdAt: serverTimestamp() }),
    };

    if (isReupload) {
      batch.update(regRef, {
        status: decisionStatus,
        paymentMethod: registration.paymentMethod || '',
        paymentAmount: registration.paymentAmount ?? 0,
        transactionId: registration.transactionId || '',
        transactionIdNormalized: registration.transactionIdNormalized || '',
        screenshotHashSha256: registration.screenshotHashSha256 || '',
        screenshotDHash: registration.screenshotDHash || '',
        screenshotDataUrl: registration.screenshotDataUrl || '',
        ...(aiAnalysis ? { aiResult: aiAnalysis } : {}),
        reviewNotes: decisionReason.slice(0, 300),
        attemptCount: registration.attemptCount,
        updatedAt: serverTimestamp(),
      });
      batch.update(rosterRef, {
        status: decisionStatus,
        updatedAt: serverTimestamp(),
      });
    } else {
      batch.set(regRef, regPayload);
      batch.set(rosterRef, {
        id: rosterId,
        scrimId: scrim.id,
        registrationId: registration.id,
        userId: registration.userId,
        teamName: registration.teamName,
        teamNameNormalized: registration.teamNameNormalized,
        teamLogoUrl: registration.teamLogoUrl || '',
        captainName: registration.captainName,
        captainUid: registration.captainUid,
        playerUids: registration.players.map((p) => p.uid),
        players: registration.players,
        status: decisionStatus,
        shareCode: registration.shareCode,
        hasTeamPassword: Boolean(registration.hasTeamPassword),
        teamPasswordHash: registration.teamPasswordHash || '',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    }

    // Store deduplication hashes (only when not rejected for non-receipt/tampering? Store SHA/dHash on all verified/pending to stop spam, and txnId/combo when present)
    if (decisionStatus !== 'rejected') {
      if (registration.screenshotHashSha256) {
        const hId = makeSafeId('hsha');
        batch.set(doc(db, 'paymentHashes', hId), {
          id: hId,
          type: 'sha256',
          value: registration.screenshotHashSha256,
          scrimId: scrim.id,
          userId: registration.userId,
          createdAt: serverTimestamp(),
        });
      }
      if (registration.screenshotDHash) {
        const hId = makeSafeId('hdh');
        batch.set(doc(db, 'paymentHashes', hId), {
          id: hId,
          type: 'dhash',
          value: registration.screenshotDHash,
          dHash: registration.screenshotDHash,
          scrimId: scrim.id,
          userId: registration.userId,
          createdAt: serverTimestamp(),
        });
      }
      if (aiAnalysis?.transaction_id && normalizeTransactionId(aiAnalysis.transaction_id)) {
        const hId = makeSafeId('htxn');
        batch.set(doc(db, 'paymentHashes', hId), {
          id: hId,
          type: 'txnid',
          value: normalizeTransactionId(aiAnalysis.transaction_id),
          scrimId: scrim.id,
          userId: registration.userId,
          createdAt: serverTimestamp(),
        });
      }
      if (aiAnalysis && aiAnalysis.amount > 0 && aiAnalysis.sender_name && aiAnalysis.date_time) {
        const hId = makeSafeId('hcmb');
        batch.set(doc(db, 'paymentHashes', hId), {
          id: hId,
          type: 'combo',
          value: buildPaymentComboKey(aiAnalysis.amount, aiAnalysis.sender_name, aiAnalysis.date_time),
          scrimId: scrim.id,
          userId: registration.userId,
          amount: aiAnalysis.amount,
          senderName: aiAnalysis.sender_name,
          dateTime: aiAnalysis.date_time,
          createdAt: serverTimestamp(),
        });
      }
    }

    // Transaction record
    const txnDocId = makeSafeId('txn');
    const txnStatus =
      decisionStatus === 'slot_confirmed'
        ? 'verified'
        : decisionStatus === 'pending_review'
          ? 'pending'
          : 'rejected';
    batch.set(doc(db, 'transactions', txnDocId), {
      id: txnDocId,
      userId: registration.userId,
      scrimId: scrim.id,
      scrimTitle: scrim.title,
      registrationId: registration.id,
      teamName: registration.teamName,
      amount: aiAnalysis?.amount || scrim.entryFee,
      currency: scrim.currency,
      method: registration.paymentMethod || 'Wallet',
      transactionId: registration.transactionId || aiAnalysis?.transaction_id || 'N/A',
      status: txnStatus,
      notes: decisionReason.slice(0, 240),
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });

    // Notification
    const notifId = makeSafeId('notif');
    batch.set(doc(db, 'notifications', notifId), {
      id: notifId,
      userId: registration.userId,
      scrimId: scrim.id,
      title:
        decisionStatus === 'slot_confirmed'
          ? `Slot Confirmed · ${registration.teamName}`
          : decisionStatus === 'pending_review'
            ? `Payment Under Review · ${registration.teamName}`
            : `Payment Rejected · ${registration.teamName}`,
      message: decisionReason.slice(0, 400),
      type: decisionStatus === 'slot_confirmed' ? 'confirmed' : decisionStatus === 'rejected' ? 'rejected' : 'info',
      read: false,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });

    // If auto-approved -> grant scrim room access and increment slotsFilled
    if (decisionStatus === 'slot_confirmed') {
      const accessId = `${scrim.id}_${registration.userId}`;
      batch.set(doc(db, 'scrimAccess', accessId), {
        scrimId: scrim.id,
        userId: registration.userId,
        registrationId: registration.id,
        grantedAt: serverTimestamp(),
      });

      const nextSlots = Math.min(scrim.totalSlots, scrim.slotsFilled + 1);
      const nextStatus =
        nextSlots >= scrim.totalSlots
          ? 'Full'
          : nextSlots / scrim.totalSlots >= 0.7
            ? 'Filling Fast'
            : scrim.status;
      batch.update(doc(db, 'scrims', scrim.id), {
        slotsFilled: nextSlots,
        status: nextStatus,
        updatedAt: serverTimestamp(),
      });
    }

    await batch.commit();
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, 'registrations');
  }
}

export async function fetchScrimRoomCredentials(scrimId: string): Promise<ScrimRoom | null> {
  const path = `scrimRooms/${scrimId}`;
  try {
    const snap = await getDoc(doc(db, 'scrimRooms', scrimId));
    if (!snap.exists()) return null;
    return snap.data() as ScrimRoom;
  } catch (error) {
    // Expected permission denial before release time for non-admins
    return null;
  }
}

export async function updateRegisteredTeamPassword(params: {
  registrationId: string;
  scrimId: string;
  hasTeamPassword: boolean;
  teamPasswordHash: string;
}) {
  const { registrationId, scrimId, hasTeamPassword, teamPasswordHash } = params;
  const regPath = `registrations/${registrationId}`;
  const rosterId = `${scrimId}_${registrationId}`;
  try {
    const batch = writeBatch(db);
    batch.update(doc(db, 'registrations', registrationId), {
      hasTeamPassword,
      teamPasswordHash: teamPasswordHash.slice(0, 160),
      updatedAt: serverTimestamp(),
    });
    batch.update(doc(db, 'scrimRosters', rosterId), {
      hasTeamPassword,
      teamPasswordHash: teamPasswordHash.slice(0, 160),
      updatedAt: serverTimestamp(),
    });
    await batch.commit();
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, regPath);
  }
}

export async function markNotificationRead(notifId: string) {
  try {
    await updateDoc(doc(db, 'notifications', notifId), {
      read: true,
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `notifications/${notifId}`);
  }
}

// --- Admin Operations ---

export async function adminSaveScrim(scrim: Scrim, isNew: boolean, roomCreds?: { roomId: string; roomPassword: string }) {
  try {
    const batch = writeBatch(db);
    const ref = doc(db, 'scrims', scrim.id);
    if (isNew) {
      batch.set(ref, {
        ...scrim,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    } else {
      batch.update(ref, {
        title: scrim.title,
        bannerUrl: scrim.bannerUrl,
        map: scrim.map,
        mode: scrim.mode,
        dateTimeISO: scrim.dateTimeISO,
        registrationOpensAtISO: scrim.registrationOpensAtISO,
        roomReleaseAtISO: scrim.roomReleaseAtISO,
        entryFee: scrim.entryFee,
        currency: scrim.currency,
        prizePool: scrim.prizePool,
        prizeDistribution: scrim.prizeDistribution,
        totalSlots: scrim.totalSlots,
        slotsFilled: scrim.slotsFilled,
        status: scrim.status,
        rules: scrim.rules,
        pointsSystem: scrim.pointsSystem,
        roomReleased: Boolean(scrim.roomReleased),
        updatedAt: serverTimestamp(),
      });
    }

    if (roomCreds) {
      batch.set(doc(db, 'scrimRooms', scrim.id), {
        scrimId: scrim.id,
        roomId: roomCreds.roomId.slice(0, 40),
        roomPassword: roomCreds.roomPassword.slice(0, 40),
        releaseAt: Timestamp.fromDate(new Date(scrim.roomReleaseAtISO)),
        updatedAt: serverTimestamp(),
      });
    }

    await batch.commit();
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `scrims/${scrim.id}`);
  }
}

export async function adminDeleteScrim(scrimId: string) {
  try {
    await deleteDoc(doc(db, 'scrims', scrimId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `scrims/${scrimId}`);
  }
}

export async function adminSavePaymentMethod(method: PaymentMethod, isNew: boolean) {
  try {
    const ref = doc(db, 'paymentMethods', method.id);
    if (isNew) {
      await setDoc(ref, {
        ...method,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    } else {
      await updateDoc(ref, {
        name: method.name,
        type: method.type,
        accountName: method.accountName,
        accountNumber: method.accountNumber,
        qrImageDataUrl: method.qrImageDataUrl || '',
        instructions: method.instructions || '',
        enabled: method.enabled,
        updatedAt: serverTimestamp(),
      });
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `paymentMethods/${method.id}`);
  }
}

export async function adminDeletePaymentMethod(methodId: string) {
  try {
    await deleteDoc(doc(db, 'paymentMethods', methodId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `paymentMethods/${methodId}`);
  }
}

export async function adminReviewRegistration(params: {
  registration: Registration;
  scrim?: Scrim;
  approve: boolean;
  reason: string;
}) {
  const { registration, scrim, approve, reason } = params;
  const newStatus = approve ? 'slot_confirmed' : 'rejected';
  try {
    const batch = writeBatch(db);
    batch.update(doc(db, 'registrations', registration.id), {
      status: newStatus,
      reviewNotes: reason.slice(0, 300),
      updatedAt: serverTimestamp(),
    });
    batch.update(doc(db, 'scrimRosters', `${registration.scrimId}_${registration.id}`), {
      status: newStatus,
      updatedAt: serverTimestamp(),
    });

    if (approve && scrim && registration.status !== 'slot_confirmed') {
      batch.set(doc(db, 'scrimAccess', `${scrim.id}_${registration.userId}`), {
        scrimId: scrim.id,
        userId: registration.userId,
        registrationId: registration.id,
        grantedAt: serverTimestamp(),
      });
      const nextSlots = Math.min(scrim.totalSlots, scrim.slotsFilled + 1);
      const nextScrimStatus =
        nextSlots >= scrim.totalSlots
          ? 'Full'
          : nextSlots / scrim.totalSlots >= 0.7
            ? 'Filling Fast'
            : scrim.status;
      batch.update(doc(db, 'scrims', scrim.id), {
        slotsFilled: nextSlots,
        status: nextScrimStatus,
        updatedAt: serverTimestamp(),
      });
    }

    const notifId = makeSafeId('notif');
    batch.set(doc(db, 'notifications', notifId), {
      id: notifId,
      userId: registration.userId,
      scrimId: registration.scrimId,
      title: approve ? `Slot Confirmed · ${registration.teamName}` : `Registration Rejected · ${registration.teamName}`,
      message: reason.slice(0, 400),
      type: approve ? 'confirmed' : 'rejected',
      read: false,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });

    await batch.commit();
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `registrations/${registration.id}`);
  }
}

export async function adminRemoveRegistration(reg: Registration, scrim?: Scrim) {
  try {
    const batch = writeBatch(db);
    batch.delete(doc(db, 'registrations', reg.id));
    batch.delete(doc(db, 'scrimRosters', `${reg.scrimId}_${reg.id}`));
    if (scrim && reg.status === 'slot_confirmed' && scrim.slotsFilled > 0) {
      batch.update(doc(db, 'scrims', scrim.id), {
        slotsFilled: increment(-1),
        updatedAt: serverTimestamp(),
      });
    }
    await batch.commit();
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `registrations/${reg.id}`);
  }
}

export async function adminSaveTransaction(txn: TransactionRecord, isNew: boolean) {
  try {
    const ref = doc(db, 'transactions', txn.id);
    if (isNew) {
      await setDoc(ref, {
        ...txn,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    } else {
      await updateDoc(ref, {
        status: txn.status,
        notes: txn.notes || '',
        updatedAt: serverTimestamp(),
      });
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `transactions/${txn.id}`);
  }
}

export async function adminToggleUserBan(uid: string, ban: boolean) {
  try {
    await updateDoc(doc(db, 'users', uid), {
      isBanned: ban,
      strikes: ban ? 3 : 0,
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `users/${uid}`);
  }
}

export async function adminPushAnnouncement(ann: Announcement) {
  try {
    await setDoc(doc(db, 'announcements', ann.id), {
      ...ann,
      createdAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, `announcements/${ann.id}`);
  }
}

export async function adminSaveResult(result: ScrimResult) {
  try {
    await setDoc(doc(db, 'results', result.id), {
      ...result,
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `results/${result.id}`);
  }
}

export async function adminAssignTeamRoomCredentials(params: {
  registration: Registration;
  roomId: string;
  roomPassword: string;
}) {
  const { registration, roomId, roomPassword } = params;
  const cleanId = roomId.trim().slice(0, 40);
  const cleanPass = roomPassword.trim().slice(0, 40);
  try {
    const batch = writeBatch(db);
    batch.update(doc(db, 'registrations', registration.id), {
      assignedRoomId: cleanId,
      assignedRoomPassword: cleanPass,
      roomAssignedAtISO: cleanId ? new Date().toISOString() : '',
      updatedAt: serverTimestamp(),
    });

    if (cleanId) {
      const notifId = makeSafeId('notif');
      batch.set(doc(db, 'notifications', notifId), {
        id: notifId,
        userId: registration.userId,
        scrimId: registration.scrimId,
        title: `Scrim ID & Pass Placed · ${registration.teamName}`,
        message: `Room ID: ${cleanId} · Passcode: ${cleanPass || 'None'}`,
        type: 'room_release',
        read: false,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    }

    await batch.commit();
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `registrations/${registration.id}`);
  }
}

export async function adminPushRoomToScrimTeams(params: {
  scrim: Scrim;
  registrations: Registration[];
  roomId: string;
  roomPassword: string;
}) {
  const { scrim, registrations, roomId, roomPassword } = params;
  const cleanId = roomId.trim().slice(0, 40);
  const cleanPass = roomPassword.trim().slice(0, 40);
  if (!cleanId) return 0;

  const targetTeams = registrations.filter((r) => r.scrimId === scrim.id && r.status !== 'rejected');
  try {
    const batch = writeBatch(db);
    batch.set(doc(db, 'scrimRooms', scrim.id), {
      scrimId: scrim.id,
      roomId: cleanId,
      roomPassword: cleanPass,
      releaseAt: Timestamp.fromDate(new Date(scrim.roomReleaseAtISO)),
      updatedAt: serverTimestamp(),
    });
    batch.update(doc(db, 'scrims', scrim.id), {
      roomReleased: true,
      updatedAt: serverTimestamp(),
    });

    const nowISO = new Date().toISOString();
    for (const reg of targetTeams) {
      batch.update(doc(db, 'registrations', reg.id), {
        assignedRoomId: cleanId,
        assignedRoomPassword: cleanPass,
        roomAssignedAtISO: nowISO,
        updatedAt: serverTimestamp(),
      });
      const notifId = makeSafeId('notif');
      batch.set(doc(db, 'notifications', notifId), {
        id: notifId,
        userId: reg.userId,
        scrimId: scrim.id,
        title: `Scrim ID & Pass Released · ${reg.teamName}`,
        message: `${scrim.title} — Room ID: ${cleanId} · Passcode: ${cleanPass || 'None'}`,
        type: 'room_release',
        read: false,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    }

    await batch.commit();
    return targetTeams.length;
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `scrimRooms/${scrim.id}`);
  }
}

