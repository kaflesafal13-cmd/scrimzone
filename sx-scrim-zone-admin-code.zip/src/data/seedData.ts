import { Announcement, PaymentMethod, Scrim, ScrimResult, ScrimRoster } from '../types';
import { DEFAULT_POINTS_SYSTEM } from '../utils/scoring';

export const HERO_BANNER_URL = '/src/assets/images/hero_esports_arena_1795758509548.jpg';
export const EMPTY_STATE_IMAGE_URL = '/src/assets/images/empty_state_squad_1795758509580.jpg';

function buildSvgQrDataUrl(label: string): string {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 180 180" width="180" height="180">
    <rect width="180" height="180" rx="12" fill="#FFFFFF"/>
    <rect x="14" y="14" width="44" height="44" fill="#0A0A0F"/>
    <rect x="22" y="22" width="28" height="28" fill="#FFFFFF"/>
    <rect x="28" y="28" width="16" height="16" fill="#0A0A0F"/>
    <rect x="122" y="14" width="44" height="44" fill="#0A0A0F"/>
    <rect x="130" y="22" width="28" height="28" fill="#FFFFFF"/>
    <rect x="136" y="28" width="16" height="16" fill="#0A0A0F"/>
    <rect x="14" y="122" width="44" height="44" fill="#0A0A0F"/>
    <rect x="22" y="130" width="28" height="28" fill="#FFFFFF"/>
    <rect x="28" y="136" width="16" height="16" fill="#0A0A0F"/>
    <rect x="70" y="20" width="12" height="12" fill="#0A0A0F"/>
    <rect x="92" y="20" width="16" height="12" fill="#0A0A0F"/>
    <rect x="70" y="42" width="20" height="12" fill="#FF6A00"/>
    <rect x="20" y="72" width="16" height="14" fill="#0A0A0F"/>
    <rect x="46" y="72" width="24" height="14" fill="#0A0A0F"/>
    <rect x="80" y="68" width="22" height="22" fill="#FF6A00"/>
    <rect x="114" y="72" width="18" height="14" fill="#0A0A0F"/>
    <rect x="144" y="72" width="18" height="18" fill="#0A0A0F"/>
    <rect x="20" y="96" width="32" height="12" fill="#0A0A0F"/>
    <rect x="64" y="100" width="14" height="24" fill="#0A0A0F"/>
    <rect x="90" y="98" width="20" height="16" fill="#0A0A0F"/>
    <rect x="124" y="98" width="38" height="14" fill="#0A0A0F"/>
    <rect x="72" y="134" width="22" height="22" fill="#0A0A0F"/>
    <rect x="104" y="124" width="18" height="18" fill="#FF6A00"/>
    <rect x="132" y="132" width="30" height="28" fill="#0A0A0F"/>
    <text x="90" y="174" text-anchor="middle" font-family="monospace" font-size="9" fill="#0A0A0F">${label}</text>
  </svg>`;
  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
}

export const SEED_SCRIMS: Scrim[] = [];

export const SEED_PAYMENT_METHODS: PaymentMethod[] = [
  {
    id: 'pm-esewa-main',
    name: 'eSewa Official',
    type: 'eSewa',
    accountName: 'SX SCRIM ZONE',
    accountNumber: '9801234567',
    qrImageDataUrl: buildSvgQrDataUrl('eSewa 9801234567'),
    instructions: 'Include your Team Name in remarks when paying via eSewa.',
    enabled: true,
  },
  {
    id: 'pm-khalti-main',
    name: 'Khalti Wallet',
    type: 'Khalti',
    accountName: 'SX Esports Arena',
    accountNumber: '9812345678',
    qrImageDataUrl: buildSvgQrDataUrl('Khalti 9812345678'),
    instructions: 'Send exact entry fee and upload the full-screen confirmation.',
    enabled: true,
  },
  {
    id: 'pm-upi-main',
    name: 'UPI Instant',
    type: 'UPI',
    accountName: 'SX Scrim Zone',
    accountNumber: 'sxscrim@okaxis',
    qrImageDataUrl: buildSvgQrDataUrl('UPI sxscrim@okaxis'),
    instructions: 'Make sure UTR / Reference Number is clearly visible in screenshot.',
    enabled: true,
  },
];

export const SEED_ANNOUNCEMENTS: Announcement[] = [
  {
    id: 'ann-season-open',
    title: 'Season 4 Scrims Live · Instant AI Verification',
    message:
      'Upload clear, uncropped payment receipts showing Transaction ID and timestamp within 30 minutes for automatic slot confirmation.',
    priority: 'urgent',
    createdBy: 'SX Tournament Ops',
  },
  {
    id: 'ann-room-rule',
    title: 'Room Credentials Auto-Release Policy',
    message:
      'Room ID and password unlock for confirmed captains 10 minutes before match time or immediately when placed by the admin.',
    priority: 'normal',
    createdBy: 'SX Tournament Ops',
  },
];

export const SEED_RESULTS: ScrimResult[] = [];

export const SEED_ROSTERS: ScrimRoster[] = [];

