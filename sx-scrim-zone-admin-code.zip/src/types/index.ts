export type ScrimMap = 'Bermuda' | 'Purgatory' | 'Kalahari' | 'Alpine' | 'NeXTerra';
export type ScrimMode = 'Squad' | 'Duo' | 'Solo';
export type ScrimStatus = 'Open' | 'Filling Fast' | 'Full' | 'Live' | 'Completed';
export type RegistrationStatus = 'pending_review' | 'verified' | 'rejected' | 'slot_confirmed';
export type PaymentMethodType = 'eSewa' | 'Khalti' | 'UPI' | 'bKash' | 'Bank';
export type TransactionStatus = 'verified' | 'pending' | 'rejected' | 'refunded' | 'manual';
export type FraudLayer = 'sha256' | 'dhash' | 'transaction_id' | 'combo' | 'rate_limit' | 'tampering';

export const SCHEMA_LIMITS = {
  TITLE_MAX: 100,
  TEAM_NAME_MIN: 2,
  TEAM_NAME_MAX: 40,
  PLAYER_NAME_MAX: 40,
  UID_PATTERN: /^[0-9]{8,12}$/,
  ID_PATTERN: /^[a-zA-Z0-9_-]+$/,
  PHONE_MIN: 7,
  PHONE_MAX: 25,
  NOTES_MAX: 300,
  MAX_ATTEMPTS: 3,
  TEAM_PASSWORD_MIN: 4,
  TEAM_PASSWORD_MAX: 32,
} as const;

export interface PrizeTier {
  rank: number;
  label: string;
  amount: number;
}

export interface PointsSystem {
  placement: Record<string, number>;
  killPoint: number;
}

export interface Scrim {
  id: string;
  title: string;
  bannerUrl: string;
  map: ScrimMap;
  mode: ScrimMode;
  dateTimeISO: string;
  registrationOpensAtISO: string;
  roomReleaseAtISO: string;
  entryFee: number;
  currency: string;
  prizePool: number;
  prizeDistribution: PrizeTier[];
  totalSlots: number;
  slotsFilled: number;
  status: ScrimStatus;
  rules: string[];
  pointsSystem: PointsSystem;
  roomReleased?: boolean;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface ScrimRoom {
  scrimId: string;
  roomId: string;
  roomPassword: string;
  releaseAt?: unknown;
  updatedAt?: unknown;
}

export interface PlayerEntry {
  ign: string;
  uid: string;
  role: 'Captain' | 'Rusher' | 'Sniper' | 'Support' | 'IGL' | 'Substitute';
  photoUrl?: string;
}

export interface SavedTeam {
  id: string;
  teamName: string;
  teamLogoUrl?: string;
  captainName: string;
  captainUid: string;
  captainPhone: string;
  mode: ScrimMode;
  players: PlayerEntry[];
}

export interface UserProfile {
  uid: string;
  email: string;
  displayName?: string;
  photoURL?: string;
  inGameName?: string;
  gameUid?: string;
  whatsapp?: string;
  role: 'captain' | 'admin';
  strikes: number;
  isBanned: boolean;
  savedTeams?: SavedTeam[];
  createdAt?: unknown;
  updatedAt?: unknown;
  lastLogin?: unknown;
}

export interface PaymentMethod {
  id: string;
  name: string;
  type: PaymentMethodType;
  accountName: string;
  accountNumber: string;
  qrImageDataUrl?: string;
  instructions?: string;
  enabled: boolean;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface AIPaymentAnalysis {
  is_payment_screenshot: boolean;
  amount: number;
  currency: string;
  transaction_id: string;
  receiver_name_or_number: string;
  sender_name: string;
  date_time: string;
  status: 'success' | 'failed' | 'pending' | 'unknown';
  tampering_suspected: boolean;
  confidence: number;
  analysis_summary?: string;
}

export interface Registration {
  id: string;
  scrimId: string;
  scrimTitle?: string;
  userId: string;
  teamName: string;
  teamNameNormalized: string;
  teamLogoUrl?: string;
  captainName: string;
  captainUid: string;
  captainPhone: string;
  players: PlayerEntry[];
  status: RegistrationStatus;
  paymentMethod?: string;
  paymentAmount?: number;
  transactionId?: string;
  transactionIdNormalized?: string;
  screenshotHashSha256?: string;
  screenshotDHash?: string;
  screenshotDataUrl?: string;
  aiResult?: AIPaymentAnalysis;
  reviewNotes?: string;
  attemptCount: number;
  shareCode: string;
  hasTeamPassword?: boolean;
  teamPasswordHash?: string;
  assignedRoomId?: string;
  assignedRoomPassword?: string;
  roomAssignedAtISO?: string;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface ScrimRoster {
  id: string;
  scrimId: string;
  registrationId: string;
  userId: string;
  teamName: string;
  teamNameNormalized: string;
  teamLogoUrl?: string;
  captainName?: string;
  captainUid?: string;
  playerUids: string[];
  players: PlayerEntry[];
  status: RegistrationStatus;
  shareCode: string;
  hasTeamPassword?: boolean;
  teamPasswordHash?: string;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface PaymentHash {
  id: string;
  type: 'sha256' | 'dhash' | 'txnid' | 'combo';
  value: string;
  dHash?: string;
  scrimId: string;
  userId: string;
  amount?: number;
  senderName?: string;
  dateTime?: string;
  createdAt?: unknown;
}

export interface TransactionRecord {
  id: string;
  userId: string;
  scrimId: string;
  scrimTitle?: string;
  registrationId?: string;
  teamName?: string;
  amount: number;
  currency: string;
  method: string;
  transactionId?: string;
  status: TransactionStatus;
  notes?: string;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface FraudLog {
  id: string;
  userId: string;
  userEmail?: string;
  scrimId: string;
  reason: string;
  layer: FraudLayer;
  details?: string;
  createdAt?: unknown;
}

export interface AppNotification {
  id: string;
  userId: string;
  title: string;
  message: string;
  type: 'confirmed' | 'rejected' | 'room_release' | 'announcement' | 'info';
  scrimId?: string;
  read: boolean;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface Announcement {
  id: string;
  title: string;
  message: string;
  priority: 'normal' | 'urgent';
  createdBy: string;
  createdAt?: unknown;
}

export interface ScrimResult {
  id: string;
  scrimId: string;
  teamId?: string;
  teamName: string;
  placement: number;
  kills: number;
  placementPoints?: number;
  killPoints?: number;
  totalPoints: number;
  prizeAmount?: number;
  prizePaid: boolean;
  payoutReference?: string;
  updatedAt?: unknown;
}
