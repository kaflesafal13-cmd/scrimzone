import React, { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react';
import {
  User,
  createUserWithEmailAndPassword,
  onAuthStateChanged,
  sendEmailVerification,
  sendPasswordResetEmail,
  signInWithEmailAndPassword,
  signOut,
  updateProfile,
} from 'firebase/auth';
import { doc, getDoc } from 'firebase/firestore';
import { UserProfile } from '../types';
import {
  BOOTSTRAPPED_ADMIN_EMAIL,
  auth,
  authPersistenceReady,
  db,
} from '../lib/firebase';
import { isValidAdminCode } from '../lib/adminCode';
import { ensureUserProfile } from '../lib/db';
import { extractFirebaseErrorCode, mapFirebaseAuthError } from '../utils/authErrors';

export type UserRole = 'captain' | 'admin';

export interface AuthToastPayload {
  type: 'success' | 'error' | 'info';
  title: string;
  description?: string;
}

interface AuthContextValue {
  user: User | null;
  userProfile: UserProfile | null;
  role: UserRole;
  loading: boolean;
  authActionPending: boolean;
  redirectPath: string | null;
  setRedirectPath: (path: string | null) => void;
  clearRedirectPath: () => void;
  unlockAdmin: (code: string) => boolean;
  signInWithEmail: (email: string, password: string) => Promise<void>;
  signUpWithEmail: (email: string, password: string, displayName: string) => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
  logout: () => Promise<void>;
  refreshProfile: () => Promise<void>;
}

const REDIRECT_STORAGE_KEY = 'sx_auth_redirect';
const ADMIN_UNLOCK_KEY = 'sx_admin_unlocked';

function readAdminUnlocked(): boolean {
  if (typeof window === 'undefined') return false;
  try {
    return window.sessionStorage.getItem(ADMIN_UNLOCK_KEY) === '1';
  } catch {
    return false;
  }
}

function writeAdminUnlocked(value: boolean) {
  if (typeof window === 'undefined') return;
  try {
    if (value) window.sessionStorage.setItem(ADMIN_UNLOCK_KEY, '1');
    else window.sessionStorage.removeItem(ADMIN_UNLOCK_KEY);
  } catch {
    // ignore storage errors
  }
}

const AuthContext = createContext<AuthContextValue | null>(null);

function readStoredRedirectPath(): string | null {
  if (typeof window === 'undefined') return null;
  try {
    const val = window.sessionStorage.getItem(REDIRECT_STORAGE_KEY);
    return val && val.startsWith('/') ? val : null;
  } catch {
    return null;
  }
}

function writeStoredRedirectPath(path: string | null) {
  if (typeof window === 'undefined') return;
  try {
    if (path && path.startsWith('/')) {
      window.sessionStorage.setItem(REDIRECT_STORAGE_KEY, path);
    } else {
      window.sessionStorage.removeItem(REDIRECT_STORAGE_KEY);
    }
  } catch {
    // Ignore storage quota or private-mode errors
  }
}

function makeCodedError(message: string, code: string): Error {
  const err = new Error(message) as Error & { code?: string };
  err.code = code;
  return err;
}

export const AuthProvider: React.FC<{
  children: React.ReactNode;
  onToast?: (toast: AuthToastPayload) => void;
}> = ({ children, onToast }) => {
  const [user, setUser] = useState<User | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [baseRole, setRole] = useState<UserRole>('captain');
  const [adminUnlocked, setAdminUnlocked] = useState<boolean>(() => readAdminUnlocked());
  const role: UserRole = baseRole === 'admin' || adminUnlocked ? 'admin' : 'captain';
  const [loading, setLoading] = useState(true);
  const [authActionPending, setAuthActionPending] = useState(false);
  const [redirectPath, setRedirectPathState] = useState<string | null>(() => readStoredRedirectPath());

  const onToastRef = useRef(onToast);
  onToastRef.current = onToast;
  const authSeqRef = useRef(0);
  const actionLockRef = useRef(false);

  const emitToast = useCallback((toast: AuthToastPayload) => {
    onToastRef.current?.(toast);
  }, []);

  const setRedirectPath = useCallback((path: string | null) => {
    const normalized = path && path.startsWith('/') && path !== '/login' ? path : null;
    setRedirectPathState(normalized);
    writeStoredRedirectPath(normalized);
  }, []);

  const clearRedirectPath = useCallback(() => {
    setRedirectPathState(null);
    writeStoredRedirectPath(null);
  }, []);

  useEffect(() => {
    let cancelled = false;
    let unsubscribeAuth: (() => void) | undefined;

    const resolveUserSession = async (fbUser: User | null, seq: number) => {
      if (!fbUser) {
        if (cancelled || seq !== authSeqRef.current) return;
        setUser(null);
        setUserProfile(null);
        setRole('captain');
        setLoading(false);
        return;
      }

      const isBootAdmin = Boolean(
        fbUser.emailVerified &&
          fbUser.email &&
          fbUser.email.toLowerCase() === BOOTSTRAPPED_ADMIN_EMAIL.toLowerCase()
      );

      let adminDocExists = false;
      if (!isBootAdmin && fbUser.emailVerified) {
        try {
          const admSnap = await getDoc(doc(db, 'admins', fbUser.uid));
          adminDocExists = admSnap.exists();
        } catch {
          adminDocExists = false;
        }
      }

      let resolvedProfile: UserProfile | null = null;
      if (fbUser.emailVerified) {
        try {
          resolvedProfile = await ensureUserProfile(
            fbUser.uid,
            fbUser.email || '',
            fbUser.displayName,
            isBootAdmin || adminDocExists,
            fbUser.photoURL
          );
        } catch (err) {
          console.error('[SX Auth] Failed to ensure user profile:', err);
        }
      } else {
        try {
          const snap = await getDoc(doc(db, 'users', fbUser.uid));
          if (snap.exists()) {
            resolvedProfile = snap.data() as UserProfile;
          }
        } catch {
          resolvedProfile = null;
        }
      }

      if (cancelled || seq !== authSeqRef.current) return;

      const resolvedRole: UserRole =
        isBootAdmin || adminDocExists || resolvedProfile?.role === 'admin' ? 'admin' : 'captain';

      setUser(fbUser);
      setUserProfile(resolvedProfile);
      setRole(resolvedRole);
      setLoading(false);
    };

    const boot = async () => {
      await authPersistenceReady;

      if (cancelled) return;

      unsubscribeAuth = onAuthStateChanged(auth, (fbUser) => {
        const seq = ++authSeqRef.current;
        void resolveUserSession(fbUser, seq);
      });
    };

    void boot();

    return () => {
      cancelled = true;
      unsubscribeAuth?.();
    };
  }, [emitToast]);

  const refreshProfile = useCallback(async () => {
    const current = auth.currentUser;
    if (!current) return;
    await current.reload().catch(() => undefined);
    const snap = await getDoc(doc(db, 'users', current.uid));
    if (snap.exists()) {
      const data = snap.data() as UserProfile;
      setUserProfile(data);
      const isBootAdmin = Boolean(
        current.emailVerified &&
          current.email &&
          current.email.toLowerCase() === BOOTSTRAPPED_ADMIN_EMAIL.toLowerCase()
      );
      setRole(isBootAdmin || data.role === 'admin' ? 'admin' : 'captain');
    }
  }, []);

  const unlockAdmin = useCallback((code: string) => {
    if (!isValidAdminCode(code)) return false;
    writeAdminUnlocked(true);
    setAdminUnlocked(true);
    emitToast({ type: 'success', title: 'Admin access unlocked' });
    return true;
  }, [emitToast]);

  const signInWithEmail = useCallback(
    async (email: string, password: string) => {
      if (actionLockRef.current) return;
      actionLockRef.current = true;
      setAuthActionPending(true);
      try {
        await authPersistenceReady;
        const cred = await signInWithEmailAndPassword(auth, email.trim(), password);
        if (!cred.user.emailVerified) {
          emitToast({
            type: 'info',
            title: 'Verify your email address',
            description: 'Check your inbox for the verification link before registering teams.',
          });
        } else {
          emitToast({ type: 'success', title: 'Welcome back to SX SCRIM ZONE' });
        }
      } catch (err: unknown) {
        const code = extractFirebaseErrorCode(err);
        console.error('[SX Auth] Email sign-in error:', code, err);
        const mapped = mapFirebaseAuthError(err);
        emitToast({ type: 'error', title: mapped.title, description: mapped.message });
        throw makeCodedError(mapped.message, code);
      } finally {
        actionLockRef.current = false;
        setAuthActionPending(false);
      }
    },
    [emitToast]
  );

  const signUpWithEmail = useCallback(
    async (email: string, password: string, displayName: string) => {
      if (actionLockRef.current) return;
      actionLockRef.current = true;
      setAuthActionPending(true);
      try {
        await authPersistenceReady;
        const cred = await createUserWithEmailAndPassword(auth, email.trim(), password);
        if (displayName.trim()) {
          await updateProfile(cred.user, { displayName: displayName.trim().slice(0, 80) });
        }
        await sendEmailVerification(cred.user);
        emitToast({
          type: 'success',
          title: 'Account created',
          description: 'Verification email sent. Verify your email to unlock team registrations.',
        });
      } catch (err: unknown) {
        const code = extractFirebaseErrorCode(err);
        console.error('[SX Auth] Email sign-up error:', code, err);
        const mapped = mapFirebaseAuthError(err);
        emitToast({ type: 'error', title: mapped.title, description: mapped.message });
        throw makeCodedError(mapped.message, code);
      } finally {
        actionLockRef.current = false;
        setAuthActionPending(false);
      }
    },
    [emitToast]
  );

  const resetPassword = useCallback(
    async (email: string) => {
      if (actionLockRef.current) return;
      actionLockRef.current = true;
      setAuthActionPending(true);
      try {
        await sendPasswordResetEmail(auth, email.trim());
        emitToast({
          type: 'success',
          title: 'Password reset link sent',
          description: 'Check your inbox and spam folder for password reset instructions.',
        });
      } catch (err: unknown) {
        const code = extractFirebaseErrorCode(err);
        console.error('[SX Auth] Password reset error:', code, err);
        const mapped = mapFirebaseAuthError(err);
        emitToast({ type: 'error', title: mapped.title, description: mapped.message });
        throw makeCodedError(mapped.message, code);
      } finally {
        actionLockRef.current = false;
        setAuthActionPending(false);
      }
    },
    [emitToast]
  );

  const logout = useCallback(async () => {
    if (actionLockRef.current) return;
    actionLockRef.current = true;
    setAuthActionPending(true);
    try {
      await signOut(auth);
      writeAdminUnlocked(false);
      setAdminUnlocked(false);
      clearRedirectPath();
      emitToast({ type: 'info', title: 'Signed out' });
    } catch (err: unknown) {
      const code = extractFirebaseErrorCode(err);
      console.error('[SX Auth] Sign-out error:', code, err);
      const mapped = mapFirebaseAuthError(err);
      emitToast({ type: 'error', title: mapped.title, description: mapped.message });
    } finally {
      actionLockRef.current = false;
      setAuthActionPending(false);
    }
  }, [clearRedirectPath, emitToast]);

  return (
    <AuthContext.Provider
      value={{
        user,
        userProfile,
        role,
        loading,
        authActionPending,
        redirectPath,
        setRedirectPath,
        clearRedirectPath,
        unlockAdmin,
        signInWithEmail,
        signUpWithEmail,
        resetPassword,
        logout,
        refreshProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used inside AuthProvider');
  return ctx;
}
