import React, { createContext, useCallback, useContext, useEffect, useState } from 'react';
import { User } from 'firebase/auth';
import {
  Announcement,
  AppNotification,
  FraudLog,
  PaymentHash,
  PaymentMethod,
  Registration,
  Scrim,
  ScrimResult,
  ScrimRoster,
  TransactionRecord,
  UserProfile,
} from '../types';
import {
  fetchPublicScrimData,
  seedFirestoreIfEmpty,
  subscribePublicCollections,
  subscribeUserCollections,
} from '../lib/db';
import {
  SEED_ANNOUNCEMENTS,
  SEED_PAYMENT_METHODS,
  SEED_RESULTS,
  SEED_ROSTERS,
  SEED_SCRIMS,
} from '../data/seedData';
import { AuthProvider, UserRole, useAuth } from './AuthContext';

export interface ToastMessage {
  id: string;
  type: 'success' | 'error' | 'info';
  title: string;
  description?: string;
}

interface AppContextValue {
  user: User | null;
  profile: UserProfile | null;
  role: UserRole;
  authReady: boolean;
  authLoading: boolean;
  isAdmin: boolean;
  theme: 'dark' | 'light';
  toggleTheme: () => void;
  scrims: Scrim[];
  paymentMethods: PaymentMethod[];
  announcements: Announcement[];
  results: ScrimResult[];
  rosters: ScrimRoster[];
  registrations: Registration[];
  transactions: TransactionRecord[];
  notifications: AppNotification[];
  paymentHashes: PaymentHash[];
  fraudLogs: FraudLog[];
  allUsers: UserProfile[];
  dataLoading: boolean;
  toasts: ToastMessage[];
  pushToast: (toast: Omit<ToastMessage, 'id'>) => void;
  dismissToast: (id: string) => void;
  loginWithEmail: (email: string, password: string) => Promise<void>;
  registerWithEmail: (email: string, password: string, displayName: string) => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
  logout: () => Promise<void>;
  refreshProfile: () => Promise<void>;
}

const AppContext = createContext<AppContextValue | null>(null);

const AppStateBridge: React.FC<{
  toasts: ToastMessage[];
  pushToast: (toast: Omit<ToastMessage, 'id'>) => void;
  dismissToast: (id: string) => void;
  children: React.ReactNode;
}> = ({ toasts, pushToast, dismissToast, children }) => {
  const {
    user,
    userProfile,
    role,
    loading: authLoading,
    signInWithEmail,
    signUpWithEmail,
    resetPassword,
    logout,
    refreshProfile,
  } = useAuth();

  const isAdmin = role === 'admin';
  const authReady = !authLoading;

  const [theme, setTheme] = useState<'dark' | 'light'>(() => {
    if (typeof window !== 'undefined') {
      const saved = window.localStorage.getItem('sx_theme');
      if (saved === 'light' || saved === 'dark') return saved;
    }
    return 'dark';
  });

  const [scrims, setScrims] = useState<Scrim[]>(SEED_SCRIMS);
  const [paymentMethods, setPaymentMethods] = useState<PaymentMethod[]>(SEED_PAYMENT_METHODS);
  const [announcements, setAnnouncements] = useState<Announcement[]>(SEED_ANNOUNCEMENTS);
  const [results, setResults] = useState<ScrimResult[]>(SEED_RESULTS);
  const [rosters, setRosters] = useState<ScrimRoster[]>(SEED_ROSTERS);
  const [registrations, setRegistrations] = useState<Registration[]>([]);
  const [transactions, setTransactions] = useState<TransactionRecord[]>([]);
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [paymentHashes, setPaymentHashes] = useState<PaymentHash[]>([]);
  const [fraudLogs, setFraudLogs] = useState<FraudLog[]>([]);
  const [allUsers, setAllUsers] = useState<UserProfile[]>([]);
  const [dataLoading, setDataLoading] = useState(true);

  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    window.localStorage.setItem('sx_theme', theme);
  }, [theme]);

  const toggleTheme = () => setTheme((prev) => (prev === 'dark' ? 'light' : 'dark'));

  useEffect(() => {
    let active = true;
    fetchPublicScrimData()
      .then((data) => {
        if (!active) return;
        setScrims(data.scrims);
        setPaymentMethods(data.paymentMethods);
        setAnnouncements(data.announcements);
        setResults(data.results);
        setRosters(data.rosters);
      })
      .finally(() => {
        if (active) setDataLoading(false);
      });
    return () => {
      active = false;
    };
  }, []);

  useEffect(() => {
    if (authLoading) return;

    if (!user) {
      setRegistrations([]);
      setTransactions([]);
      setNotifications([]);
      setPaymentHashes([]);
      setFraudLogs([]);
      setAllUsers([]);
      return;
    }

    if (isAdmin) {
      seedFirestoreIfEmpty().catch((err) => {
        console.error('[SX App] Failed seeding defaults:', err);
      });
    }

    const unsubPublic = subscribePublicCollections(
      {
        onScrims: setScrims,
        onPaymentMethods: setPaymentMethods,
        onAnnouncements: setAnnouncements,
        onResults: setResults,
        onRosters: setRosters,
      },
      isAdmin
    );

    const unsubUser = subscribeUserCollections(user.uid, isAdmin, {
      onRegistrations: setRegistrations,
      onTransactions: setTransactions,
      onNotifications: setNotifications,
      onPaymentHashes: setPaymentHashes,
      onFraudLogs: setFraudLogs,
      onAllUsers: isAdmin ? setAllUsers : undefined,
    });

    return () => {
      unsubPublic();
      unsubUser();
    };
  }, [authLoading, user, isAdmin]);

  return (
    <AppContext.Provider
      value={{
        user,
        profile: userProfile,
        role,
        authReady,
        authLoading,
        isAdmin,
        theme,
        toggleTheme,
        scrims,
        paymentMethods,
        announcements,
        results,
        rosters,
        registrations,
        transactions,
        notifications,
        paymentHashes,
        fraudLogs,
        allUsers,
        dataLoading,
        toasts,
        pushToast,
        dismissToast,
        loginWithEmail: signInWithEmail,
        registerWithEmail: signUpWithEmail,
        resetPassword,
        logout,
        refreshProfile,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const pushToast = useCallback((toast: Omit<ToastMessage, 'id'>) => {
    const id = `${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    setToasts((prev) => [...prev, { ...toast, id }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 5000);
  }, []);

  const dismissToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  return (
    <AuthProvider onToast={pushToast}>
      <AppStateBridge toasts={toasts} pushToast={pushToast} dismissToast={dismissToast}>
        {children}
      </AppStateBridge>
    </AuthProvider>
  );
};

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used inside AppProvider');
  return ctx;
}
