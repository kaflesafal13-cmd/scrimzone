import { PointsSystem, ScrimResult } from '../types';

export const DEFAULT_POINTS_SYSTEM: PointsSystem = {
  placement: {
    '1': 12,
    '2': 9,
    '3': 8,
    '4': 7,
    '5': 6,
    '6': 5,
    '7': 4,
    '8': 3,
    '9': 2,
    '10': 1,
    '11': 0,
    '12': 0,
  },
  killPoint: 1,
};

export function calculateTeamPoints(
  placement: number,
  kills: number,
  pointsSystem: PointsSystem = DEFAULT_POINTS_SYSTEM
): { placementPoints: number; killPoints: number; totalPoints: number } {
  const safePlacement = Math.max(1, Math.floor(placement));
  const safeKills = Math.max(0, Math.floor(kills));
  const placementPoints = pointsSystem.placement[String(safePlacement)] ?? 0;
  const killPoints = safeKills * (pointsSystem.killPoint ?? 1);
  return {
    placementPoints,
    killPoints,
    totalPoints: placementPoints + killPoints,
  };
}

export function sortLeaderboard(results: ScrimResult[]): ScrimResult[] {
  return [...results].sort((a, b) => {
    if (b.totalPoints !== a.totalPoints) return b.totalPoints - a.totalPoints;
    if (a.placement !== b.placement) return a.placement - b.placement;
    return b.kills - a.kills;
  });
}
