import test from 'node:test';
import assert from 'node:assert/strict';
import { hashTeamPassword, validateTeamPassword, verifyTeamPassword } from './teamPassword';

test('validateTeamPassword enforces 4-32 char boundaries', () => {
  assert.equal(validateTeamPassword('').valid, false);
  assert.equal(validateTeamPassword('123').valid, false);
  assert.equal(validateTeamPassword('   ').valid, false);
  assert.equal(validateTeamPassword('a'.repeat(33)).valid, false);
  assert.equal(validateTeamPassword('SX99').valid, true);
  assert.equal(validateTeamPassword('Inferno#2026').valid, true);
});

test('hashTeamPassword generates salted PBKDF2 hashes and verifies correctly', async () => {
  const h1 = await hashTeamPassword('SquadPass99');
  const h2 = await hashTeamPassword('SquadPass99');
  assert.notEqual(h1, h2);
  assert.match(h1, /^v1\$[0-9a-f]{32}\$[0-9a-f]{64}$/);
  assert.equal(await verifyTeamPassword('SquadPass99', h1), true);
  assert.equal(await verifyTeamPassword('  SquadPass99  ', h1), true);
  assert.equal(await verifyTeamPassword('WrongPass', h1), false);
  assert.equal(await verifyTeamPassword('SquadPass99', 'invalid-hash'), false);
});
