import test from 'node:test';
import assert from 'node:assert/strict';
import {
  extractFirebaseErrorCode,
  mapFirebaseAuthError,
  shouldFallbackToRedirect,
} from './authErrors';

test('extractFirebaseErrorCode reads object code and message code', () => {
  assert.equal(extractFirebaseErrorCode({ code: 'auth/unauthorized-domain' }), 'auth/unauthorized-domain');
  assert.equal(
    extractFirebaseErrorCode(new Error('Firebase: Error (auth/invalid-credential).')),
    'auth/invalid-credential'
  );
  assert.equal(extractFirebaseErrorCode(new Error('Random failure')), 'auth/unknown');
});

test('shouldFallbackToRedirect returns true only for popup interruption codes', () => {
  assert.equal(shouldFallbackToRedirect({ code: 'auth/popup-blocked' }), true);
  assert.equal(shouldFallbackToRedirect({ code: 'auth/popup-closed-by-user' }), true);
  assert.equal(shouldFallbackToRedirect({ code: 'auth/cancelled-popup-request' }), true);
  assert.equal(shouldFallbackToRedirect({ code: 'auth/unauthorized-domain' }), false);
  assert.equal(shouldFallbackToRedirect({ code: 'auth/network-request-failed' }), false);
});

test('mapFirebaseAuthError maps required Firebase Auth error codes to friendly messages', () => {
  assert.equal(
    mapFirebaseAuthError({ code: 'auth/unauthorized-domain' }).message,
    'This domain is not authorized. Add it in Firebase Authentication > Settings > Authorized domains.'
  );
  assert.equal(
    mapFirebaseAuthError({ code: 'auth/popup-blocked' }).message,
    'Popup was blocked. Redirecting you to sign in instead.'
  );
  assert.equal(
    mapFirebaseAuthError({ code: 'auth/network-request-failed' }).message,
    'Network error. Check your internet and try again.'
  );
  assert.ok(mapFirebaseAuthError({ code: 'auth/invalid-credential' }).message.includes('Incorrect email or password'));
  assert.ok(mapFirebaseAuthError({ code: 'auth/user-not-found' }).message.includes('No captain account'));
  assert.ok(mapFirebaseAuthError({ code: 'auth/wrong-password' }).message.includes('incorrect'));
  assert.ok(mapFirebaseAuthError({ code: 'auth/email-already-in-use' }).message.includes('already exists'));
  assert.ok(mapFirebaseAuthError({ code: 'auth/too-many-requests' }).message.includes('Too many'));
  assert.ok(
    mapFirebaseAuthError({ code: 'auth/account-exists-with-different-credential' }).message.includes(
      'different sign-in method'
    )
  );
});
