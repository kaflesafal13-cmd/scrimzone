export type RuleCategory = 'fair_play' | 'device' | 'reporting';
export type RuleFilter = 'all' | RuleCategory;
export type RuleEnforcement = 'Disqualification' | 'Match Forfeit' | 'Point Deduction' | 'Mandatory';

export interface TournamentRule {
  id: string;
  code: string;
  category: RuleCategory;
  title: string;
  description: string;
  enforcement: RuleEnforcement;
}

export interface ReportingStep {
  step: string;
  title: string;
  detail: string;
}

export const RULE_CATEGORY_LABELS: Record<RuleFilter, string> = {
  all: 'All Rules',
  fair_play: 'Fair Play',
  device: 'Device Restrictions',
  reporting: 'Reporting Procedures',
};

export const DEFAULT_TOURNAMENT_RULES: TournamentRule[] = [
  {
    id: 'fp-anti-cheat',
    code: 'FP-01',
    category: 'fair_play',
    title: 'Zero Third-Party Software & Config Mods',
    description:
      'Aimbots, wallhacks, antenna files, OBB/script edits, GFX boosters, and macro tools are strictly banned across all lobbies.',
    enforcement: 'Disqualification',
  },
  {
    id: 'fp-collusion',
    code: 'FP-02',
    category: 'fair_play',
    title: 'No Teaming, Ghosting, or Stream Sniping',
    description:
      'Cross-squad cooperation, intentional feeding, or using external live streams and spectator feeds to track opponents is prohibited.',
    enforcement: 'Match Forfeit',
  },
  {
    id: 'fp-glitches',
    code: 'FP-03',
    category: 'fair_play',
    title: 'No Map Glitches or Out-of-Bounds Exploits',
    description:
      'Entering clipped terrain, invisible roof spots, or abusing healing/character bugs to survive outside the safe zone is forbidden.',
    enforcement: 'Point Deduction',
  },
  {
    id: 'fp-roster',
    code: 'FP-04',
    category: 'fair_play',
    title: 'Locked Roster & Registered UID Integrity',
    description:
      'Every player entering the custom room must match the registered Free Fire UID on the team card. Unapproved ringers forfeit all match points.',
    enforcement: 'Match Forfeit',
  },
  {
    id: 'fp-etiquette',
    code: 'FP-05',
    category: 'fair_play',
    title: 'Lobby Punctuality & Slot Discipline',
    description:
      'Confirmed squads must join their assigned slot at least 5 minutes before drop. Slot-hopping or abusive lobby chat triggers immediate kick.',
    enforcement: 'Mandatory',
  },
  {
    id: 'dv-mobile-only',
    code: 'DV-01',
    category: 'device',
    title: 'Handheld Smartphones Only (No Emulators)',
    description:
      'Matches are strictly mobile-only. PC emulators including BlueStacks, MSI App Player, LDPlayer, Nox, and GameLoop are strictly prohibited.',
    enforcement: 'Disqualification',
  },
  {
    id: 'dv-peripherals',
    code: 'DV-02',
    category: 'device',
    title: 'No External Triggers, Mouse, or Keyboard Adapters',
    description:
      'Physical L1/R1 clip-on triggers, XIM/Bluetooth mouse-keyboard converters, and external controller mappers are banned.',
    enforcement: 'Disqualification',
  },
  {
    id: 'dv-tablets',
    code: 'DV-03',
    category: 'device',
    title: 'No Tablets or iPad Field-of-View Advantage',
    description:
      'iPads and Android tablets are not permitted in standard mobile scrims to preserve uniform viewport and recoil fairness.',
    enforcement: 'Match Forfeit',
  },
  {
    id: 'dv-network-os',
    code: 'DV-04',
    category: 'device',
    title: 'Unmodified OS & No VPN / Lag Manipulation',
    description:
      'Rooted/jailbroken system overlays, DNS/VPN ping spoofers, and intentional packet-drop switches are prohibited.',
    enforcement: 'Disqualification',
  },
  {
    id: 'rp-pov-retention',
    code: 'RP-01',
    category: 'reporting',
    title: 'Mandatory 24-Hour Match POV Retention',
    description:
      'All captains and flagged players must keep full-match screen recordings (720p+ with touch/HUD visible) for 24 hours after the lobby ends.',
    enforcement: 'Match Forfeit',
  },
  {
    id: 'rp-evidence',
    code: 'RP-02',
    category: 'reporting',
    title: 'Required Evidence for Rule & Cheat Reports',
    description:
      'Every report must include the accused player IGN, Free Fire UID, exact match timestamp, and an unedited video clip or death-cam recording.',
    enforcement: 'Mandatory',
  },
  {
    id: 'rp-deadline',
    code: 'RP-03',
    category: 'reporting',
    title: '20-Minute Post-Match Filing Window',
    description:
      'Violations, emulator suspicion, and scoring disputes must be submitted within 20 minutes of match completion before standings lock.',
    enforcement: 'Mandatory',
  },
  {
    id: 'rp-good-faith',
    code: 'RP-04',
    category: 'reporting',
    title: 'Verified Good-Faith Reporting Standard',
    description:
      'Submitting doctored clips, cropped screenshots, or repeated baseless accusations carries a strike and point deduction penalty.',
    enforcement: 'Point Deduction',
  },
];

export const REPORTING_STEPS: ReportingStep[] = [
  {
    step: '01',
    title: 'Capture Unedited Clip',
    detail: 'Save a 720p+ screen recording showing the kill feed, spectator view, or score discrepancy.',
  },
  {
    step: '02',
    title: 'Log Offender UID & Time',
    detail: 'Note the exact Free Fire UID (8–12 digits), team slot, and match time of the incident.',
  },
  {
    step: '03',
    title: 'File Within 20 Minutes',
    detail: 'Send the completed report template and video link to the room organizer before points finalize.',
  },
  {
    step: '04',
    title: 'Admin POV Audit & Ruling',
    detail: 'Organizers may request a 10-minute hand-cam or full POV from the accused squad before issuing penalties.',
  },
];

export function filterTournamentRules(
  rules: TournamentRule[],
  category: RuleFilter,
  searchQuery = ''
): TournamentRule[] {
  const q = searchQuery.trim().toLowerCase();
  return rules.filter((rule) => {
    if (category !== 'all' && rule.category !== category) {
      return false;
    }
    if (!q) return true;
    return (
      rule.title.toLowerCase().includes(q) ||
      rule.description.toLowerCase().includes(q) ||
      rule.code.toLowerCase().includes(q) ||
      rule.enforcement.toLowerCase().includes(q)
    );
  });
}

export function countRulesByCategory(rules: TournamentRule[]): Record<RuleFilter, number> {
  const counts: Record<RuleFilter, number> = {
    all: rules.length,
    fair_play: 0,
    device: 0,
    reporting: 0,
  };
  for (const rule of rules) {
    counts[rule.category] += 1;
  }
  return counts;
}

export function normalizeCustomScrimRules(customRules: string[]): string[] {
  const seen = new Set<string>();
  const cleaned: string[] = [];
  for (const raw of customRules) {
    const trimmed = raw.trim();
    if (!trimmed) continue;
    const key = trimmed.toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key);
    cleaned.push(trimmed);
  }
  return cleaned;
}

export function buildDisputeReportTemplate(scrimTitle: string, map: string, mode: string): string {
  return [
    `SX SCRIM ZONE — Match Violation / Dispute Report`,
    `Scrim: ${scrimTitle} (${map} · ${mode})`,
    `Reporting Team & Captain UID:`,
    `Accused Team / Player IGN:`,
    `Accused Free Fire UID (8-12 digits):`,
    `Violation Type (Emulator / Cheat / Teaming / Glitch / Score):`,
    `Match Time / Kill Feed Timestamp:`,
    `Unedited Proof Clip URL (720p+):`,
    `Brief Description:`,
  ].join('\n');
}
