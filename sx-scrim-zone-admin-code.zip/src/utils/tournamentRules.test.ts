import test from 'node:test';
import assert from 'node:assert/strict';
import {
  DEFAULT_TOURNAMENT_RULES,
  buildDisputeReportTemplate,
  countRulesByCategory,
  filterTournamentRules,
  normalizeCustomScrimRules,
} from './tournamentRules';

test('countRulesByCategory counts all categories accurately', () => {
  const counts = countRulesByCategory(DEFAULT_TOURNAMENT_RULES);
  assert.equal(counts.all, DEFAULT_TOURNAMENT_RULES.length);
  assert.equal(counts.fair_play + counts.device + counts.reporting, counts.all);
  assert.ok(counts.fair_play >= 4);
  assert.ok(counts.device >= 3);
  assert.ok(counts.reporting >= 3);
});

test('filterTournamentRules filters by category and search query', () => {
  const deviceRules = filterTournamentRules(DEFAULT_TOURNAMENT_RULES, 'device');
  assert.ok(deviceRules.length > 0);
  assert.ok(deviceRules.every((r) => r.category === 'device'));

  const emulatorSearch = filterTournamentRules(DEFAULT_TOURNAMENT_RULES, 'all', 'emulator');
  assert.equal(emulatorSearch.length, 2);
  assert.ok(emulatorSearch.some((r) => r.code === 'DV-01'));

  const bluestacksSearch = filterTournamentRules(DEFAULT_TOURNAMENT_RULES, 'all', 'bluestacks');
  assert.equal(bluestacksSearch.length, 1);
  assert.equal(bluestacksSearch[0].code, 'DV-01');

  const noMatch = filterTournamentRules(DEFAULT_TOURNAMENT_RULES, 'reporting', 'bluestacks');
  assert.equal(noMatch.length, 0);
});

test('normalizeCustomScrimRules trims blanks and deduplicates case-insensitively', () => {
  const normalized = normalizeCustomScrimRules([
    '  Mobile only, no emulators.  ',
    '',
    'mobile only, no emulators.',
    'Join room 5 minutes prior.',
  ]);
  assert.deepEqual(normalized, [
    'Mobile only, no emulators.',
    'Join room 5 minutes prior.',
  ]);
});

test('buildDisputeReportTemplate embeds scrim metadata and required fields', () => {
  const template = buildDisputeReportTemplate('Night Ops Bermuda', 'Bermuda', 'Squad');
  assert.ok(template.includes('Night Ops Bermuda'));
  assert.ok(template.includes('Bermuda · Squad'));
  assert.ok(template.includes('Accused Free Fire UID'));
  assert.ok(template.includes('Unedited Proof Clip URL'));
});
