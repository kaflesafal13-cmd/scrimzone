import test from 'node:test';
import assert from 'node:assert/strict';
import { calculateTeamPoints, DEFAULT_POINTS_SYSTEM, sortLeaderboard } from './scoring';

test('calculateTeamPoints computes placement and kill points accurately', () => {
  const booyah = calculateTeamPoints(1, 8, DEFAULT_POINTS_SYSTEM);
  assert.equal(booyah.placementPoints, 12);
  assert.equal(booyah.killPoints, 8);
  assert.equal(booyah.totalPoints, 20);

  const fifth = calculateTeamPoints(5, 4, DEFAULT_POINTS_SYSTEM);
  assert.equal(fifth.placementPoints, 6);
  assert.equal(fifth.totalPoints, 10);
});

test('sortLeaderboard breaks ties by placement then kills', () => {
  const sorted = sortLeaderboard([
    { id: '2', scrimId: 's1', teamName: 'Team B', placement: 2, kills: 7, totalPoints: 16, prizePaid: false },
    { id: '1', scrimId: 's1', teamName: 'Team A', placement: 1, kills: 4, totalPoints: 16, prizePaid: false },
    { id: '3', scrimId: 's1', teamName: 'Team C', placement: 3, kills: 12, totalPoints: 20, prizePaid: false },
  ]);
  assert.deepEqual(
    sorted.map((r) => r.teamName),
    ['Team C', 'Team A', 'Team B']
  );
});
