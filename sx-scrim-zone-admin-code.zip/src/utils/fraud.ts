import { AIPaymentAnalysis, FraudLayer, PaymentHash, PaymentMethod } from '../types';

export const DHASH_HAMMING_THRESHOLD = 6;
export const PAYMENT_RECENCY_WINDOW_MS = 30 * 60 * 1000;
export const FUTURE_CLOCK_SKEW_MS = 5 * 60 * 1000;

export function normalizeTransactionId(txnId: string): string {
  return txnId.trim().toUpperCase().replace(/\s+/g, '');
}

export function normalizeAccountToken(value: string): string {
  return value.trim().toLowerCase().replace(/[^a-z0-9]/g, '');
}

export function buildPaymentComboKey(amount: number, senderName: string, dateTime: string): string {
  const amt = Math.round(amount * 100) / 100;
  const sender = normalizeAccountToken(senderName || 'unknown');
  const dt = dateTime.trim().toLowerCase().replace(/\s+/g, '');
  return `${amt}|${sender}|${dt}`;
}

export function hammingDistanceHex(hexA: string, hexB: string): number {
  if (!hexA || !hexB || hexA.length !== hexB.length) {
    return 64;
  }
  let distance = 0;
  for (let i = 0; i < hexA.length; i++) {
    const a = parseInt(hexA[i], 16);
    const b = parseInt(hexB[i], 16);
    if (Number.isNaN(a) || Number.isNaN(b)) return 64;
    let xor = a ^ b;
    while (xor > 0) {
      distance += xor & 1;
      xor >>= 1;
    }
  }
  return distance;
}

export interface DuplicateCheckInput {
  sha256: string;
  dHash: string;
  transactionId?: string;
  amount?: number;
  senderName?: string;
  dateTime?: string;
  existingHashes: Pick<PaymentHash, 'type' | 'value' | 'dHash' | 'userId'>[];
  recentUserAttemptTimestampsMs?: number[];
  nowMs?: number;
}

export interface DuplicateCheckResult {
  blocked: boolean;
  layer?: FraudLayer;
  reason?: string;
}

export function checkDuplicatePayment(input: DuplicateCheckInput): DuplicateCheckResult {
  const now = input.nowMs ?? Date.now();
  const recentAttempts = (input.recentUserAttemptTimestampsMs ?? []).filter(
    (ts) => now - ts <= 10 * 60 * 1000
  );
  if (recentAttempts.length >= 5) {
    return {
      blocked: true,
      layer: 'rate_limit',
      reason: 'Rate limit exceeded: too many payment verification attempts in 10 minutes.',
    };
  }

  for (const h of input.existingHashes) {
    if (h.type === 'sha256' && h.value === input.sha256) {
      return {
        blocked: true,
        layer: 'sha256',
        reason: 'This screenshot or transaction was already used (exact file match).',
      };
    }
    if (h.type === 'dhash' && h.dHash && hammingDistanceHex(h.dHash, input.dHash) <= DHASH_HAMMING_THRESHOLD) {
      return {
        blocked: true,
        layer: 'dhash',
        reason: 'This screenshot or transaction was already used (visually duplicate receipt).',
      };
    }
  }

  if (input.transactionId && input.transactionId.trim().length > 0) {
    const normTxn = normalizeTransactionId(input.transactionId);
    const txnMatch = input.existingHashes.find((h) => h.type === 'txnid' && h.value === normTxn);
    if (txnMatch) {
      return {
        blocked: true,
        layer: 'transaction_id',
        reason: 'This screenshot or transaction was already used (duplicate transaction ID).',
      };
    }
  }

  if (
    typeof input.amount === 'number' &&
    input.amount > 0 &&
    input.senderName &&
    input.senderName.trim().length > 0 &&
    input.dateTime &&
    input.dateTime.trim().length > 0
  ) {
    const combo = buildPaymentComboKey(input.amount, input.senderName, input.dateTime);
    if (input.existingHashes.some((h) => h.type === 'combo' && h.value === combo)) {
      return {
        blocked: true,
        layer: 'combo',
        reason: 'This screenshot or transaction was already used (duplicate amount, sender & time).',
      };
    }
  }

  return { blocked: false };
}

export function receiverMatchesConfiguredAccounts(
  extractedReceiver: string,
  methods: Pick<PaymentMethod, 'accountName' | 'accountNumber' | 'name' | 'enabled'>[]
): boolean {
  const normExtracted = normalizeAccountToken(extractedReceiver);
  if (!normExtracted) return false;

  const activeMethods = methods.filter((m) => m.enabled);
  for (const m of activeMethods) {
    const normName = normalizeAccountToken(m.accountName);
    const normNumber = normalizeAccountToken(m.accountNumber);
    if (normName && (normExtracted.includes(normName) || normName.includes(normExtracted))) {
      return true;
    }
    if (normNumber && normNumber.length >= 4 && (normExtracted.includes(normNumber) || normNumber.includes(normExtracted))) {
      return true;
    }
  }
  return false;
}

export function parsePaymentDateTimeMs(dateTimeStr: string): number | null {
  if (!dateTimeStr || !dateTimeStr.trim()) return null;
  const direct = Date.parse(dateTimeStr);
  if (!Number.isNaN(direct)) return direct;
  return null;
}

export type VerificationDecision =
  | { decision: 'auto_approved'; reason: string }
  | { decision: 'manual_review'; reason: string }
  | { decision: 'auto_rejected'; reason: string }
  | { decision: 'fraud_duplicate'; layer: FraudLayer; reason: string };

export interface AutoApprovalInput {
  ai: AIPaymentAnalysis;
  expectedAmount: number;
  configuredMethods: Pick<PaymentMethod, 'accountName' | 'accountNumber' | 'name' | 'enabled'>[];
  registrationOpensAtISO: string;
  uploadTimestampMs: number;
  existingHashes: Pick<PaymentHash, 'type' | 'value' | 'dHash' | 'userId'>[];
  sha256: string;
  dHash: string;
}

export function evaluateAutoApproval(input: AutoApprovalInput): VerificationDecision {
  const { ai, expectedAmount, configuredMethods, registrationOpensAtISO, uploadTimestampMs, existingHashes } = input;

  // Duplicate check on extracted transaction ID & combo
  const dup = checkDuplicatePayment({
    sha256: input.sha256,
    dHash: input.dHash,
    transactionId: ai.transaction_id,
    amount: ai.amount,
    senderName: ai.sender_name,
    dateTime: ai.date_time,
    existingHashes,
    nowMs: uploadTimestampMs,
  });

  if (dup.blocked && dup.layer) {
    return {
      decision: 'fraud_duplicate',
      layer: dup.layer,
      reason: dup.reason ?? 'This screenshot or transaction was already used.',
    };
  }

  if (!ai.is_payment_screenshot) {
    return {
      decision: 'auto_rejected',
      reason: 'Uploaded image is not a valid payment receipt screenshot.',
    };
  }

  if (ai.tampering_suspected) {
    return {
      decision: 'auto_rejected',
      reason: 'Possible receipt tampering detected. Please upload an unedited original screenshot.',
    };
  }

  if (ai.status === 'failed') {
    return {
      decision: 'auto_rejected',
      reason: 'Payment status on the receipt shows Failed.',
    };
  }

  if (ai.amount < expectedAmount) {
    return {
      decision: 'auto_rejected',
      reason: `Paid amount (${ai.amount}) is less than the scrim entry fee (${expectedAmount}).`,
    };
  }

  if (ai.confidence < 60) {
    return {
      decision: 'auto_rejected',
      reason: 'Receipt image is too blurry or missing required payment details (confidence below 60%).',
    };
  }

  const receiverOk = receiverMatchesConfiguredAccounts(ai.receiver_name_or_number, configuredMethods);
  const txnOk = normalizeTransactionId(ai.transaction_id).length >= 4;
  const parsedTimeMs = parsePaymentDateTimeMs(ai.date_time);
  const opensAtMs = Date.parse(registrationOpensAtISO);

  let timeRecentAndAfterOpen = false;
  let timeTooOld = false;
  if (parsedTimeMs !== null) {
    const afterOpen = Number.isNaN(opensAtMs) || parsedTimeMs >= opensAtMs;
    const ageMs = uploadTimestampMs - parsedTimeMs;
    const withinWindow = ageMs <= PAYMENT_RECENCY_WINDOW_MS && ageMs >= -FUTURE_CLOCK_SKEW_MS;
    timeRecentAndAfterOpen = afterOpen && withinWindow;
    if (ageMs > PAYMENT_RECENCY_WINDOW_MS || (!Number.isNaN(opensAtMs) && parsedTimeMs < opensAtMs)) {
      timeTooOld = true;
    }
  }

  if (timeTooOld) {
    return {
      decision: 'auto_rejected',
      reason: 'Payment timestamp is outside the active scrim window (older than 30 minutes or before registration opened).',
    };
  }

  if (
    ai.status === 'success' &&
    ai.confidence >= 85 &&
    !ai.tampering_suspected &&
    ai.amount >= expectedAmount &&
    receiverOk &&
    txnOk &&
    timeRecentAndAfterOpen
  ) {
    return {
      decision: 'auto_approved',
      reason: 'All verification checks passed. Slot confirmed automatically.',
    };
  }

  // Confidence 60-84 or partially unclear fields -> Admin Manual Review queue
  const reasons: string[] = [];
  if (ai.confidence < 85) reasons.push(`AI confidence ${ai.confidence}% (< 85%)`);
  if (ai.status !== 'success') reasons.push(`payment status "${ai.status}"`);
  if (!receiverOk) reasons.push('receiver account could not be matched automatically');
  if (!txnOk) reasons.push('transaction ID missing or unclear');
  if (!timeRecentAndAfterOpen) reasons.push('payment timestamp could not be verified within 30 minutes');

  return {
    decision: 'manual_review',
    reason: `Sent to organizer manual review: ${reasons.join('; ')}.`,
  };
}
