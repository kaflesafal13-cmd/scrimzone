import { SCHEMA_LIMITS } from '../types';

const PBKDF2_ITERATIONS = 10000;
const HASH_PREFIX = 'v1';

function toHex(bytes: Uint8Array): string {
  return Array.from(bytes)
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');
}

function fromHex(hex: string): Uint8Array | null {
  if (!/^[0-9a-f]+$/i.test(hex) || hex.length % 2 !== 0) return null;
  const out = new Uint8Array(hex.length / 2);
  for (let i = 0; i < hex.length; i += 2) {
    out[i / 2] = parseInt(hex.slice(i, i + 2), 16);
  }
  return out;
}

function constantTimeEqualHex(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) {
    diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  }
  return diff === 0;
}

export function validateTeamPassword(password: string): { valid: boolean; error?: string } {
  const trimmed = password.trim();
  if (trimmed.length < SCHEMA_LIMITS.TEAM_PASSWORD_MIN) {
    return {
      valid: false,
      error: `Team password must be at least ${SCHEMA_LIMITS.TEAM_PASSWORD_MIN} characters.`,
    };
  }
  if (trimmed.length > SCHEMA_LIMITS.TEAM_PASSWORD_MAX) {
    return {
      valid: false,
      error: `Team password cannot exceed ${SCHEMA_LIMITS.TEAM_PASSWORD_MAX} characters.`,
    };
  }
  return { valid: true };
}

async function derivePbkdf2Hex(password: string, saltBytes: Uint8Array): Promise<string> {
  const cryptoObj = globalThis.crypto;
  if (!cryptoObj?.subtle) {
    throw new Error('Web Crypto API is unavailable in this environment.');
  }
  const enc = new TextEncoder();
  const keyMaterial = await cryptoObj.subtle.importKey(
    'raw',
    enc.encode(password),
    'PBKDF2',
    false,
    ['deriveBits']
  );
  const derivedBits = await cryptoObj.subtle.deriveBits(
    {
      name: 'PBKDF2',
      salt: saltBytes as BufferSource,
      iterations: PBKDF2_ITERATIONS,
      hash: 'SHA-256',
    },
    keyMaterial,
    256
  );
  return toHex(new Uint8Array(derivedBits));
}

export async function hashTeamPassword(password: string): Promise<string> {
  const trimmed = password.trim();
  const check = validateTeamPassword(trimmed);
  if (!check.valid) {
    throw new Error(check.error || 'Invalid team password.');
  }
  const salt = new Uint8Array(16);
  globalThis.crypto.getRandomValues(salt);
  const derivedHex = await derivePbkdf2Hex(trimmed, salt);
  return `${HASH_PREFIX}$${toHex(salt)}$${derivedHex}`;
}

export async function verifyTeamPassword(password: string, storedHash: string): Promise<boolean> {
  if (!password || !storedHash) return false;
  const parts = storedHash.split('$');
  if (parts.length !== 3 || parts[0] !== HASH_PREFIX) return false;
  const [, saltHex, expectedHex] = parts;
  const saltBytes = fromHex(saltHex);
  if (!saltBytes || saltBytes.length !== 16 || expectedHex.length !== 64) return false;
  const candidateHex = await derivePbkdf2Hex(password.trim(), saltBytes);
  return constantTimeEqualHex(candidateHex, expectedHex);
}
