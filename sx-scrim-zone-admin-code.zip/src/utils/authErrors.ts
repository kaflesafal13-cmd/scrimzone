export interface FriendlyAuthError {
  code: string;
  title: string;
  message: string;
}

const POPUP_FALLBACK_CODES = new Set([
  'auth/popup-blocked',
  'auth/popup-closed-by-user',
  'auth/cancelled-popup-request',
]);

export function extractFirebaseErrorCode(err: unknown): string {
  if (err && typeof err === 'object' && 'code' in err && typeof (err as { code?: unknown }).code === 'string') {
    return (err as { code: string }).code;
  }
  if (err instanceof Error) {
    const match = err.message.match(/\((auth\/[a-z0-9-]+)\)/i);
    if (match?.[1]) {
      return match[1].toLowerCase();
    }
  }
  return 'auth/unknown';
}

export function shouldFallbackToRedirect(err: unknown): boolean {
  const code = extractFirebaseErrorCode(err);
  return POPUP_FALLBACK_CODES.has(code);
}

export function mapFirebaseAuthError(err: unknown): FriendlyAuthError {
  const code = extractFirebaseErrorCode(err);

  switch (code) {
    case 'auth/unauthorized-domain':
      return {
        code,
        title: 'Domain Not Authorized',
        message: 'This domain is not authorized. Add it in Firebase Authentication > Settings > Authorized domains.',
      };
    case 'auth/popup-blocked':
      return {
        code,
        title: 'Popup Blocked',
        message: 'Popup was blocked. Redirecting you to sign in instead.',
      };
    case 'auth/popup-closed-by-user':
      return {
        code,
        title: 'Sign-In Popup Closed',
        message: 'Popup was closed before completing sign-in. Redirecting you to sign in instead.',
      };
    case 'auth/cancelled-popup-request':
      return {
        code,
        title: 'Popup Interrupted',
        message: 'Popup sign-in was interrupted. Redirecting you to sign in instead.',
      };
    case 'auth/network-request-failed':
      return {
        code,
        title: 'Network Error',
        message: 'Network error. Check your internet and try again.',
      };
    case 'auth/invalid-credential':
      return {
        code,
        title: 'Invalid Credentials',
        message: 'Incorrect email or password. Double-check your details or reset your password.',
      };
    case 'auth/user-not-found':
      return {
        code,
        title: 'Account Not Found',
        message: 'No captain account exists with this email address. Create an account to continue.',
      };
    case 'auth/wrong-password':
      return {
        code,
        title: 'Wrong Password',
        message: 'The password you entered is incorrect. Try again or use Forgot password.',
      };
    case 'auth/email-already-in-use':
      return {
        code,
        title: 'Email Already Registered',
        message: 'An account with this email already exists. Sign in or reset your password instead.',
      };
    case 'auth/too-many-requests':
      return {
        code,
        title: 'Too Many Attempts',
        message: 'Too many unsuccessful attempts. Wait a few minutes before trying again.',
      };
    case 'auth/account-exists-with-different-credential':
      return {
        code,
        title: 'Different Sign-In Method Used',
        message: 'An account already exists with this email using a different sign-in method. Sign in with your original method.',
      };
    case 'auth/operation-not-allowed':
      return {
        code,
        title: 'Provider Disabled',
        message: 'This sign-in method is not enabled in Firebase Authentication > Sign-in method.',
      };
    case 'auth/weak-password':
      return {
        code,
        title: 'Weak Password',
        message: 'Choose a stronger password with at least 6 characters.',
      };
    case 'auth/invalid-email':
      return {
        code,
        title: 'Invalid Email',
        message: 'Enter a valid email address.',
      };
    case 'auth/user-disabled':
      return {
        code,
        title: 'Account Disabled',
        message: 'This account has been disabled. Contact tournament support.',
      };
    default:
      return {
        code,
        title: 'Authentication Failed',
        message:
          err instanceof Error && err.message && !err.message.startsWith('Firebase:')
            ? err.message
            : 'Unable to complete authentication right now. Please try again.',
      };
  }
}
