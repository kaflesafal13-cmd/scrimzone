import test from 'node:test';
import assert from 'node:assert/strict';
import {
  checkDuplicatePayment,
  evaluateAutoApproval,
  hammingDistanceHex,
  normalizeTransactionId,
} from './fraud';

test('normalizeTransactionId strips whitespace and uppercases', () => {
  assert.equal(normalizeTransactionId(' txN 9981 aB '), 'TXN9981AB');
});

test('hammingDistanceHex accurately measures bit distance', () => {
  assert.equal(hammingDistanceHex('0000000000000000', '0000000000000000'), 0);
  assert.equal(hammingDistanceHex('000000000000000f', '0000000000000000'), 4);
  assert.equal(hammingDistanceHex('ffffffffffffffff', '0000000000000000'), 64);
});

test('checkDuplicatePayment blocks SHA-256, dHash, TxnID, combo, and rate limits', () => {
  const existingHashes = [
    { type: 'sha256' as const, value: 'abc123', userId: 'u1' },
    { type: 'dhash' as const, value: 'd1', dHash: 'aaaaaaaaaaaaaaaa', userId: 'u1' },
    { type: 'txnid' as const, value: 'ESEWA990011', userId: 'u1' },
    { type: 'combo' as const, value: '200|ramsharma|2026-11-26t20:00:00z', userId: 'u1' },
  ];

  // Exact SHA-256
  const shaDup = checkDuplicatePayment({
    sha256: 'abc123',
    dHash: '0000000000000000',
    existingHashes,
  });
  assert.equal(shaDup.blocked, true);
  assert.equal(shaDup.layer, 'sha256');

  // Near-identical dHash (1 bit difference)
  const dhashDup = checkDuplicatePayment({
    sha256: 'other',
    dHash: 'aaaaaaaaaaaaaaab',
    existingHashes,
  });
  assert.equal(dhashDup.blocked, true);
  assert.equal(dhashDup.layer, 'dhash');

  // Duplicate transaction ID with spaces/lowercase
  const txnDup = checkDuplicatePayment({
    sha256: 'other',
    dHash: '0000000000000000',
    transactionId: ' esewa 990011 ',
    existingHashes,
  });
  assert.equal(txnDup.blocked, true);
  assert.equal(txnDup.layer, 'transaction_id');

  // Duplicate combo
  const comboDup = checkDuplicatePayment({
    sha256: 'other',
    dHash: '0000000000000000',
    amount: 200,
    senderName: 'Ram Sharma',
    dateTime: '2026-11-26T20:00:00Z',
    existingHashes,
  });
  assert.equal(comboDup.blocked, true);
  assert.equal(comboDup.layer, 'combo');
});

test('evaluateAutoApproval routes auto_approved, manual_review, and auto_rejected accurately', () => {
  const nowMs = Date.parse('2026-11-26T21:45:00Z');
  const openISO = '2026-11-26T18:00:00Z';
  const configuredMethods = [
    { name: 'eSewa Official', accountName: 'SX Esports', accountNumber: '9801234567', enabled: true },
  ];

  // Auto-approve when all criteria pass
  const approved = evaluateAutoApproval({
    ai: {
      is_payment_screenshot: true,
      amount: 200,
      currency: 'NPR',
      transaction_id: 'ESW778899',
      receiver_name_or_number: '9801234567',
      sender_name: 'Kiran Thapa',
      date_time: '2026-11-26T21:35:00Z',
      status: 'success',
      tampering_suspected: false,
      confidence: 95,
    },
    expectedAmount: 200,
    configuredMethods,
    registrationOpensAtISO: openISO,
    uploadTimestampMs: nowMs,
    existingHashes: [],
    sha256: 'new_sha',
    dHash: '1111111111111111',
  });
  assert.equal(approved.decision, 'auto_approved');

  // Manual review when confidence is 75
  const review = evaluateAutoApproval({
    ai: {
      is_payment_screenshot: true,
      amount: 200,
      currency: 'NPR',
      transaction_id: 'ESW778800',
      receiver_name_or_number: 'SX Esports',
      sender_name: 'Kiran Thapa',
      date_time: '2026-11-26T21:35:00Z',
      status: 'success',
      tampering_suspected: false,
      confidence: 75,
    },
    expectedAmount: 200,
    configuredMethods,
    registrationOpensAtISO: openISO,
    uploadTimestampMs: nowMs,
    existingHashes: [],
    sha256: 'new_sha_2',
    dHash: '2222222222222222',
  });
  assert.equal(review.decision, 'manual_review');

  // Auto-reject when amount < entry fee
  const underpaid = evaluateAutoApproval({
    ai: {
      is_payment_screenshot: true,
      amount: 100,
      currency: 'NPR',
      transaction_id: 'ESW778811',
      receiver_name_or_number: '9801234567',
      sender_name: 'Kiran Thapa',
      date_time: '2026-11-26T21:35:00Z',
      status: 'success',
      tampering_suspected: false,
      confidence: 96,
    },
    expectedAmount: 200,
    configuredMethods,
    registrationOpensAtISO: openISO,
    uploadTimestampMs: nowMs,
    existingHashes: [],
    sha256: 'new_sha_3',
    dHash: '3333333333333333',
  });
  assert.equal(underpaid.decision, 'auto_rejected');
});
