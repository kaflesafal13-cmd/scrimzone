import test from 'node:test';
import assert from 'node:assert/strict';
import { isValidUid, validateTeamRoster } from './validation';

test('isValidUid accepts 8-12 numeric digits and rejects invalid UIDs', () => {
  assert.equal(isValidUid('12345678'), true);
  assert.equal(isValidUid('987654321012'), true);
  assert.equal(isValidUid('1234567'), false);
  assert.equal(isValidUid('1234567890123'), false);
  assert.equal(isValidUid('1234abcd'), false);
});

test('validateTeamRoster blocks duplicate UIDs within team and across scrim', () => {
  const existingRosters = [
    {
      registrationId: 'reg-1',
      teamNameNormalized: 'apex predators',
      playerUids: ['11112222', '33334444'],
    },
  ];

  // Duplicate team name
  const dupName = validateTeamRoster({
    teamName: 'Apex Predators',
    captainName: 'SX_Ghost',
    captainUid: '55556666',
    captainPhone: '+9779800001111',
    mode: 'Duo',
    players: [
      { ign: 'SX_Ghost', uid: '55556666', role: 'Captain' },
      { ign: 'SX_Viper', uid: '77778888', role: 'Rusher' },
    ],
    existingRosters,
  });
  assert.equal(dupName.valid, false);
  assert.ok(dupName.errors.teamName);

  // Duplicate UID in same scrim
  const dupScrimUid = validateTeamRoster({
    teamName: 'Nova Strike',
    captainName: 'SX_Ghost',
    captainUid: '55556666',
    captainPhone: '+9779800001111',
    mode: 'Duo',
    players: [
      { ign: 'SX_Ghost', uid: '55556666', role: 'Captain' },
      { ign: 'SX_Viper', uid: '33334444', role: 'Rusher' },
    ],
    existingRosters,
  });
  assert.equal(dupScrimUid.valid, false);
  assert.ok(dupScrimUid.errors.player_1_uid);

  // Duplicate UID inside same team
  const dupTeamUid = validateTeamRoster({
    teamName: 'Nova Strike',
    captainName: 'SX_Ghost',
    captainUid: '55556666',
    captainPhone: '+9779800001111',
    mode: 'Duo',
    players: [
      { ign: 'SX_Ghost', uid: '55556666', role: 'Captain' },
      { ign: 'SX_Viper', uid: '55556666', role: 'Rusher' },
    ],
    existingRosters,
  });
  assert.equal(dupTeamUid.valid, false);
  assert.ok(dupTeamUid.errors.player_1_uid);

  // Valid squad with optional substitute empty
  const validSquad = validateTeamRoster({
    teamName: 'Crimson Wolves',
    captainName: 'SX_Alpha',
    captainUid: '22223333',
    captainPhone: '+9779800002222',
    mode: 'Squad',
    players: [
      { ign: 'SX_Alpha', uid: '22223333', role: 'Captain' },
      { ign: 'SX_Bravo', uid: '22224444', role: 'Rusher' },
      { ign: 'SX_Charlie', uid: '22225555', role: 'Sniper' },
      { ign: 'SX_Delta', uid: '22226666', role: 'Support' },
      { ign: '', uid: '', role: 'Substitute' },
    ],
    existingRosters,
  });
  assert.equal(validSquad.valid, true);
});
