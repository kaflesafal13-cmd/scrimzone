import { PlayerEntry, SCHEMA_LIMITS, ScrimMode, ScrimRoster } from '../types';

export function isValidUid(uid: string): boolean {
  return SCHEMA_LIMITS.UID_PATTERN.test(uid.trim());
}

export function isValidPhone(phone: string): boolean {
  const cleaned = phone.replace(/[\s\-()]/g, '');
  return /^\+?[0-9]{7,15}$/.test(cleaned);
}

export function normalizeTeamName(name: string): string {
  return name.trim().toLowerCase().replace(/\s+/g, ' ');
}

export function isValidTeamName(name: string): boolean {
  const trimmed = name.trim();
  return trimmed.length >= SCHEMA_LIMITS.TEAM_NAME_MIN && trimmed.length <= SCHEMA_LIMITS.TEAM_NAME_MAX;
}

export function requiredMainPlayersForMode(mode: ScrimMode): number {
  if (mode === 'Solo') return 1;
  if (mode === 'Duo') return 2;
  return 4;
}

export interface RosterValidationInput {
  teamName: string;
  captainName: string;
  captainUid: string;
  captainPhone: string;
  players: PlayerEntry[];
  mode: ScrimMode;
  existingRosters: Pick<ScrimRoster, 'registrationId' | 'teamNameNormalized' | 'playerUids'>[];
  editingRegistrationId?: string;
}

export interface RosterValidationResult {
  valid: boolean;
  errors: Record<string, string>;
  generalError?: string;
}

export function validateTeamRoster(input: RosterValidationInput): RosterValidationResult {
  const errors: Record<string, string> = {};
  const trimmedTeam = input.teamName.trim();
  const normalizedTeam = normalizeTeamName(trimmedTeam);

  if (!isValidTeamName(trimmedTeam)) {
    errors.teamName = `Team name must be ${SCHEMA_LIMITS.TEAM_NAME_MIN}–${SCHEMA_LIMITS.TEAM_NAME_MAX} characters.`;
  }

  const otherRosters = input.existingRosters.filter(
    (r) => !input.editingRegistrationId || r.registrationId !== input.editingRegistrationId
  );

  if (otherRosters.some((r) => r.teamNameNormalized === normalizedTeam)) {
    errors.teamName = 'This team name is already registered in this scrim.';
  }

  if (input.captainName.trim().length < 2 || input.captainName.trim().length > SCHEMA_LIMITS.PLAYER_NAME_MAX) {
    errors.captainName = 'Captain IGN must be 2–40 characters.';
  }

  if (!isValidUid(input.captainUid)) {
    errors.captainUid = 'Captain UID must be 8–12 numeric digits.';
  }

  if (!isValidPhone(input.captainPhone)) {
    errors.captainPhone = 'Enter a valid WhatsApp / phone number (7–15 digits).';
  }

  const requiredMain = requiredMainPlayersForMode(input.mode);
  const activePlayers = input.players.filter((p) => p.ign.trim().length > 0 || p.uid.trim().length > 0);

  if (activePlayers.length < requiredMain) {
    errors.players = `${input.mode} mode requires at least ${requiredMain} player${requiredMain > 1 ? 's' : ''}.`;
  }

  const seenUids = new Set<string>();
  const existingScrimUids = new Set<string>();
  for (const r of otherRosters) {
    for (const u of r.playerUids) {
      existingScrimUids.add(u.trim());
    }
  }

  input.players.forEach((player, idx) => {
    const isRequiredSlot = idx < requiredMain;
    const hasAnyInput = player.ign.trim().length > 0 || player.uid.trim().length > 0;
    if (!isRequiredSlot && !hasAnyInput) {
      return;
    }

    const ign = player.ign.trim();
    const uid = player.uid.trim();

    if (ign.length < 2 || ign.length > SCHEMA_LIMITS.PLAYER_NAME_MAX) {
      errors[`player_${idx}_ign`] = 'In-game name must be 2–40 characters.';
    }
    if (!isValidUid(uid)) {
      errors[`player_${idx}_uid`] = 'UID must be 8–12 numeric digits.';
    } else {
      if (seenUids.has(uid)) {
        errors[`player_${idx}_uid`] = 'Duplicate UID within your team roster.';
      }
      if (existingScrimUids.has(uid)) {
        errors[`player_${idx}_uid`] = 'This UID is already registered in this scrim.';
      }
      seenUids.add(uid);
    }
  });

  const valid = Object.keys(errors).length === 0;
  return {
    valid,
    errors,
    generalError: valid ? undefined : 'Please fix the highlighted roster validation errors.',
  };
}
