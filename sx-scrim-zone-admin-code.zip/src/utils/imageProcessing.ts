import { Registration, Scrim } from '../types';

export async function computeSha256Hex(file: File | Blob): Promise<string> {
  const buffer = await file.arrayBuffer();
  const hashBuffer = await crypto.subtle.digest('SHA-256', buffer);
  const bytes = new Uint8Array(hashBuffer);
  return Array.from(bytes)
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');
}

export async function loadImageElement(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error('Failed to decode image file.'));
    img.src = src;
  });
}

export async function fileToDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(new Error('Unable to read image file.'));
    reader.readAsDataURL(file);
  });
}

/**
 * Computes a 64-bit Difference Hash (dHash) by resizing to 9x8 grayscale
 * and comparing adjacent horizontal pixel brightness.
 */
export async function computeDHashHex(file: File): Promise<string> {
  const dataUrl = await fileToDataUrl(file);
  const img = await loadImageElement(dataUrl);
  const canvas = document.createElement('canvas');
  canvas.width = 9;
  canvas.height = 8;
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('Canvas 2D context unavailable.');

  ctx.drawImage(img, 0, 0, 9, 8);
  const { data } = ctx.getImageData(0, 0, 9, 8);
  const gray: number[] = [];
  for (let i = 0; i < data.length; i += 4) {
    gray.push(0.299 * data[i] + 0.587 * data[i + 1] + 0.114 * data[i + 2]);
  }

  let bits = '';
  for (let y = 0; y < 8; y++) {
    for (let x = 0; x < 8; x++) {
      const left = gray[y * 9 + x];
      const right = gray[y * 9 + x + 1];
      bits += left > right ? '1' : '0';
    }
  }

  let hex = '';
  for (let i = 0; i < 64; i += 4) {
    hex += parseInt(bits.slice(i, i + 4), 2).toString(16);
  }
  return hex;
}

/**
 * Crops center square (for logos) or preserves aspect ratio (for screenshots)
 * and compresses image to fit safely inside Firestore document bounds.
 */
export async function compressImageToDataUrl(
  file: File,
  options: { maxWidth: number; maxHeight: number; squareCrop?: boolean; quality?: number }
): Promise<{ dataUrl: string; base64: string; mimeType: 'image/jpeg' | 'image/webp' }> {
  const rawUrl = await fileToDataUrl(file);
  const img = await loadImageElement(rawUrl);

  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('Canvas 2D context unavailable.');

  if (options.squareCrop) {
    const side = Math.min(img.width, img.height);
    const sx = (img.width - side) / 2;
    const sy = (img.height - side) / 2;
    canvas.width = options.maxWidth;
    canvas.height = options.maxHeight;
    ctx.drawImage(img, sx, sy, side, side, 0, 0, options.maxWidth, options.maxHeight);
  } else {
    const ratio = Math.min(options.maxWidth / img.width, options.maxHeight / img.height, 1);
    canvas.width = Math.max(1, Math.round(img.width * ratio));
    canvas.height = Math.max(1, Math.round(img.height * ratio));
    ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
  }

  let quality = options.quality ?? 0.82;
  let dataUrl = canvas.toDataURL('image/jpeg', quality);
  // Keep well under 350 KB base64 for Firestore documents
  while (dataUrl.length > 340_000 && quality > 0.35) {
    quality -= 0.1;
    dataUrl = canvas.toDataURL('image/jpeg', quality);
  }

  const base64 = dataUrl.split(',')[1] ?? '';
  return { dataUrl, base64, mimeType: 'image/jpeg' };
}

/**
 * Renders a crisp high-res PNG esports roster card for download.
 */
export async function renderTeamCardPng(registration: Registration, scrim?: Scrim): Promise<string> {
  const canvas = document.createElement('canvas');
  canvas.width = 960;
  canvas.height = 560;
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('Canvas unavailable.');

  // Background gradient
  const grad = ctx.createLinearGradient(0, 0, 960, 560);
  grad.addColorStop(0, '#0A0A0F');
  grad.addColorStop(1, '#161622');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 960, 560);

  // Diagonal tactical stripe accent
  ctx.fillStyle = 'rgba(255, 106, 0, 0.08)';
  ctx.beginPath();
  ctx.moveTo(640, 0);
  ctx.lineTo(960, 0);
  ctx.lineTo(960, 560);
  ctx.lineTo(500, 560);
  ctx.closePath();
  ctx.fill();

  // Border frame
  ctx.strokeStyle = 'rgba(255, 106, 0, 0.5)';
  ctx.lineWidth = 3;
  ctx.strokeRect(18, 18, 924, 524);

  // Top Header
  ctx.fillStyle = '#FF6A00';
  ctx.font = '700 22px Rajdhani, sans-serif';
  ctx.fillText('SX SCRIM ZONE  ·  OFFICIAL TEAM PASS', 44, 62);

  ctx.fillStyle = '#A1A1B5';
  ctx.font = '600 18px "Plus Jakarta Sans", sans-serif';
  const scrimText = scrim ? `${scrim.title} (${scrim.map} · ${scrim.mode})` : (registration.scrimTitle || 'Custom Room Scrim');
  ctx.fillText(scrimText, 44, 94);

  // Status badge text
  const statusLabel =
    registration.status === 'slot_confirmed'
      ? 'SLOT CONFIRMED'
      : registration.status === 'verified'
        ? 'VERIFIED'
        : registration.status === 'rejected'
          ? 'REJECTED'
          : 'PENDING REVIEW';
  ctx.fillStyle = registration.status === 'slot_confirmed' || registration.status === 'verified' ? '#22C55E' : '#F59E0B';
  ctx.font = '700 20px Rajdhani, sans-serif';
  ctx.textAlign = 'right';
  ctx.fillText(statusLabel, 912, 62);
  ctx.textAlign = 'left';

  // Team logo box
  ctx.fillStyle = '#14141C';
  ctx.fillRect(44, 128, 136, 136);
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.14)';
  ctx.lineWidth = 2;
  ctx.strokeRect(44, 128, 136, 136);

  if (registration.teamLogoUrl) {
    try {
      const logo = await loadImageElement(registration.teamLogoUrl);
      ctx.drawImage(logo, 48, 132, 128, 128);
    } catch {
      ctx.fillStyle = '#FF6A00';
      ctx.font = '700 44px Rajdhani, sans-serif';
      ctx.fillText(registration.teamName.slice(0, 2).toUpperCase(), 82, 210);
    }
  } else {
    ctx.fillStyle = '#FF6A00';
    ctx.font = '700 44px Rajdhani, sans-serif';
    ctx.fillText(registration.teamName.slice(0, 2).toUpperCase(), 82, 210);
  }

  // Team name & captain info
  ctx.fillStyle = '#F4F4F7';
  ctx.font = '700 46px Rajdhani, sans-serif';
  ctx.fillText(registration.teamName, 204, 180);

  ctx.fillStyle = '#A1A1B5';
  ctx.font = '500 18px "Plus Jakarta Sans", sans-serif';
  ctx.fillText(`Captain: ${registration.captainName}  ·  UID ${registration.captainUid}`, 204, 218);

  ctx.fillStyle = '#FF6A00';
  ctx.font = '600 16px "JetBrains Mono", monospace';
  ctx.fillText(`PASS CODE: ${registration.shareCode}`, 204, 250);

  // Roster list
  ctx.fillStyle = '#E4E4EB';
  ctx.font = '700 18px Rajdhani, sans-serif';
  ctx.fillText('REGISTERED ROSTER', 44, 314);

  registration.players.slice(0, 5).forEach((p, idx) => {
    const col = idx % 2;
    const row = Math.floor(idx / 2);
    const x = 44 + col * 444;
    const y = 334 + row * 62;

    ctx.fillStyle = '#181822';
    ctx.fillRect(x, y, 424, 50);
    ctx.strokeStyle = 'rgba(255,255,255,0.08)';
    ctx.lineWidth = 1;
    ctx.strokeRect(x, y, 424, 50);

    ctx.fillStyle = '#FF6A00';
    ctx.font = '700 14px "JetBrains Mono", monospace';
    ctx.fillText(`P${idx + 1}`, x + 14, y + 30);

    ctx.fillStyle = '#F4F4F7';
    ctx.font = '600 17px "Plus Jakarta Sans", sans-serif';
    ctx.fillText(p.ign, x + 52, y + 30);

    ctx.fillStyle = '#A1A1B5';
    ctx.font = '500 15px "JetBrains Mono", monospace';
    ctx.textAlign = 'right';
    ctx.fillText(p.uid, x + 408, y + 30);
    ctx.textAlign = 'left';
  });

  // Footer
  ctx.fillStyle = '#73738C';
  ctx.font = '500 14px "Plus Jakarta Sans", sans-serif';
  ctx.fillText('Verified on SX SCRIM ZONE · Present this card or share code at match check-in', 44, 522);

  return canvas.toDataURL('image/png');
}
