import React from 'react';
import { AlertTriangle, RefreshCw } from 'lucide-react';

interface State {
  hasError: boolean;
  message: string;
}

export class ErrorBoundary extends React.Component<{ children: React.ReactNode }, State> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = { hasError: false, message: '' };
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, message: error.message || 'An unexpected error occurred.' };
  }

  componentDidCatch(error: Error) {
    console.error('App ErrorBoundary caught:', error);
  }

  render() {
    if (this.state.hasError) {
      let friendly = this.state.message;
      try {
        const parsed = JSON.parse(this.state.message);
        if (parsed?.error) friendly = parsed.error;
      } catch {
        // plain string message
      }

      return (
        <div className="min-h-screen flex items-center justify-center bg-[#0A0A0F] text-[#F4F4F7] p-6">
          <div className="max-w-md w-full rounded-2xl bg-[#14141C] border border-white/10 p-6 text-center space-y-4">
            <div className="mx-auto w-12 h-12 rounded-xl bg-[#FF2A2A]/15 text-[#FF2A2A] flex items-center justify-center">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <h1 className="text-2xl font-bold font-display tracking-wide">Something went wrong</h1>
            <p className="text-sm text-zinc-400 break-words">{friendly}</p>
            <button
              type="button"
              onClick={() => window.location.reload()}
              className="inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-[#FF6A00] text-white font-semibold text-sm hover:bg-[#e55f00] transition-colors"
            >
              <RefreshCw className="w-4 h-4" />
              Reload SX SCRIM ZONE
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}
