import React, { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';

export const SplashScreen: React.FC<{ onComplete: () => void }> = ({ onComplete }) => {
  const onCompleteRef = useRef(onComplete);
  onCompleteRef.current = onComplete;

  const [visible, setVisible] = useState(() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      if (params.get('autostart') === '1' || params.get('team')) return false;
    }
    return true;
  });

  useEffect(() => {
    if (!visible) {
      onCompleteRef.current();
      return;
    }
    const timer = setTimeout(() => {
      setVisible(false);
      onCompleteRef.current();
    }, 950);
    return () => clearTimeout(timer);
  }, [visible]);

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          initial={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.25 }}
          className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-[#0A0A0F] text-white"
          aria-label="SX SCRIM ZONE Splash Screen"
        >
          <motion.div
            initial={{ scale: 0.85, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
            className="flex flex-col items-center gap-4"
          >
            <div className="relative w-20 h-20 rounded-2xl bg-[#14141C] border border-[#FF6A00]/40 flex items-center justify-center shadow-[0_0_40px_rgba(255,106,0,0.28)]">
              <span className="font-display text-4xl font-bold tracking-wider text-[#FF6A00]">SX</span>
            </div>
            <div className="text-center">
              <p className="font-display text-2xl font-bold tracking-[0.18em] text-white">SX SCRIM ZONE</p>
              <p className="text-xs text-zinc-400 mt-1">Free Fire Custom Rooms &amp; Tournaments</p>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
