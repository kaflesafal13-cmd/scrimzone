import React, { useMemo, useState } from 'react';
import { Copy, FileWarning, ShieldCheck, Smartphone } from 'lucide-react';
import { Scrim } from '../types';
import { useApp } from '../context/AppContext';
import {
  DEFAULT_TOURNAMENT_RULES,
  REPORTING_STEPS,
  RULE_CATEGORY_LABELS,
  RuleCategory,
  RuleEnforcement,
  RuleFilter,
  buildDisputeReportTemplate,
  countRulesByCategory,
  filterTournamentRules,
  normalizeCustomScrimRules,
} from '../utils/tournamentRules';

interface TournamentRulesProps {
  scrim: Scrim;
}

const CATEGORY_ORDER: RuleCategory[] = ['fair_play', 'device', 'reporting'];

const CATEGORY_META: Record<
  RuleCategory,
  { heading: string; summary: string; Icon: React.ComponentType<{ className?: string }> }
> = {
  fair_play: {
    heading: 'Fair-Play Guidelines',
    summary: 'Anti-cheat, roster integrity, and lobby conduct standards.',
    Icon: ShieldCheck,
  },
  device: {
    heading: 'Device Restrictions',
    summary: 'Approved handheld hardware and prohibited input peripherals.',
    Icon: Smartphone,
  },
  reporting: {
    heading: 'Reporting Procedures',
    summary: 'Evidence requirements, POV retention, and dispute deadlines.',
    Icon: FileWarning,
  },
};

function enforcementTextClass(enforcement: RuleEnforcement): string {
  switch (enforcement) {
    case 'Disqualification':
      return 'text-[#FF2A2A]';
    case 'Match Forfeit':
      return 'text-[#FF6A00]';
    case 'Point Deduction':
      return 'text-amber-600 dark:text-amber-400';
    default:
      return 'text-emerald-600 dark:text-emerald-400';
  }
}

export const TournamentRules: React.FC<TournamentRulesProps> = ({ scrim }) => {
  const { pushToast } = useApp();
  const [activeCategory, setActiveCategory] = useState<RuleFilter>('all');

  const categoryCounts = useMemo(() => countRulesByCategory(DEFAULT_TOURNAMENT_RULES), []);
  const customScrimRules = useMemo(() => normalizeCustomScrimRules(scrim.rules || []), [scrim.rules]);

  const visibleCategories = useMemo(
    () => (activeCategory === 'all' ? CATEGORY_ORDER : [activeCategory]),
    [activeCategory]
  );

  const showReportingChecklist = activeCategory === 'all' || activeCategory === 'reporting';

  const handleCopyReportTemplate = async () => {
    const template = buildDisputeReportTemplate(scrim.title, scrim.map, scrim.mode);
    try {
      await navigator.clipboard.writeText(template);
      pushToast({
        type: 'success',
        title: 'Report template copied',
        description: 'Fill in the offender UID, timestamp, and 720p+ clip link before sending.',
      });
    } catch {
      pushToast({
        type: 'error',
        title: 'Clipboard unavailable',
        description: 'Copy failed. Please copy details manually from the checklist.',
      });
    }
  };

  return (
    <section
      aria-label="Tournament Rules"
      className="rounded-2xl bg-white dark:bg-[#14141C] border border-zinc-200 dark:border-white/10 p-6 space-y-6"
    >
      {/* Header & Category Tabs */}
      <div className="space-y-4">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#FF6A00]/15 text-[#FF6A00] flex items-center justify-center shrink-0">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <h2 className="font-display text-xl font-bold text-zinc-900 dark:text-white">
              Tournament Rules
            </h2>
            <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-0.5">
              Free Fire Fair Play · Device Restrictions · Dispute Protocol
            </p>
          </div>
        </div>

        <div
          role="tablist"
          aria-label="Filter tournament rules by section"
          className="inline-flex max-w-full overflow-x-auto items-center gap-1 p-1 rounded-xl bg-zinc-100 dark:bg-[#0A0A0F] border border-zinc-200 dark:border-white/10"
        >
          {(['all', 'fair_play', 'device', 'reporting'] as const).map((tab) => {
            const isSelected = activeCategory === tab;
            const shortLabel =
              tab === 'all'
                ? 'All'
                : tab === 'fair_play'
                  ? 'Fair Play'
                  : tab === 'device'
                    ? 'Devices'
                    : 'Reporting';

            return (
              <button
                key={tab}
                type="button"
                role="tab"
                aria-selected={isSelected}
                onClick={() => setActiveCategory(tab)}
                className={`min-h-[36px] px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 ${
                  isSelected
                    ? 'bg-[#FF6A00] text-white'
                    : 'text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white'
                }`}
              >
                <span>{shortLabel}</span>
                <span
                  className={`font-mono text-[11px] tabular-nums ${
                    isSelected ? 'text-white/90' : 'text-zinc-400 dark:text-zinc-500'
                  }`}
                >
                  {categoryCounts[tab]}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Scrim-Specific Lobby Rules (from organizer config) */}
      {activeCategory === 'all' && customScrimRules.length > 0 && (
        <div className="pt-4 border-t border-zinc-200 dark:border-white/10 space-y-3">
          <div className="flex items-center justify-between gap-2">
            <h3 className="font-display text-base font-bold text-zinc-900 dark:text-white">
              Lobby-Specific Conditions
            </h3>
            <span className="text-xs text-zinc-500 dark:text-zinc-400 tabular-nums">
              {scrim.map} · {scrim.mode}
            </span>
          </div>
          <ul className="divide-y divide-zinc-200/80 dark:divide-white/8">
            {customScrimRules.map((rule, idx) => (
              <li key={idx} className="py-2.5 flex items-start gap-3 text-sm text-zinc-700 dark:text-zinc-300">
                <span className="font-mono text-xs font-bold text-[#FF6A00] tabular-nums mt-0.5 shrink-0">
                  {String(idx + 1).padStart(2, '0')}.
                </span>
                <span>{rule}</span>
              </li>
            ))}
          </ul>
        </div>
      )}

      {/* Structured Rules Sections */}
      <div className="space-y-6">
        {visibleCategories.map((category) => {
          const meta = CATEGORY_META[category];
          const Icon = meta.Icon;
          const items = filterTournamentRules(DEFAULT_TOURNAMENT_RULES, category);

          return (
            <div key={category} className="pt-5 border-t border-zinc-200 dark:border-white/10 space-y-3">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <h3 className="font-display text-lg font-bold text-zinc-900 dark:text-white flex items-center gap-2">
                    <Icon className="w-4 h-4 text-[#FF6A00] shrink-0" />
                    <span>{meta.heading}</span>
                  </h3>
                  <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-0.5">{meta.summary}</p>
                </div>
                <span className="font-mono text-xs text-zinc-500 dark:text-zinc-400 tabular-nums shrink-0">
                  {items.length} {items.length === 1 ? 'rule' : 'rules'}
                </span>
              </div>

              <ul className="divide-y divide-zinc-200/80 dark:divide-white/8">
                {items.map((rule) => (
                  <li key={rule.id} className="py-3.5 first:pt-2 last:pb-1 space-y-1">
                    <div className="flex flex-wrap items-baseline justify-between gap-2">
                      <div className="flex items-baseline gap-2.5 min-w-0">
                        <span className="font-mono text-xs font-bold text-[#FF6A00] tabular-nums shrink-0">
                          {rule.code}
                        </span>
                        <span className="text-sm font-semibold text-zinc-900 dark:text-white">
                          {rule.title}
                        </span>
                      </div>
                      <span
                        className={`text-xs font-semibold whitespace-nowrap ${enforcementTextClass(rule.enforcement)}`}
                      >
                        Penalty: {rule.enforcement}
                      </span>
                    </div>
                    <p className="text-xs sm:text-sm text-zinc-600 dark:text-zinc-400 leading-relaxed pl-0 sm:pl-12">
                      {rule.description}
                    </p>
                  </li>
                ))}
              </ul>
            </div>
          );
        })}
      </div>

      {/* Reporting Workflow & Copyable Template */}
      {showReportingChecklist && (
        <div className="pt-5 border-t border-zinc-200 dark:border-white/10 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h3 className="font-display text-lg font-bold text-zinc-900 dark:text-white">
                How to File a Match Dispute
              </h3>
              <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-0.5">
                Follow all four steps within 20 minutes of match end ({RULE_CATEGORY_LABELS.reporting}).
              </p>
            </div>
            <button
              type="button"
              onClick={handleCopyReportTemplate}
              className="min-h-[40px] px-4 py-2 rounded-xl border border-zinc-200 dark:border-white/15 hover:border-[#FF6A00] text-xs font-semibold text-zinc-900 dark:text-white inline-flex items-center justify-center gap-2 transition-colors whitespace-nowrap shrink-0"
            >
              <Copy className="w-3.5 h-3.5 text-[#FF6A00]" />
              Copy Report Template
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-4">
            {REPORTING_STEPS.map((item) => (
              <div key={item.step} className="flex items-start gap-3">
                <span className="font-mono text-xs font-bold text-[#FF6A00] tabular-nums mt-0.5 shrink-0">
                  {item.step}.
                </span>
                <div>
                  <div className="text-xs font-semibold text-zinc-900 dark:text-white">{item.title}</div>
                  <p className="text-xs text-zinc-600 dark:text-zinc-400 mt-0.5 leading-relaxed">
                    {item.detail}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </section>
  );
};
