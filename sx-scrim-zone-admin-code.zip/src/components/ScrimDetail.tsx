import React, { useEffect, useState } from 'react';
import { ArrowLeft, Calendar, Copy, Eye, EyeOff, KeyRound, Lock, Trophy, Users } from 'lucide-react';
import { Scrim, ScrimRoom } from '../types';
import { useApp } from '../context/AppContext';
import { fetchScrimRoomCredentials } from '../lib/db';
import { TournamentRules } from './TournamentRules';

interface ScrimDetailProps {
  scrim: Scrim;
  onBack: () => void;
  onRegister: () => void;
}

export const ScrimDetail: React.FC<ScrimDetailProps> = ({ scrim, onBack, onRegister }) => {
  const { user, isAdmin, registrations, rosters, pushToast } = useApp();
  const [roomCreds, setRoomCreds] = useState<ScrimRoom | null>(null);
  const [showRoomPass, setShowRoomPass] = useState(false);
  const [nowMs, setNowMs] = useState(() => Date.now());

  const userReg = registrations.find((r) => r.scrimId === scrim.id && r.status !== 'rejected');
  const userConfirmedReg = registrations.find(
    (r) => r.scrimId === scrim.id && r.status === 'slot_confirmed'
  );
  const assignedRoomId = userReg?.assignedRoomId?.trim() || '';
  const assignedRoomPassword = userReg?.assignedRoomPassword?.trim() || '';
  const hasDirectAssignedRoom = Boolean(assignedRoomId);

  const releaseMs = new Date(scrim.roomReleaseAtISO).getTime();
  const isReleaseTime = nowMs >= releaseMs || Boolean(scrim.roomReleased);
  const canViewRoom = isAdmin || hasDirectAssignedRoom || (Boolean(userConfirmedReg) && isReleaseTime);

  const activeRoomId = assignedRoomId || roomCreds?.roomId || '';
  const activeRoomPass = assignedRoomId ? assignedRoomPassword : roomCreds?.roomPassword || '';

  useEffect(() => {
    const timer = setInterval(() => setNowMs(Date.now()), 15000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    if (!user || (!isAdmin && !userConfirmedReg)) {
      setRoomCreds(null);
      return;
    }
    if (isAdmin || isReleaseTime) {
      fetchScrimRoomCredentials(scrim.id).then(setRoomCreds);
    }
  }, [scrim.id, user, isAdmin, userConfirmedReg, isReleaseTime]);

  const scrimRosters = rosters.filter((r) => r.scrimId === scrim.id && r.status !== 'rejected');
  const canRegister = scrim.status === 'Open' || scrim.status === 'Filling Fast';
  const minsUntilRelease = Math.max(0, Math.ceil((releaseMs - nowMs) / 60000));

  const copyText = (val: string, label: string) => {
    navigator.clipboard.writeText(val);
    pushToast({ type: 'success', title: `${label} copied` });
  };

  return (
    <div className="space-y-6">
      <button
        type="button"
        onClick={onBack}
        className="min-h-[40px] inline-flex items-center gap-2 text-sm font-medium text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white transition-colors"
      >
        <ArrowLeft className="w-4 h-4" />
        Back to Scrims
      </button>

      {/* Hero Header */}
      <div className="relative rounded-2xl overflow-hidden border border-zinc-200 dark:border-white/10 bg-[#14141C]">
        <img
          src={scrim.bannerUrl}
          alt={scrim.title}
          referrerPolicy="no-referrer"
          className="w-full h-56 sm:h-64 object-cover opacity-60"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0A0A0F] via-[#0A0A0F]/60 to-transparent" />
        <div className="absolute bottom-0 inset-x-0 p-6 flex flex-col sm:flex-row sm:items-end justify-between gap-4">
          <div>
            <div className="text-xs font-semibold text-[#FF6A00]">
              {scrim.map} · {scrim.mode} · {scrim.status}
            </div>
            <h1 className="font-display text-3xl sm:text-4xl font-bold text-white mt-1">{scrim.title}</h1>
            <p className="text-xs text-zinc-300 mt-1 inline-flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5 text-[#FF6A00]" />
              Match Start: {new Date(scrim.dateTimeISO).toLocaleString()}
            </p>
          </div>
          {canRegister && (
            <button
              type="button"
              onClick={onRegister}
              className="min-h-[46px] px-6 py-2.5 rounded-xl bg-[#FF6A00] hover:bg-[#e55f00] text-white font-semibold text-sm transition-colors whitespace-nowrap shrink-0"
            >
              Register Team ({scrim.currency} {scrim.entryFee})
            </button>
          )}
        </div>
      </div>

      {/* Key Metrics Strip */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="rounded-2xl bg-white dark:bg-[#14141C] border border-zinc-200 dark:border-white/10 p-4">
          <div className="text-xs text-zinc-500 dark:text-zinc-400">Entry Fee</div>
          <div className="font-mono text-xl font-bold text-zinc-900 dark:text-white tabular-nums mt-1">
            {scrim.currency} {scrim.entryFee}
          </div>
        </div>
        <div className="rounded-2xl bg-white dark:bg-[#14141C] border border-zinc-200 dark:border-white/10 p-4">
          <div className="text-xs text-zinc-500 dark:text-zinc-400">Prize Pool</div>
          <div className="font-mono text-xl font-bold text-[#FF6A00] tabular-nums mt-1">
            {scrim.currency} {scrim.prizePool}
          </div>
        </div>
        <div className="rounded-2xl bg-white dark:bg-[#14141C] border border-zinc-200 dark:border-white/10 p-4">
          <div className="text-xs text-zinc-500 dark:text-zinc-400">Slots Filled</div>
          <div className="font-mono text-xl font-bold text-zinc-900 dark:text-white tabular-nums mt-1">
            {scrim.slotsFilled} / {scrim.totalSlots}
          </div>
        </div>
        <div className="rounded-2xl bg-white dark:bg-[#14141C] border border-zinc-200 dark:border-white/10 p-4">
          <div className="text-xs text-zinc-500 dark:text-zinc-400">Room Release</div>
          <div className="font-mono text-sm font-semibold text-zinc-900 dark:text-white tabular-nums mt-1">
            {new Date(scrim.roomReleaseAtISO).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} (10m prior)
          </div>
        </div>
      </div>

      {/* Custom Room Credentials Vault */}
      <section className="rounded-2xl bg-white dark:bg-[#14141C] border border-zinc-200 dark:border-white/10 p-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#FF6A00]/15 text-[#FF6A00] flex items-center justify-center shrink-0">
              {canViewRoom ? <KeyRound className="w-5 h-5" /> : <Lock className="w-5 h-5" />}
            </div>
            <div>
              <h2 className="font-display text-xl font-bold text-zinc-900 dark:text-white">
                Scrim ID Code &amp; Passcode
              </h2>
              <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-0.5">
                {canViewRoom && activeRoomId
                  ? 'Scrim Room ID & passcode are unlocked. Join 5 minutes prior to match start.'
                  : canViewRoom
                    ? 'Waiting for the admin to place the Scrim ID & passcode.'
                    : userConfirmedReg
                      ? `Slot confirmed. Room ID & passcode auto-release in ~${minsUntilRelease} minutes or when placed by admin.`
                      : 'Registered teams receive the Scrim ID Code and Passcode here once placed or released by the admin.'}
              </p>
            </div>
          </div>

          {canViewRoom && activeRoomId && (
            <div className="flex flex-wrap items-center gap-2.5">
              <button
                type="button"
                onClick={() => copyText(activeRoomId, 'Room ID')}
                className="min-h-[40px] px-3.5 py-2 rounded-xl bg-zinc-100 dark:bg-[#0A0A0F] border border-zinc-200 dark:border-white/10 text-xs font-mono font-semibold flex items-center gap-2 hover:border-[#FF6A00]"
              >
                ID: {activeRoomId}
                <Copy className="w-3.5 h-3.5 text-[#FF6A00]" />
              </button>
              <button
                type="button"
                onClick={() => copyText(activeRoomPass || '', 'Room Passcode')}
                className="min-h-[40px] px-3.5 py-2 rounded-xl bg-zinc-100 dark:bg-[#0A0A0F] border border-zinc-200 dark:border-white/10 text-xs font-mono font-semibold flex items-center gap-2 hover:border-[#FF6A00]"
              >
                PASS: {showRoomPass ? activeRoomPass || 'None' : '••••••'}
                <Copy className="w-3.5 h-3.5 text-[#FF6A00]" />
              </button>
              <button
                type="button"
                onClick={() => setShowRoomPass((p) => !p)}
                aria-label={showRoomPass ? 'Hide passcode' : 'Show passcode'}
                className="min-h-[40px] px-2.5 py-2 rounded-xl border border-zinc-200 dark:border-white/10 text-zinc-500 hover:text-zinc-900 dark:hover:text-white"
              >
                {showRoomPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          )}
        </div>
      </section>

      {/* Tournament Rules, Registered Squads, Points System, Prize Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">
        <div className="lg:col-span-2 space-y-6">
          <TournamentRules scrim={scrim} />

          <section className="rounded-2xl bg-white dark:bg-[#14141C] border border-zinc-200 dark:border-white/10 p-6 space-y-3">
            <h2 className="font-display text-xl font-bold text-zinc-900 dark:text-white">
              Registered Squads ({scrimRosters.length})
            </h2>
            {scrimRosters.length === 0 ? (
              <p className="text-xs text-zinc-500 dark:text-zinc-400">
                Be the first squad to register for this lobby.
              </p>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {scrimRosters.map((r) => (
                  <div
                    key={r.id}
                    className="flex items-center justify-between gap-2 rounded-xl bg-zinc-50 dark:bg-[#0A0A0F] border border-zinc-200 dark:border-white/8 px-3.5 py-2.5"
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <Users className="w-4 h-4 text-[#FF6A00] shrink-0" />
                      <span className="text-xs font-semibold text-zinc-900 dark:text-white truncate">{r.teamName}</span>
                    </div>
                    <span className="text-[11px] font-medium text-zinc-500 dark:text-zinc-400 shrink-0">
                      {r.status === 'slot_confirmed' ? 'Confirmed' : 'Pending'}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </section>
        </div>

        <div className="space-y-6">
          {/* Prize Breakdown */}
          <section className="rounded-2xl bg-white dark:bg-[#14141C] border border-zinc-200 dark:border-white/10 p-6 space-y-3">
            <div className="flex items-center gap-2">
              <Trophy className="w-5 h-5 text-[#FF6A00]" />
              <h2 className="font-display text-xl font-bold text-zinc-900 dark:text-white">Prize Distribution</h2>
            </div>
            <div className="divide-y divide-zinc-200 dark:divide-white/10">
              {scrim.prizeDistribution.map((tier) => (
                <div key={tier.rank} className="py-2.5 flex items-center justify-between text-sm">
                  <span className="text-zinc-700 dark:text-zinc-300">{tier.label}</span>
                  <span className="font-mono font-bold text-[#FF6A00] tabular-nums">
                    {scrim.currency} {tier.amount}
                  </span>
                </div>
              ))}
            </div>
          </section>

          {/* Points System */}
          <section className="rounded-2xl bg-white dark:bg-[#14141C] border border-zinc-200 dark:border-white/10 p-6 space-y-3">
            <h2 className="font-display text-xl font-bold text-zinc-900 dark:text-white">Scoring System</h2>
            <p className="text-xs text-zinc-500 dark:text-zinc-400">
              Kill Points: <strong className="text-zinc-900 dark:text-white">+{scrim.pointsSystem.killPoint} pt</strong> per elimination
            </p>
            <div className="grid grid-cols-2 gap-2 text-xs">
              {Object.entries(scrim.pointsSystem.placement)
                .slice(0, 10)
                .map(([rank, pts]) => (
                  <div
                    key={rank}
                    className="flex items-center justify-between px-3 py-1.5 rounded-lg bg-zinc-50 dark:bg-[#0A0A0F] border border-zinc-200 dark:border-white/8"
                  >
                    <span className="text-zinc-500 dark:text-zinc-400">#{rank}</span>
                    <span className="font-mono font-bold text-zinc-900 dark:text-white tabular-nums">
                      {pts} {pts === 1 ? 'pt' : 'pts'}
                    </span>
                  </div>
                ))}
            </div>
          </section>
        </div>
      </div>
    </div>
  );
};
