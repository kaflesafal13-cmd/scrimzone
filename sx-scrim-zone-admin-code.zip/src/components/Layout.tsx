import React, { useState } from 'react';
import {
  Flame,
  Trophy,
  Users,
  Receipt,
  Bell,
  UserCircle,
  ShieldAlert,
  Sun,
  Moon,
  Download,
  LogIn,
  WifiOff,
  X,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { useOnlineStatus } from '../hooks/useOnlineStatus';

export type NavTab =
  | 'home'
  | 'my-teams'
  | 'transactions'
  | 'notifications'
  | 'leaderboard'
  | 'profile'
  | 'admin'
  | 'login';

interface LayoutProps {
  activeTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  onOpenAuth: () => void;
  children: React.ReactNode;
}

export const Layout: React.FC<LayoutProps> = ({ activeTab, onSelectTab, onOpenAuth, children }) => {
  const { user, isAdmin, theme, toggleTheme, notifications, toasts, dismissToast } = useApp();
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const isOnline = useOnlineStatus();
  const [showIOSGuide, setShowIOSGuide] = useState(false);

  const unreadCount = notifications.filter((n) => !n.read).length;

  const navItems: { id: NavTab; label: string; icon: React.ComponentType<{ className?: string }>; badge?: number }[] = [
    { id: 'home', label: 'Scrims', icon: Flame },
    { id: 'my-teams', label: 'My Teams', icon: Users },
    { id: 'transactions', label: 'Payments', icon: Receipt },
    { id: 'notifications', label: 'Alerts', icon: Bell, badge: unreadCount },
    { id: 'leaderboard', label: 'Standings', icon: Trophy },
    { id: 'profile', label: 'Profile', icon: UserCircle },
  ];

  navItems.push({ id: 'admin', label: 'Admin', icon: ShieldAlert });

  const mobileItems = navItems.slice(0, 5);

  return (
    <div className="min-h-screen flex flex-col lg:flex-row bg-[#F6F6F9] text-[#0F1016] dark:bg-[#0A0A0F] dark:text-[#F4F4F7]">
      {/* Desktop Left Sidebar */}
      <aside className="hidden lg:flex lg:flex-col lg:w-64 lg:fixed lg:inset-y-0 border-r border-zinc-200 dark:border-white/8 bg-white dark:bg-[#0D0D14] z-30">
        <div className="px-5 h-16 flex items-center gap-3 border-b border-zinc-200 dark:border-white/8">
          <div className="w-9 h-9 rounded-xl bg-[#FF6A00] flex items-center justify-center text-white font-display font-bold text-lg shadow-[0_0_20px_rgba(255,106,0,0.35)]">
            SX
          </div>
          <span className="font-display text-xl font-bold tracking-wider whitespace-nowrap">SX SCRIM ZONE</span>
        </div>

        <nav className="flex-1 p-3 space-y-1 overflow-y-auto" aria-label="Primary Sidebar Navigation">
          {navItems.map((item) => {
            const Icon = item.icon;
            const active = activeTab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => onSelectTab(item.id)}
                className={`w-full min-h-[44px] px-3.5 py-2.5 rounded-xl flex items-center justify-between text-sm font-medium transition-colors whitespace-nowrap ${
                  active
                    ? 'bg-[#FF6A00]/15 text-[#FF6A00] font-semibold'
                    : 'text-zinc-600 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-white/5 hover:text-zinc-900 dark:hover:text-white'
                }`}
              >
                <span className="flex items-center gap-3">
                  <Icon className="w-4 h-4 shrink-0" />
                  <span>{item.label}</span>
                </span>
                {item.badge && item.badge > 0 ? (
                  <span className="font-mono text-xs font-bold text-[#FF6A00] tabular-nums">{item.badge}</span>
                ) : null}
              </button>
            );
          })}
        </nav>

        <div className="p-3 border-t border-zinc-200 dark:border-white/8 space-y-2">
          {!isInstalled && isInstallable && (
            <button
              type="button"
              onClick={install}
              className="w-full min-h-[40px] px-3 py-2 rounded-xl bg-[#FF6A00]/12 text-[#FF6A00] hover:bg-[#FF6A00]/20 text-xs font-semibold flex items-center justify-center gap-2 transition-colors whitespace-nowrap"
            >
              <Download className="w-4 h-4" />
              Install SX App
            </button>
          )}
          {!isInstalled && isIOS && (
            <button
              type="button"
              onClick={() => setShowIOSGuide(true)}
              className="w-full min-h-[40px] px-3 py-2 rounded-xl border border-zinc-200 dark:border-white/10 text-xs font-semibold flex items-center justify-center gap-2 hover:bg-zinc-100 dark:hover:bg-white/5 transition-colors whitespace-nowrap"
            >
              <Download className="w-4 h-4" />
              Install on iOS
            </button>
          )}

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={toggleTheme}
              aria-label={`Switch to ${theme === 'dark' ? 'light' : 'dark'} theme`}
              className="flex-1 min-h-[40px] px-3 py-2 rounded-xl border border-zinc-200 dark:border-white/10 text-xs font-medium flex items-center justify-center gap-2 hover:bg-zinc-100 dark:hover:bg-white/5 transition-colors whitespace-nowrap"
            >
              {theme === 'dark' ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4" />}
              {theme === 'dark' ? 'Light Mode' : 'Dark Mode'}
            </button>

            {!user && (
              <button
                type="button"
                onClick={onOpenAuth}
                className="flex-1 min-h-[40px] px-3 py-2 rounded-xl bg-[#FF6A00] hover:bg-[#e55f00] text-white text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors whitespace-nowrap"
              >
                <LogIn className="w-3.5 h-3.5" />
                Sign In
              </button>
            )}
          </div>
        </div>
      </aside>

      {/* Main Content Shell */}
      <div className="flex-1 lg:pl-64 flex flex-col min-h-screen">
        {/* Top Bar (Mobile + Desktop Context Header) */}
        <header className="sticky top-0 z-20 h-14 px-3 sm:px-4 lg:px-8 flex items-center justify-between gap-2 sm:gap-4 border-b border-zinc-200 dark:border-white/8 bg-white/90 dark:bg-[#0A0A0F]/90 backdrop-blur-md">
          <button
            type="button"
            onClick={() => onSelectTab('home')}
            className="flex items-center gap-2 lg:hidden min-w-0 text-left"
          >
            <div className="w-8 h-8 shrink-0 rounded-lg bg-[#FF6A00] flex items-center justify-center text-white font-display font-bold text-sm">
              SX
            </div>
            <span className="font-display text-base sm:text-lg font-bold tracking-wider truncate">SX SCRIM ZONE</span>
          </button>

          <div className="hidden lg:block text-sm font-medium text-zinc-500 dark:text-zinc-400">
            Free Fire Custom Room &amp; Esports Tournament Desk
          </div>

          <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
            <button
              type="button"
              onClick={toggleTheme}
              aria-label={`Switch to ${theme === 'dark' ? 'light' : 'dark'} theme`}
              className="lg:hidden min-w-[38px] min-h-[38px] rounded-xl flex items-center justify-center text-zinc-600 dark:text-zinc-300 hover:bg-zinc-100 dark:hover:bg-white/5"
            >
              {theme === 'dark' ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4" />}
            </button>

            <button
              type="button"
              onClick={() => onSelectTab('admin')}
              className="lg:hidden min-h-[38px] px-2.5 sm:px-3 rounded-xl bg-[#FF6A00]/15 text-[#FF6A00] text-xs font-semibold whitespace-nowrap"
            >
              Admin
            </button>

            {user ? (
              <button
                type="button"
                onClick={() => onSelectTab('profile')}
                className="min-h-[38px] px-2.5 sm:px-3 py-1.5 rounded-xl bg-zinc-100 dark:bg-[#14141C] border border-zinc-200 dark:border-white/10 text-xs font-semibold text-zinc-900 dark:text-white flex items-center gap-2 hover:border-[#FF6A00]/50 transition-colors whitespace-nowrap"
              >
                <span className="max-w-[96px] sm:max-w-[130px] truncate">{user.displayName || user.email}</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={onOpenAuth}
                className="min-h-[38px] px-3 sm:px-4 py-2 rounded-xl bg-[#FF6A00] hover:bg-[#e55f00] text-white text-xs font-semibold flex items-center gap-1.5 transition-colors whitespace-nowrap"
              >
                <LogIn className="w-3.5 h-3.5 shrink-0" />
                Sign In
              </button>
            )}
          </div>
        </header>

        <main className="flex-1 w-full max-w-7xl mx-auto px-4 lg:px-8 py-6 pb-24 lg:pb-10">
          {children}
        </main>
      </div>

      {/* Mobile Bottom Tab Bar (height 64px <= 15% cap) */}
      <nav
        className="lg:hidden fixed bottom-0 left-0 right-0 z-30 h-16 bg-white/95 dark:bg-[#0D0D14]/95 backdrop-blur-md border-t border-zinc-200 dark:border-white/10 grid grid-cols-5 items-center"
        aria-label="Mobile Bottom Navigation"
      >
        {mobileItems.map((item) => {
          const Icon = item.icon;
          const active = activeTab === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => onSelectTab(item.id)}
              className={`min-h-[44px] h-full flex flex-col items-center justify-center gap-0.5 text-[11px] font-medium transition-colors relative ${
                active ? 'text-[#FF6A00] font-semibold' : 'text-zinc-500 dark:text-zinc-400'
              }`}
            >
              <Icon className="w-5 h-5" />
              <span className="truncate max-w-[64px]">{item.label}</span>
              {item.badge && item.badge > 0 ? (
                <span className="absolute top-1.5 right-4 font-mono text-[10px] font-bold text-[#FF6A00]">
                  {item.badge}
                </span>
              ) : null}
            </button>
          );
        })}
      </nav>

      {/* Offline Banner */}
      {!isOnline && (
        <div className="fixed bottom-20 lg:bottom-5 left-4 z-40 flex items-center gap-2 rounded-xl bg-amber-600 px-3.5 py-2 text-xs font-semibold text-white shadow-lg">
          <WifiOff className="w-4 h-4" />
          Offline Mode — Cached scrim data active
        </div>
      )}

      {/* Toast Stack */}
      <div className="fixed top-16 right-4 z-50 space-y-2 max-w-sm w-[calc(100%-2rem)] pointer-events-none">
        {toasts.map((t) => (
          <div
            key={t.id}
            role="status"
            className={`pointer-events-auto rounded-xl border p-3.5 shadow-xl flex items-start justify-between gap-3 bg-white dark:bg-[#14141C] ${
              t.type === 'error'
                ? 'border-[#FF2A2A]/40'
                : t.type === 'success'
                  ? 'border-emerald-500/40'
                  : 'border-[#FF6A00]/40'
            }`}
          >
            <div className="min-w-0">
              <p className="text-xs font-semibold text-zinc-900 dark:text-white">{t.title}</p>
              {t.description && <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-0.5">{t.description}</p>}
            </div>
            <button
              type="button"
              onClick={() => dismissToast(t.id)}
              aria-label="Dismiss notification"
              className="text-zinc-400 hover:text-zinc-900 dark:hover:text-white p-1"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        ))}
      </div>

      {/* iOS PWA Guide Modal */}
      {showIOSGuide && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
          <div className="w-full max-w-sm rounded-2xl bg-white dark:bg-[#14141C] border border-zinc-200 dark:border-white/10 p-6">
            <h3 className="font-display text-xl font-bold text-zinc-900 dark:text-white">Install SX SCRIM ZONE</h3>
            <p className="mt-2 text-sm text-zinc-600 dark:text-zinc-300">
              1. Tap the <strong>Share</strong> button in Safari.<br />
              2. Scroll down and tap <strong>Add to Home Screen</strong>.
            </p>
            <button
              type="button"
              onClick={() => setShowIOSGuide(false)}
              className="mt-4 w-full min-h-[44px] rounded-xl bg-[#FF6A00] text-white text-sm font-semibold"
            >
              Got it
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
