import React, { useMemo, useState } from 'react';
import { motion } from 'motion/react';
import { Search, Megaphone, ArrowRight, Calendar, Users, Trophy } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Scrim, ScrimMode, ScrimStatus } from '../types';
import { EMPTY_STATE_IMAGE_URL, HERO_BANNER_URL } from '../data/seedData';

interface ScrimsHomeProps {
  onSelectScrim: (scrim: Scrim) => void;
  onQuickRegister: (scrim: Scrim) => void;
}

export const ScrimsHome: React.FC<ScrimsHomeProps> = ({ onSelectScrim, onQuickRegister }) => {
  const { scrims, announcements, dataLoading } = useApp();
  const [searchQuery, setSearchQuery] = useState('');
  const [modeFilter, setModeFilter] = useState<'All' | ScrimMode>('All');
  const [statusFilter, setStatusFilter] = useState<'All' | ScrimStatus>('All');

  const filteredScrims = useMemo(() => {
    return scrims.filter((s) => {
      if (modeFilter !== 'All' && s.mode !== modeFilter) return false;
      if (statusFilter !== 'All' && s.status !== statusFilter) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        return (
          s.title.toLowerCase().includes(q) ||
          s.map.toLowerCase().includes(q) ||
          s.mode.toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [scrims, modeFilter, statusFilter, searchQuery]);

  const featuredScrim = useMemo(
    () => scrims.find((s) => s.status === 'Filling Fast' || s.status === 'Open') || scrims[0],
    [scrims]
  );

  const latestAnnouncement = announcements[0];

  const statusColorClass = (status: ScrimStatus) => {
    switch (status) {
      case 'Open':
        return 'text-emerald-600 dark:text-emerald-400';
      case 'Filling Fast':
        return 'text-[#FF6A00]';
      case 'Live':
        return 'text-[#FF2A2A]';
      case 'Full':
        return 'text-amber-600 dark:text-amber-400';
      default:
        return 'text-zinc-500 dark:text-zinc-400';
    }
  };

  return (
    <div className="space-y-6">
      {/* Hero Banner */}
      <section className="relative overflow-hidden rounded-2xl border border-zinc-200 dark:border-white/10 bg-[#14141C]">
        <img
          src={HERO_BANNER_URL}
          alt="SX SCRIM ZONE Esports Arena"
          referrerPolicy="no-referrer"
          className="absolute inset-0 w-full h-full object-cover opacity-55"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-[#0A0A0F]/95 via-[#0A0A0F]/80 to-[#0A0A0F]/40" />

        <div className="relative p-5 sm:p-6 lg:px-8 lg:py-7 flex flex-col lg:flex-row lg:items-end justify-between gap-5">
          <div className="max-w-2xl space-y-2">
            <p className="text-xs font-semibold tracking-wider text-[#FF6A00] uppercase">
              Free Fire Custom Room Tournaments
            </p>
            <h1 className="font-display text-3xl sm:text-4xl font-bold text-white leading-tight [text-wrap:balance]">
              Compete in Daily Scrims with Instant AI Slot Confirmation
            </h1>
            <p className="text-sm text-zinc-300 max-w-xl">
              Build your squad card, upload your entry receipt, and get verified in seconds. Room IDs unlock automatically 10 minutes before drop.
            </p>
          </div>

          {featuredScrim && (
            <div className="shrink-0">
              <button
                type="button"
                onClick={() => onQuickRegister(featuredScrim)}
                className="min-h-[46px] px-6 py-2.5 rounded-xl bg-[#FF6A00] hover:bg-[#e55f00] text-white font-semibold text-sm flex items-center gap-2.5 shadow-[0_8px_24px_rgba(255,106,0,0.35)] transition-all whitespace-nowrap"
              >
                Register Next Scrim
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      </section>

      {/* Organizer Announcement Strip */}
      {latestAnnouncement && (
        <section
          aria-label="Latest Organizer Announcement"
          className="rounded-2xl bg-white dark:bg-[#14141C] border border-zinc-200 dark:border-white/10 p-4 flex items-start gap-3.5"
        >
          <div className="w-9 h-9 rounded-xl bg-[#FF6A00]/15 text-[#FF6A00] flex items-center justify-center shrink-0">
            <Megaphone className="w-4 h-4" />
          </div>
          <div className="min-w-0">
            <h2 className="text-sm font-semibold text-zinc-900 dark:text-white">{latestAnnouncement.title}</h2>
            <p className="text-xs text-zinc-600 dark:text-zinc-400 mt-0.5">{latestAnnouncement.message}</p>
          </div>
        </section>
      )}

      {/* Search & Filter Controls */}
      <section className="space-y-4" aria-label="Scrim Directory">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h2 className="font-display text-2xl font-bold text-zinc-900 dark:text-white">Upcoming &amp; Live Scrims</h2>
            <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-0.5">
              Select a custom room lobby to view rules, points, and register your roster.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <div className="relative w-full sm:w-64">
              <Search className="w-4 h-4 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <label htmlFor="scrim-search" className="sr-only">
                Search scrims by title or map
              </label>
              <input
                id="scrim-search"
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search map or scrim..."
                className="w-full min-h-[42px] pl-9 pr-3 py-2 rounded-xl bg-white dark:bg-[#14141C] border border-zinc-200 dark:border-white/10 text-sm text-zinc-900 dark:text-white focus:outline-none focus:border-[#FF6A00]"
              />
            </div>

            <div className="flex items-center gap-1 p-1 rounded-xl bg-zinc-200/70 dark:bg-[#14141C] border border-zinc-200 dark:border-white/10">
              {(['All', 'Squad', 'Duo', 'Solo'] as const).map((m) => (
                <button
                  key={m}
                  type="button"
                  onClick={() => setModeFilter(m)}
                  className={`min-h-[34px] px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap ${
                    modeFilter === m
                      ? 'bg-[#FF6A00] text-white'
                      : 'text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white'
                  }`}
                >
                  {m}
                </button>
              ))}
            </div>

            <label htmlFor="status-filter" className="sr-only">
              Filter by scrim status
            </label>
            <select
              id="status-filter"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as 'All' | ScrimStatus)}
              className="flex-1 sm:flex-initial min-w-[130px] min-h-[42px] px-3 py-2 rounded-xl bg-white dark:bg-[#14141C] border border-zinc-200 dark:border-white/10 text-xs font-semibold text-zinc-900 dark:text-white focus:outline-none focus:border-[#FF6A00]"
            >
              <option value="All">All Statuses</option>
              <option value="Open">Open</option>
              <option value="Filling Fast">Filling Fast</option>
              <option value="Full">Full</option>
              <option value="Live">Live</option>
              <option value="Completed">Completed</option>
            </select>
          </div>
        </div>

        {/* Loading Skeletons */}
        {dataLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
            {[1, 2, 3].map((idx) => (
              <div
                key={idx}
                className="rounded-2xl bg-white dark:bg-[#14141C] border border-zinc-200 dark:border-white/10 overflow-hidden animate-pulse"
              >
                <div className="h-44 bg-zinc-200 dark:bg-white/5" />
                <div className="p-5 space-y-3">
                  <div className="h-5 w-2/3 bg-zinc-200 dark:bg-white/10 rounded" />
                  <div className="h-4 w-1/2 bg-zinc-200 dark:bg-white/10 rounded" />
                  <div className="h-10 w-full bg-zinc-200 dark:bg-white/10 rounded-xl" />
                </div>
              </div>
            ))}
          </div>
        ) : filteredScrims.length === 0 ? (
          /* Illustrated Empty State */
          <div className="rounded-2xl bg-white dark:bg-[#14141C] border border-zinc-200 dark:border-white/10 p-8 text-center max-w-lg mx-auto space-y-4">
            <img
              src={EMPTY_STATE_IMAGE_URL}
              alt="No scrims available"
              referrerPolicy="no-referrer"
              className="w-48 h-36 object-cover rounded-xl mx-auto"
            />
            <div>
              <h3 className="font-display text-xl font-bold text-zinc-900 dark:text-white">
                {scrims.length === 0 ? 'No Scrims Scheduled Yet' : 'No Matching Scrims'}
              </h3>
              <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-1">
                {scrims.length === 0
                  ? 'No upcoming or live scrims right now. Check back soon or publish a scrim from the Admin Console.'
                  : 'Try clearing your search or switching mode and status filters.'}
              </p>
            </div>
            {scrims.length > 0 && (
              <button
                type="button"
                onClick={() => {
                  setSearchQuery('');
                  setModeFilter('All');
                  setStatusFilter('All');
                }}
                className="min-h-[42px] px-5 py-2 rounded-xl bg-[#FF6A00] text-white text-xs font-semibold hover:bg-[#e55f00] transition-colors"
              >
                Reset Filters
              </button>
            )}
          </div>
        ) : (
          /* Scrims Grid */
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
            {filteredScrims.map((scrim) => {
              const fillPct = Math.min(100, Math.round((scrim.slotsFilled / Math.max(1, scrim.totalSlots)) * 100));
              const formattedDate = new Date(scrim.dateTimeISO).toLocaleString(undefined, {
                month: 'short',
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit',
              });
              const canRegister = scrim.status === 'Open' || scrim.status === 'Filling Fast';

              return (
                <motion.article
                  key={scrim.id}
                  whileHover={{ y: -2 }}
                  transition={{ duration: 0.16 }}
                  className="rounded-2xl bg-white dark:bg-[#14141C] border border-zinc-200 dark:border-white/10 hover:border-[#FF6A00]/50 overflow-hidden flex flex-col transition-colors"
                >
                  <div className="relative h-36 bg-[#0A0A0F] overflow-hidden">
                    <img
                      src={scrim.bannerUrl}
                      alt={`${scrim.title} map banner`}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#0A0A0F]/95 via-[#0A0A0F]/35 to-[#0A0A0F]/35" />
                    <div className="absolute top-3 right-3.5 rounded-md bg-[#0A0A0F]/80 backdrop-blur-sm px-2 py-0.5 border border-white/10">
                      <span className={`text-[11px] font-bold tracking-wide ${statusColorClass(scrim.status)}`}>
                        {scrim.status}
                      </span>
                    </div>
                    <div className="absolute bottom-3 left-4 right-4">
                      <h3 className="font-display text-xl font-bold text-white leading-snug">
                        {scrim.title}
                      </h3>
                    </div>
                  </div>

                  <div className="p-4 sm:p-5 flex-1 flex flex-col justify-between gap-3.5">
                    <div className="space-y-3">
                      {/* Clean unboxed metadata */}
                      <div className="flex flex-wrap items-center gap-2 text-xs text-zinc-500 dark:text-zinc-400">
                        <span className="font-medium text-zinc-800 dark:text-zinc-200">{scrim.map}</span>
                        <span aria-hidden="true">·</span>
                        <span>{scrim.mode}</span>
                        <span aria-hidden="true">·</span>
                        <span className="inline-flex items-center gap-1">
                          <Calendar className="w-3.5 h-3.5" />
                          {formattedDate}
                        </span>
                      </div>

                      <div className="grid grid-cols-2 gap-3 pt-1">
                        <div>
                          <div className="text-[11px] text-zinc-500 dark:text-zinc-400">Entry Fee</div>
                          <div className="font-mono text-base font-bold text-zinc-900 dark:text-white tabular-nums">
                            {scrim.currency} {scrim.entryFee}
                          </div>
                        </div>
                        <div>
                          <div className="text-[11px] text-zinc-500 dark:text-zinc-400">Prize Pool</div>
                          <div className="font-mono text-base font-bold text-[#FF6A00] tabular-nums inline-flex items-center gap-1">
                            <Trophy className="w-3.5 h-3.5" />
                            {scrim.currency} {scrim.prizePool}
                          </div>
                        </div>
                      </div>

                      {/* Slots Progress Bar */}
                      <div className="space-y-1.5">
                        <div className="flex items-center justify-between text-xs">
                          <span className="text-zinc-500 dark:text-zinc-400 inline-flex items-center gap-1">
                            <Users className="w-3.5 h-3.5" />
                            Slots Filled
                          </span>
                          <span className="font-mono font-semibold text-zinc-900 dark:text-white tabular-nums">
                            {scrim.slotsFilled} / {scrim.totalSlots}
                          </span>
                        </div>
                        <div className="h-2 rounded-full bg-zinc-200 dark:bg-white/10 overflow-hidden">
                          <div
                            className={`h-full rounded-full transition-all ${
                              fillPct >= 90 ? 'bg-[#FF2A2A]' : 'bg-[#FF6A00]'
                            }`}
                            style={{ width: `${fillPct}%` }}
                          />
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2.5 pt-1">
                      <button
                        type="button"
                        onClick={() => onSelectScrim(scrim)}
                        className="flex-1 min-h-[42px] px-3 py-2 rounded-xl border border-zinc-200 dark:border-white/12 text-xs font-semibold text-zinc-900 dark:text-white hover:bg-zinc-100 dark:hover:bg-white/5 transition-colors whitespace-nowrap"
                      >
                        View Details
                      </button>
                      {canRegister && (
                        <button
                          type="button"
                          onClick={() => onQuickRegister(scrim)}
                          className="flex-1 min-h-[42px] px-3 py-2 rounded-xl bg-[#FF6A00] hover:bg-[#e55f00] text-white text-xs font-semibold transition-colors whitespace-nowrap"
                        >
                          Register Team
                        </button>
                      )}
                    </div>
                  </div>
                </motion.article>
              );
            })}
          </div>
        )}
      </section>
    </div>
  );
};
