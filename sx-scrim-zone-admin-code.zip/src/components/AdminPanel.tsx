import React, { useEffect, useMemo, useState } from 'react';
import {
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import {
  Ban,
  CheckCircle2,
  Download,
  FileSpreadsheet,
  FileText,
  KeyRound,
  Lock,
  Megaphone,
  Plus,
  Send,
  ShieldAlert,
  Trash2,
  Unlock,
  XCircle,
  ZoomIn,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import {
  PaymentMethod,
  PaymentMethodType,
  Registration,
  SCHEMA_LIMITS,
  Scrim,
  ScrimMap,
  ScrimMode,
  ScrimStatus,
  TransactionRecord,
} from '../types';
import {
  adminAssignTeamRoomCredentials,
  adminDeletePaymentMethod,
  adminDeleteScrim,
  adminPushAnnouncement,
  adminPushRoomToScrimTeams,
  adminRemoveRegistration,
  adminReviewRegistration,
  adminSavePaymentMethod,
  adminSaveResult,
  adminSaveScrim,
  adminSaveTransaction,
  adminToggleUserBan,
  fetchScrimRoomCredentials,
  makeSafeId,
  updateRegisteredTeamPassword,
} from '../lib/db';
import {
  downloadAllTeamCards,
  exportRegistrationsCsv,
  exportRegistrationsExcel,
  exportRegistrationsPdf,
} from '../lib/exportUtils';
import { calculateTeamPoints, DEFAULT_POINTS_SYSTEM, sortLeaderboard } from '../utils/scoring';
import { compressImageToDataUrl } from '../utils/imageProcessing';
import { hashTeamPassword, validateTeamPassword } from '../utils/teamPassword';

type AdminSection =
  | 'dashboard'
  | 'scrims'
  | 'payments'
  | 'review'
  | 'teams'
  | 'ledger'
  | 'fraud'
  | 'announcements'
  | 'results';

export const AdminPanel: React.FC = () => {
  const {
    user,
    scrims,
    paymentMethods,
    registrations,
    transactions,
    fraudLogs,
    allUsers,
    announcements,
    results,
    pushToast,
  } = useApp();

  const [section, setSection] = useState<AdminSection>('dashboard');

  // --- Metrics ---
  const totalRevenue = useMemo(
    () =>
      transactions
        .filter((t) => t.status === 'verified' || t.status === 'manual')
        .reduce((sum, t) => sum + (Number(t.amount) || 0), 0),
    [transactions]
  );
  const pendingReviewRegs = useMemo(
    () => registrations.filter((r) => r.status === 'pending_review'),
    [registrations]
  );
  const totalSlotsFilled = useMemo(() => scrims.reduce((sum, s) => sum + s.slotsFilled, 0), [scrims]);
  const totalSlotsCap = useMemo(() => scrims.reduce((sum, s) => sum + s.totalSlots, 0), [scrims]);

  const chartData = useMemo(
    () =>
      scrims.map((s) => ({
        name: s.title.slice(0, 14),
        filled: s.slotsFilled,
        capacity: s.totalSlots,
        revenue: s.slotsFilled * s.entryFee,
      })),
    [scrims]
  );

  // --- Scrim Editor State ---
  const [editingScrimId, setEditingScrimId] = useState<string | null>(null);
  const [scrimTitle, setScrimTitle] = useState('');
  const [scrimMap, setScrimMap] = useState<ScrimMap>('Bermuda');
  const [scrimMode, setScrimMode] = useState<ScrimMode>('Squad');
  const [scrimFee, setScrimFee] = useState(200);
  const [scrimPrize, setScrimPrize] = useState(2500);
  const [scrimSlots, setScrimSlots] = useState(12);
  const [scrimDate, setScrimDate] = useState(() => new Date(Date.now() + 3 * 3600_000).toISOString().slice(0, 16));
  const [scrimStatus, setScrimStatus] = useState<ScrimStatus>('Open');
  const [roomIdInput, setRoomIdInput] = useState('');
  const [roomPassInput, setRoomPassInput] = useState('');
  const [roomReleasedToggle, setRoomReleasedToggle] = useState(false);

  const loadScrimForEdit = async (s: Scrim) => {
    setEditingScrimId(s.id);
    setScrimTitle(s.title);
    setScrimMap(s.map);
    setScrimMode(s.mode);
    setScrimFee(s.entryFee);
    setScrimPrize(s.prizePool);
    setScrimSlots(s.totalSlots);
    setScrimDate(s.dateTimeISO.slice(0, 16));
    setScrimStatus(s.status);
    setRoomReleasedToggle(Boolean(s.roomReleased));
    const room = await fetchScrimRoomCredentials(s.id);
    setRoomIdInput(room?.roomId || '');
    setRoomPassInput(room?.roomPassword || '');
  };

  const buildScrimPayload = (): Scrim => {
    const existing = scrims.find((s) => s.id === editingScrimId);
    const matchDt = new Date(scrimDate);
    const releaseDt = new Date(matchDt.getTime() - 10 * 60_000);
    const mapBanner =
      scrimMap === 'Purgatory'
        ? '/src/assets/images/scrim_purgatory_banner_1795758509128.jpg'
        : scrimMap === 'Kalahari'
          ? '/src/assets/images/scrim_kalahari_banner_1795758509869.jpg'
          : '/src/assets/images/scrim_bermuda_banner_1795758509070.jpg';

    return {
      id: editingScrimId || makeSafeId('scrim'),
      title: scrimTitle.trim(),
      bannerUrl: existing?.bannerUrl || mapBanner,
      map: scrimMap,
      mode: scrimMode,
      dateTimeISO: matchDt.toISOString(),
      registrationOpensAtISO: existing?.registrationOpensAtISO || new Date().toISOString(),
      roomReleaseAtISO: releaseDt.toISOString(),
      entryFee: Number(scrimFee),
      currency: existing?.currency || 'NPR',
      prizePool: Number(scrimPrize),
      prizeDistribution: existing?.prizeDistribution || [
        { rank: 1, label: '1st Place', amount: Math.round(scrimPrize * 0.55) },
        { rank: 2, label: '2nd Place', amount: Math.round(scrimPrize * 0.3) },
        { rank: 3, label: '3rd Place', amount: Math.round(scrimPrize * 0.15) },
      ],
      totalSlots: Number(scrimSlots),
      slotsFilled: existing?.slotsFilled ?? 0,
      status: scrimStatus,
      rules: existing?.rules || ['Mobile only, no emulators.', 'Join room 5 minutes prior.'],
      pointsSystem: existing?.pointsSystem || DEFAULT_POINTS_SYSTEM,
      roomReleased: roomReleasedToggle,
    };
  };

  const handleSaveScrim = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!scrimTitle.trim()) return;
    const isNew = !editingScrimId;
    const scrimPayload = buildScrimPayload();

    await adminSaveScrim(
      scrimPayload,
      isNew,
      roomIdInput.trim() ? { roomId: roomIdInput.trim(), roomPassword: roomPassInput.trim() || 'SX2026' } : undefined
    );
    setEditingScrimId(null);
    setScrimTitle('');
    setRoomIdInput('');
    setRoomPassInput('');
    setRoomReleasedToggle(false);
    pushToast({ type: 'success', title: isNew ? 'Scrim created' : 'Scrim updated' });
  };

  const handleSaveAndPushScrimRoom = async () => {
    if (!scrimTitle.trim() || !roomIdInput.trim()) {
      pushToast({
        type: 'error',
        title: 'Room ID Required',
        description: 'Enter a Scrim Title and Scrim Room ID Code before pushing to registered teams.',
      });
      return;
    }
    const isNew = !editingScrimId;
    const scrimPayload = { ...buildScrimPayload(), roomReleased: true };
    const cleanPass = roomPassInput.trim() || 'SX2026';
    await adminSaveScrim(scrimPayload, isNew, {
      roomId: roomIdInput.trim(),
      roomPassword: cleanPass,
    });
    const pushedCount = await adminPushRoomToScrimTeams({
      scrim: scrimPayload,
      registrations,
      roomId: roomIdInput.trim(),
      roomPassword: cleanPass,
    });
    setEditingScrimId(null);
    setScrimTitle('');
    setRoomIdInput('');
    setRoomPassInput('');
    setRoomReleasedToggle(false);
    pushToast({
      type: 'success',
      title: 'Scrim Saved & ID/Pass Pushed',
      description: `Placed Room ID & Passcode onto ${pushedCount || 0} registered team(s).`,
    });
  };

  // --- Payment Methods State ---
  const [pmName, setPmName] = useState('');
  const [pmType, setPmType] = useState<PaymentMethodType>('eSewa');
  const [pmAccName, setPmAccName] = useState('');
  const [pmAccNum, setPmAccNum] = useState('');
  const [pmQr, setPmQr] = useState('');

  const handlePmQrUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (!f) return;
    const c = await compressImageToDataUrl(f, { maxWidth: 320, maxHeight: 320, quality: 0.85 });
    setPmQr(c.dataUrl);
  };

  const handleAddPaymentMethod = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!pmName.trim() || !pmAccName.trim() || !pmAccNum.trim()) return;
    const pm: PaymentMethod = {
      id: makeSafeId('pm'),
      name: pmName.trim(),
      type: pmType,
      accountName: pmAccName.trim(),
      accountNumber: pmAccNum.trim(),
      qrImageDataUrl: pmQr,
      enabled: true,
    };
    await adminSavePaymentMethod(pm, true);
    setPmName('');
    setPmAccName('');
    setPmAccNum('');
    setPmQr('');
    pushToast({ type: 'success', title: 'Payment method added' });
  };

  // --- Manual Review State ---
  const [zoomImg, setZoomImg] = useState<string | null>(null);
  const [reviewReasons, setReviewReasons] = useState<Record<string, string>>({});

  // --- Teams Table Filters, Password Manager & Room ID/Pass Placement ---
  const [teamScrimFilter, setTeamScrimFilter] = useState('all');
  const [teamSearch, setTeamSearch] = useState('');
  const [editingPwRegId, setEditingPwRegId] = useState<string | null>(null);
  const [adminPwInput, setAdminPwInput] = useState('');
  const [editingRoomRegId, setEditingRoomRegId] = useState<string | null>(null);
  const [adminRoomIdInput, setAdminRoomIdInput] = useState('');
  const [adminRoomPassInput, setAdminRoomPassInput] = useState('');
  const [bulkScrimId, setBulkScrimId] = useState(scrims[0]?.id || '');
  const [bulkRoomId, setBulkRoomId] = useState('');
  const [bulkRoomPass, setBulkRoomPass] = useState('');

  const handleOpenTeamRoomEditor = async (reg: Registration) => {
    setEditingRoomRegId(reg.id);
    if (reg.assignedRoomId) {
      setAdminRoomIdInput(reg.assignedRoomId);
      setAdminRoomPassInput(reg.assignedRoomPassword || '');
      return;
    }
    const scrimRoom = await fetchScrimRoomCredentials(reg.scrimId);
    setAdminRoomIdInput(scrimRoom?.roomId || '');
    setAdminRoomPassInput(scrimRoom?.roomPassword || '');
  };

  const handleSaveTeamRoomCredentials = async (reg: Registration) => {
    if (!adminRoomIdInput.trim()) {
      pushToast({ type: 'error', title: 'Enter Scrim ID Code' });
      return;
    }
    await adminAssignTeamRoomCredentials({
      registration: reg,
      roomId: adminRoomIdInput.trim(),
      roomPassword: adminRoomPassInput.trim(),
    });
    setEditingRoomRegId(null);
    setAdminRoomIdInput('');
    setAdminRoomPassInput('');
    pushToast({
      type: 'success',
      title: `Scrim ID & Pass placed on ${reg.teamName}`,
      description: 'Captain notified with the Room ID Code & Passcode.',
    });
  };

  const handleClearTeamRoomCredentials = async (reg: Registration) => {
    await adminAssignTeamRoomCredentials({
      registration: reg,
      roomId: '',
      roomPassword: '',
    });
    setEditingRoomRegId(null);
    setAdminRoomIdInput('');
    setAdminRoomPassInput('');
    pushToast({ type: 'info', title: `Cleared Scrim ID & Pass from ${reg.teamName}` });
  };

  const handleBulkPushRoomToScrim = async (e: React.FormEvent) => {
    e.preventDefault();
    const targetScrim = scrims.find((s) => s.id === (teamScrimFilter !== 'all' ? teamScrimFilter : bulkScrimId));
    if (!targetScrim || !bulkRoomId.trim()) {
      pushToast({ type: 'error', title: 'Select a scrim and enter Scrim Room ID Code' });
      return;
    }
    const count = await adminPushRoomToScrimTeams({
      scrim: targetScrim,
      registrations,
      roomId: bulkRoomId.trim(),
      roomPassword: bulkRoomPass.trim() || 'SX2026',
    });
    setBulkRoomId('');
    setBulkRoomPass('');
    pushToast({
      type: 'success',
      title: `ID & Pass Placed on ${count || 0} Team(s)`,
      description: `All active registered teams in ${targetScrim.title} received the Room ID & Passcode.`,
    });
  };

  const handleAdminSetTeamPassword = async (reg: Registration) => {
    const check = validateTeamPassword(adminPwInput);
    if (!check.valid) {
      pushToast({ type: 'error', title: 'Invalid Password', description: check.error });
      return;
    }
    const hash = await hashTeamPassword(adminPwInput);
    await updateRegisteredTeamPassword({
      registrationId: reg.id,
      scrimId: reg.scrimId,
      hasTeamPassword: true,
      teamPasswordHash: hash,
    });
    setEditingPwRegId(null);
    setAdminPwInput('');
    pushToast({ type: 'success', title: `Password set for ${reg.teamName}` });
  };

  const handleAdminClearTeamPassword = async (reg: Registration) => {
    await updateRegisteredTeamPassword({
      registrationId: reg.id,
      scrimId: reg.scrimId,
      hasTeamPassword: false,
      teamPasswordHash: '',
    });
    setEditingPwRegId(null);
    setAdminPwInput('');
    pushToast({ type: 'info', title: `Password lock cleared for ${reg.teamName}` });
  };

  const filteredTeams = useMemo(() => {
    return registrations.filter((r) => {
      if (teamScrimFilter !== 'all' && r.scrimId !== teamScrimFilter) return false;
      if (teamSearch.trim()) {
        const q = teamSearch.toLowerCase();
        return (
          r.teamName.toLowerCase().includes(q) ||
          r.captainUid.includes(q) ||
          r.players.some((p) => p.uid.includes(q) || p.ign.toLowerCase().includes(q))
        );
      }
      return true;
    });
  }, [registrations, teamScrimFilter, teamSearch]);

  // --- Ledger Manual Entry ---
  const [ledgerScrimId, setLedgerScrimId] = useState(scrims[0]?.id || '');
  const [ledgerTeamName, setLedgerTeamName] = useState('');
  const [ledgerAmount, setLedgerAmount] = useState(200);
  const [ledgerMethod, setLedgerMethod] = useState('Cash / Manual');
  const [ledgerFilterStatus, setLedgerFilterStatus] = useState('all');

  const handleAddManualLedger = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !ledgerTeamName.trim()) return;
    const scrim = scrims.find((s) => s.id === ledgerScrimId);
    const txn: TransactionRecord = {
      id: makeSafeId('txn'),
      userId: user.uid,
      scrimId: ledgerScrimId,
      scrimTitle: scrim?.title || 'Manual Entry',
      teamName: ledgerTeamName.trim(),
      amount: Number(ledgerAmount),
      currency: scrim?.currency || 'NPR',
      method: ledgerMethod,
      transactionId: `MANUAL-${Date.now().toString().slice(-6)}`,
      status: 'manual',
      notes: 'Added by organizer',
    };
    await adminSaveTransaction(txn, true);
    setLedgerTeamName('');
    pushToast({ type: 'success', title: 'Manual ledger entry added' });
  };

  // --- Announcements ---
  const [annTitle, setAnnTitle] = useState('');
  const [annMsg, setAnnMsg] = useState('');
  const [annPriority, setAnnPriority] = useState<'normal' | 'urgent'>('normal');

  const handlePushAnnouncement = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!annTitle.trim() || !annMsg.trim()) return;
    await adminPushAnnouncement({
      id: makeSafeId('ann'),
      title: annTitle.trim(),
      message: annMsg.trim(),
      priority: annPriority,
      createdBy: user?.email || 'Admin',
    });
    setAnnTitle('');
    setAnnMsg('');
    pushToast({ type: 'success', title: 'Announcement pushed to all captains' });
  };

  // --- Results Entry ---
  const [resScrimId, setResScrimId] = useState(scrims[0]?.id || '');

  useEffect(() => {
    if (scrims.length > 0) {
      if (!ledgerScrimId) setLedgerScrimId(scrims[0].id);
      if (!resScrimId) setResScrimId(scrims[0].id);
      if (!bulkScrimId) setBulkScrimId(scrims[0].id);
    }
  }, [scrims, ledgerScrimId, resScrimId, bulkScrimId]);
  const [resTeamName, setResTeamName] = useState('');
  const [resPlacement, setResPlacement] = useState(1);
  const [resKills, setResKills] = useState(5);
  const [resPrize, setResPrize] = useState(0);
  const [resPayoutRef, setResPayoutRef] = useState('');

  const handleSaveResult = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!resTeamName.trim() || !resScrimId) return;
    const scrim = scrims.find((s) => s.id === resScrimId);
    const pts = calculateTeamPoints(resPlacement, resKills, scrim?.pointsSystem || DEFAULT_POINTS_SYSTEM);
    await adminSaveResult({
      id: makeSafeId('res'),
      scrimId: resScrimId,
      teamName: resTeamName.trim(),
      placement: Number(resPlacement),
      kills: Number(resKills),
      placementPoints: pts.placementPoints,
      killPoints: pts.killPoints,
      totalPoints: pts.totalPoints,
      prizeAmount: Number(resPrize),
      prizePaid: Boolean(resPayoutRef.trim()),
      payoutReference: resPayoutRef.trim(),
    });
    setResTeamName('');
    setResPayoutRef('');
    pushToast({ type: 'success', title: 'Result saved and points calculated' });
  };

  const tabs: { id: AdminSection; label: string }[] = [
    { id: 'dashboard', label: 'Dashboard' },
    { id: 'scrims', label: 'Scrims' },
    { id: 'payments', label: 'Payment Methods' },
    { id: 'review', label: `Review Queue (${pendingReviewRegs.length})` },
    { id: 'teams', label: 'Teams & Export' },
    { id: 'ledger', label: 'Ledger' },
    { id: 'fraud', label: `Fraud Log (${fraudLogs.length})` },
    { id: 'announcements', label: 'Notices' },
    { id: 'results', label: 'Results & Payouts' },
  ];

  const scrimsMap = useMemo(() => Object.fromEntries(scrims.map((s) => [s.id, s])), [scrims]);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-3xl font-bold text-zinc-900 dark:text-white">Organizer Admin Console</h1>
        <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-0.5">
          Manage scrim lobbies, AI verification queue, payment channels, fraud controls, and prize payouts.
        </p>
      </div>

      {/* Horizontal Admin Navigation Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
        {tabs.map((t) => (
          <button
            key={t.id}
            type="button"
            onClick={() => setSection(t.id)}
            className={`min-h-[38px] px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap shrink-0 transition-colors ${
              section === t.id
                ? 'bg-[#FF6A00] text-white'
                : 'bg-white dark:bg-[#14141C] border border-zinc-200 dark:border-white/10 text-zinc-700 dark:text-zinc-300 hover:border-[#FF6A00]/50'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* 1. Dashboard */}
      {section === 'dashboard' && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
            <StatCard label="Total Revenue" value={`NPR ${totalRevenue}`} accent />
            <StatCard label="Registrations" value={String(registrations.length)} />
            <StatCard label="Pending Reviews" value={String(pendingReviewRegs.length)} />
            <StatCard label="Slots Filled" value={`${totalSlotsFilled}/${totalSlotsCap}`} />
            <StatCard label="Fraud Alerts" value={String(fraudLogs.length)} danger={fraudLogs.length > 0} />
          </div>

          <div className="rounded-2xl bg-white dark:bg-[#14141C] border border-zinc-200 dark:border-white/10 p-6">
            <h2 className="font-display text-xl font-bold text-zinc-900 dark:text-white mb-4">
              Scrim Slot Fill &amp; Revenue Overview
            </h2>
            <div className="h-72 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(160,160,180,0.15)" />
                  <XAxis dataKey="name" tick={{ fontSize: 11, fill: '#9ca3af' }} />
                  <YAxis tick={{ fontSize: 11, fill: '#9ca3af' }} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#14141C',
                      borderColor: 'rgba(255,255,255,0.1)',
                      borderRadius: '12px',
                      color: '#fff',
                    }}
                  />
                  <Bar dataKey="filled" name="Slots Filled" fill="#FF6A00" radius={[6, 6, 0, 0]} />
                  <Bar dataKey="capacity" name="Total Slots" fill="#3f3f46" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      )}

      {/* 2. Scrims CRUD */}
      {section === 'scrims' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <form
            onSubmit={handleSaveScrim}
            className="lg:col-span-5 rounded-2xl bg-white dark:bg-[#14141C] border border-zinc-200 dark:border-white/10 p-6 space-y-4"
          >
            <h2 className="font-display text-xl font-bold text-zinc-900 dark:text-white">
              {editingScrimId ? 'Edit Scrim' : 'Create New Scrim'}
            </h2>
            <div>
              <label htmlFor="adm-scrim-title" className="block text-xs font-medium text-zinc-500 mb-1">
                Scrim Title
              </label>
              <input
                id="adm-scrim-title"
                required
                value={scrimTitle}
                onChange={(e) => setScrimTitle(e.target.value)}
                placeholder="SX Weekend Clash"
                className="w-full min-h-[40px] px-3 py-2 rounded-xl bg-zinc-50 dark:bg-[#0A0A0F] border border-zinc-200 dark:border-white/10 text-sm text-zinc-900 dark:text-white"
              />
            </div>

            <div className="grid grid-cols-3 gap-3">
              <div>
                <label htmlFor="adm-scrim-map" className="block text-xs font-medium text-zinc-500 mb-1">Map</label>
                <select
                  id="adm-scrim-map"
                  value={scrimMap}
                  onChange={(e) => setScrimMap(e.target.value as ScrimMap)}
                  className="w-full min-h-[40px] px-2.5 py-2 rounded-xl bg-zinc-50 dark:bg-[#0A0A0F] border border-zinc-200 dark:border-white/10 text-xs text-zinc-900 dark:text-white"
                >
                  <option value="Bermuda">Bermuda</option>
                  <option value="Purgatory">Purgatory</option>
                  <option value="Kalahari">Kalahari</option>
                  <option value="Alpine">Alpine</option>
                  <option value="NeXTerra">NeXTerra</option>
                </select>
              </div>
              <div>
                <label htmlFor="adm-scrim-mode" className="block text-xs font-medium text-zinc-500 mb-1">Mode</label>
                <select
                  id="adm-scrim-mode"
                  value={scrimMode}
                  onChange={(e) => setScrimMode(e.target.value as ScrimMode)}
                  className="w-full min-h-[40px] px-2.5 py-2 rounded-xl bg-zinc-50 dark:bg-[#0A0A0F] border border-zinc-200 dark:border-white/10 text-xs text-zinc-900 dark:text-white"
                >
                  <option value="Squad">Squad</option>
                  <option value="Duo">Duo</option>
                  <option value="Solo">Solo</option>
                </select>
              </div>
              <div>
                <label htmlFor="adm-scrim-status" className="block text-xs font-medium text-zinc-500 mb-1">Status</label>
                <select
                  id="adm-scrim-status"
                  value={scrimStatus}
                  onChange={(e) => setScrimStatus(e.target.value as ScrimStatus)}
                  className="w-full min-h-[40px] px-2.5 py-2 rounded-xl bg-zinc-50 dark:bg-[#0A0A0F] border border-zinc-200 dark:border-white/10 text-xs text-zinc-900 dark:text-white"
                >
                  <option value="Open">Open</option>
                  <option value="Filling Fast">Filling Fast</option>
                  <option value="Full">Full</option>
                  <option value="Live">Live</option>
                  <option value="Completed">Completed</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-3">
              <div>
                <label htmlFor="adm-fee" className="block text-xs font-medium text-zinc-500 mb-1">Fee</label>
                <input
                  id="adm-fee"
                  type="number"
                  value={scrimFee}
                  onChange={(e) => setScrimFee(Number(e.target.value))}
                  className="w-full min-h-[40px] px-3 py-2 rounded-xl bg-zinc-50 dark:bg-[#0A0A0F] border border-zinc-200 dark:border-white/10 font-mono text-xs text-zinc-900 dark:text-white"
                />
              </div>
              <div>
                <label htmlFor="adm-prize" className="block text-xs font-medium text-zinc-500 mb-1">Prize Pool</label>
                <input
                  id="adm-prize"
                  type="number"
                  value={scrimPrize}
                  onChange={(e) => setScrimPrize(Number(e.target.value))}
                  className="w-full min-h-[40px] px-3 py-2 rounded-xl bg-zinc-50 dark:bg-[#0A0A0F] border border-zinc-200 dark:border-white/10 font-mono text-xs text-zinc-900 dark:text-white"
                />
              </div>
              <div>
                <label htmlFor="adm-slots" className="block text-xs font-medium text-zinc-500 mb-1">Slots</label>
                <input
                  id="adm-slots"
                  type="number"
                  value={scrimSlots}
                  onChange={(e) => setScrimSlots(Number(e.target.value))}
                  className="w-full min-h-[40px] px-3 py-2 rounded-xl bg-zinc-50 dark:bg-[#0A0A0F] border border-zinc-200 dark:border-white/10 font-mono text-xs text-zinc-900 dark:text-white"
                />
              </div>
            </div>

            <div>
              <label htmlFor="adm-dt" className="block text-xs font-medium text-zinc-500 mb-1">
                Match Start Time (Room auto-releases 10 min prior)
              </label>
              <input
                id="adm-dt"
                type="datetime-local"
                value={scrimDate}
                onChange={(e) => setScrimDate(e.target.value)}
                className="w-full min-h-[40px] px-3 py-2 rounded-xl bg-zinc-50 dark:bg-[#0A0A0F] border border-zinc-200 dark:border-white/10 font-mono text-xs text-zinc-900 dark:text-white"
              />
            </div>

            <div className="rounded-xl bg-zinc-50 dark:bg-[#0A0A0F] border border-[#FF6A00]/30 p-3.5 space-y-3">
              <div className="flex items-center gap-2 text-xs font-semibold text-zinc-900 dark:text-white">
                <KeyRound className="w-4 h-4 text-[#FF6A00]" />
                Scrim ID Code &amp; Passcode (Custom Room)
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label htmlFor="adm-room-id" className="block text-xs font-medium text-zinc-500 mb-1">
                    Room ID Code
                  </label>
                  <input
                    id="adm-room-id"
                    value={roomIdInput}
                    onChange={(e) => setRoomIdInput(e.target.value)}
                    placeholder="88912045"
                    className="w-full min-h-[40px] px-3 py-2 rounded-xl bg-white dark:bg-[#14141C] border border-zinc-200 dark:border-white/10 font-mono text-xs text-zinc-900 dark:text-white"
                  />
                </div>
                <div>
                  <label htmlFor="adm-room-pass" className="block text-xs font-medium text-zinc-500 mb-1">
                    Room Passcode
                  </label>
                  <input
                    id="adm-room-pass"
                    value={roomPassInput}
                    onChange={(e) => setRoomPassInput(e.target.value)}
                    placeholder="SX2026"
                    className="w-full min-h-[40px] px-3 py-2 rounded-xl bg-white dark:bg-[#14141C] border border-zinc-200 dark:border-white/10 font-mono text-xs text-zinc-900 dark:text-white"
                  />
                </div>
              </div>

              <label className="flex items-center gap-2 text-xs text-zinc-700 dark:text-zinc-300">
                <input
                  type="checkbox"
                  checked={roomReleasedToggle}
                  onChange={(e) => setRoomReleasedToggle(e.target.checked)}
                />
                Release ID &amp; Passcode to confirmed teams immediately
              </label>
            </div>

            <div className="flex flex-wrap gap-2">
              <button
                type="submit"
                className="flex-1 min-h-[42px] px-4 py-2 rounded-xl bg-[#FF6A00] text-white text-xs font-semibold"
              >
                {editingScrimId ? 'Save Changes' : 'Create Scrim'}
              </button>
              <button
                type="button"
                onClick={handleSaveAndPushScrimRoom}
                className="min-h-[42px] px-3.5 py-2 rounded-xl border border-[#FF6A00] text-[#FF6A00] hover:bg-[#FF6A00]/10 text-xs font-semibold inline-flex items-center gap-1.5"
              >
                <Send className="w-3.5 h-3.5" />
                Save &amp; Push ID/Pass
              </button>
              {editingScrimId && (
                <button
                  type="button"
                  onClick={() => {
                    setEditingScrimId(null);
                    setScrimTitle('');
                    setRoomIdInput('');
                    setRoomPassInput('');
                    setRoomReleasedToggle(false);
                  }}
                  className="min-h-[42px] px-4 py-2 rounded-xl border border-zinc-200 dark:border-white/10 text-xs font-semibold"
                >
                  Cancel
                </button>
              )}
            </div>
          </form>

          <div className="lg:col-span-7 space-y-3">
            {scrims.length === 0 ? (
              <div className="rounded-2xl bg-white dark:bg-[#14141C] border border-zinc-200 dark:border-white/10 p-8 text-center text-xs text-zinc-500">
                No scrims created yet. Use the form on the left to publish a scrim and set its Room ID Code &amp; Passcode.
              </div>
            ) : (
              scrims.map((s) => (
                <div
                  key={s.id}
                  className="rounded-2xl bg-white dark:bg-[#14141C] border border-zinc-200 dark:border-white/10 p-4 flex items-center justify-between gap-4"
                >
                  <div>
                    <h3 className="font-display text-lg font-bold text-zinc-900 dark:text-white">{s.title}</h3>
                    <p className="text-xs text-zinc-500">
                      {s.map} · {s.mode} · {s.slotsFilled}/{s.totalSlots} slots · {s.status} ·{' '}
                      <span className={s.roomReleased ? 'text-emerald-500 font-semibold' : 'text-amber-500'}>
                        {s.roomReleased ? 'ID/Pass Released' : 'ID/Pass Scheduled'}
                      </span>
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => loadScrimForEdit(s)}
                      className="min-h-[36px] px-3 py-1.5 rounded-lg border border-zinc-200 dark:border-white/10 text-xs font-semibold hover:border-[#FF6A00]"
                    >
                      Edit / ID Pass
                    </button>
                    <button
                      type="button"
                      onClick={() => adminDeleteScrim(s.id)}
                      aria-label={`Delete ${s.title}`}
                      className="min-h-[36px] p-2 rounded-lg text-zinc-400 hover:text-[#FF2A2A]"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* 3. Payment Methods Manager */}
      {section === 'payments' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <form
            onSubmit={handleAddPaymentMethod}
            className="lg:col-span-5 rounded-2xl bg-white dark:bg-[#14141C] border border-zinc-200 dark:border-white/10 p-6 space-y-4"
          >
            <h2 className="font-display text-xl font-bold text-zinc-900 dark:text-white">Add Payment Method</h2>
            <input
              required
              value={pmName}
              onChange={(e) => setPmName(e.target.value)}
              placeholder="Display Name (e.g. eSewa Official)"
              className="w-full min-h-[40px] px-3 py-2 rounded-xl bg-zinc-50 dark:bg-[#0A0A0F] border border-zinc-200 dark:border-white/10 text-sm"
            />
            <select
              value={pmType}
              onChange={(e) => setPmType(e.target.value as PaymentMethodType)}
              className="w-full min-h-[40px] px-3 py-2 rounded-xl bg-zinc-50 dark:bg-[#0A0A0F] border border-zinc-200 dark:border-white/10 text-sm"
            >
              <option value="eSewa">eSewa</option>
              <option value="Khalti">Khalti</option>
              <option value="UPI">UPI</option>
              <option value="bKash">bKash</option>
              <option value="Bank">Bank</option>
            </select>
            <input
              required
              value={pmAccName}
              onChange={(e) => setPmAccName(e.target.value)}
              placeholder="Account Holder Name"
              className="w-full min-h-[40px] px-3 py-2 rounded-xl bg-zinc-50 dark:bg-[#0A0A0F] border border-zinc-200 dark:border-white/10 text-sm"
            />
            <input
              required
              value={pmAccNum}
              onChange={(e) => setPmAccNum(e.target.value)}
              placeholder="Phone / UPI ID / Account Number"
              className="w-full min-h-[40px] px-3 py-2 rounded-xl bg-zinc-50 dark:bg-[#0A0A0F] border border-zinc-200 dark:border-white/10 font-mono text-sm"
            />
            <div>
              <label htmlFor="pm-qr-upload" className="block text-xs text-zinc-500 mb-1">QR Code Image (optional)</label>
              <input id="pm-qr-upload" type="file" accept="image/*" onChange={handlePmQrUpload} className="text-xs" />
            </div>
            <button type="submit" className="w-full min-h-[42px] rounded-xl bg-[#FF6A00] text-white text-xs font-semibold">
              Add Payment Channel
            </button>
          </form>

          <div className="lg:col-span-7 space-y-3">
            {paymentMethods.map((pm) => (
              <div
                key={pm.id}
                className="rounded-2xl bg-white dark:bg-[#14141C] border border-zinc-200 dark:border-white/10 p-4 flex items-center justify-between gap-4"
              >
                <div>
                  <div className="text-sm font-bold text-zinc-900 dark:text-white">
                    {pm.name} ({pm.type})
                  </div>
                  <div className="text-xs font-mono text-zinc-500">
                    {pm.accountName} · {pm.accountNumber}
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => adminSavePaymentMethod({ ...pm, enabled: !pm.enabled }, false)}
                    className={`min-h-[34px] px-3 rounded-lg text-xs font-semibold ${
                      pm.enabled ? 'bg-emerald-500/15 text-emerald-500' : 'bg-zinc-200 dark:bg-white/10 text-zinc-500'
                    }`}
                  >
                    {pm.enabled ? 'Enabled' : 'Disabled'}
                  </button>
                  <button
                    type="button"
                    onClick={() => adminDeletePaymentMethod(pm.id)}
                    aria-label={`Delete ${pm.name}`}
                    className="p-2 text-zinc-400 hover:text-[#FF2A2A]"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 4. Manual Review Queue */}
      {section === 'review' && (
        <div className="space-y-4">
          {pendingReviewRegs.length === 0 ? (
            <div className="rounded-2xl bg-white dark:bg-[#14141C] border border-zinc-200 dark:border-white/10 p-10 text-center">
              <CheckCircle2 className="w-8 h-8 text-emerald-500 mx-auto mb-2" />
              <p className="text-sm font-semibold text-zinc-900 dark:text-white">Manual Review Queue Clear</p>
            </div>
          ) : (
            pendingReviewRegs.map((reg) => (
              <div
                key={reg.id}
                className="rounded-2xl bg-white dark:bg-[#14141C] border border-zinc-200 dark:border-white/10 p-5 grid grid-cols-1 lg:grid-cols-12 gap-5"
              >
                <div className="lg:col-span-4">
                  {reg.screenshotDataUrl ? (
                    <button
                      type="button"
                      onClick={() => setZoomImg(reg.screenshotDataUrl || null)}
                      className="relative group w-full rounded-xl overflow-hidden border border-zinc-200 dark:border-white/10"
                    >
                      <img
                        src={reg.screenshotDataUrl}
                        alt={`Receipt for ${reg.teamName}`}
                        className="w-full h-56 object-contain bg-black"
                      />
                      <span className="absolute bottom-2 right-2 px-2.5 py-1 rounded-lg bg-black/75 text-white text-[11px] inline-flex items-center gap-1">
                        <ZoomIn className="w-3.5 h-3.5" /> Zoom
                      </span>
                    </button>
                  ) : (
                    <div className="h-56 rounded-xl bg-zinc-100 dark:bg-[#0A0A0F] flex items-center justify-center text-xs text-zinc-500">
                      No screenshot stored
                    </div>
                  )}
                </div>

                <div className="lg:col-span-8 space-y-4">
                  <div>
                    <h3 className="font-display text-2xl font-bold text-zinc-900 dark:text-white">
                      {reg.teamName} · {reg.scrimTitle}
                    </h3>
                    <p className="text-xs text-zinc-500">
                      Captain: {reg.captainName} ({reg.captainUid}) · {reg.captainPhone}
                    </p>
                  </div>

                  {reg.aiResult && (
                    <div className="rounded-xl bg-zinc-50 dark:bg-[#0A0A0F] border border-zinc-200 dark:border-white/8 p-3.5 grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                      <div>
                        <span className="text-zinc-500 block">AI Amount</span>
                        <span className="font-mono font-bold">
                          {reg.aiResult.currency} {reg.aiResult.amount}
                        </span>
                      </div>
                      <div>
                        <span className="text-zinc-500 block">Txn ID</span>
                        <span className="font-mono font-bold">{reg.aiResult.transaction_id || '—'}</span>
                      </div>
                      <div>
                        <span className="text-zinc-500 block">Receiver</span>
                        <span className="font-semibold truncate block">{reg.aiResult.receiver_name_or_number || '—'}</span>
                      </div>
                      <div>
                        <span className="text-zinc-500 block">Confidence</span>
                        <span className="font-mono font-bold text-[#FF6A00]">{reg.aiResult.confidence}%</span>
                      </div>
                    </div>
                  )}

                  {reg.reviewNotes && <p className="text-xs text-amber-500">{reg.reviewNotes}</p>}

                  <div className="flex flex-col sm:flex-row gap-2.5">
                    <input
                      type="text"
                      value={reviewReasons[reg.id] || ''}
                      onChange={(e) => setReviewReasons((prev) => ({ ...prev, [reg.id]: e.target.value }))}
                      placeholder="Approval note or rejection reason..."
                      className="flex-1 min-h-[40px] px-3 py-2 rounded-xl bg-zinc-50 dark:bg-[#0A0A0F] border border-zinc-200 dark:border-white/10 text-xs"
                    />
                    <button
                      type="button"
                      onClick={() =>
                        adminReviewRegistration({
                          registration: reg,
                          scrim: scrimsMap[reg.scrimId],
                          approve: true,
                          reason: reviewReasons[reg.id] || 'Approved by organizer.',
                        })
                      }
                      className="min-h-[40px] px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold inline-flex items-center gap-1.5"
                    >
                      <CheckCircle2 className="w-4 h-4" /> Approve
                    </button>
                    <button
                      type="button"
                      onClick={() =>
                        adminReviewRegistration({
                          registration: reg,
                          scrim: scrimsMap[reg.scrimId],
                          approve: false,
                          reason: reviewReasons[reg.id] || 'Receipt could not be verified by organizer.',
                        })
                      }
                      className="min-h-[40px] px-4 py-2 rounded-xl bg-[#FF2A2A] hover:bg-red-700 text-white text-xs font-semibold inline-flex items-center gap-1.5"
                    >
                      <XCircle className="w-4 h-4" /> Reject
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* 5. Registered Teams & Export */}
      {section === 'teams' && (
        <div className="space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex flex-wrap items-center gap-2">
              <select
                value={teamScrimFilter}
                onChange={(e) => setTeamScrimFilter(e.target.value)}
                className="min-h-[40px] px-3 py-2 rounded-xl bg-white dark:bg-[#14141C] border border-zinc-200 dark:border-white/10 text-xs font-semibold"
              >
                <option value="all">All Scrims</option>
                {scrims.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.title}
                  </option>
                ))}
              </select>
              <input
                type="text"
                value={teamSearch}
                onChange={(e) => setTeamSearch(e.target.value)}
                placeholder="Search team or UID..."
                className="min-h-[40px] px-3 py-2 rounded-xl bg-white dark:bg-[#14141C] border border-zinc-200 dark:border-white/10 text-xs"
              />
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={() => exportRegistrationsCsv(filteredTeams)}
                className="min-h-[38px] px-3 py-1.5 rounded-xl border border-zinc-200 dark:border-white/10 text-xs font-semibold inline-flex items-center gap-1.5"
              >
                <FileText className="w-3.5 h-3.5 text-[#FF6A00]" /> CSV
              </button>
              <button
                type="button"
                onClick={() => exportRegistrationsExcel(filteredTeams)}
                className="min-h-[38px] px-3 py-1.5 rounded-xl border border-zinc-200 dark:border-white/10 text-xs font-semibold inline-flex items-center gap-1.5"
              >
                <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-500" /> Excel
              </button>
              <button
                type="button"
                onClick={() => exportRegistrationsPdf(filteredTeams)}
                className="min-h-[38px] px-3 py-1.5 rounded-xl border border-zinc-200 dark:border-white/10 text-xs font-semibold inline-flex items-center gap-1.5"
              >
                <Download className="w-3.5 h-3.5 text-sky-400" /> PDF
              </button>
              <button
                type="button"
                onClick={() => downloadAllTeamCards(filteredTeams, scrimsMap)}
                className="min-h-[38px] px-3.5 py-1.5 rounded-xl bg-[#FF6A00] text-white text-xs font-semibold inline-flex items-center gap-1.5"
              >
                <Download className="w-3.5 h-3.5" /> Download All Team Cards
              </button>
            </div>
          </div>

          {scrims.length > 0 && (
            <form
              onSubmit={handleBulkPushRoomToScrim}
              className="rounded-2xl bg-white dark:bg-[#14141C] border border-[#FF6A00]/30 p-4 grid grid-cols-1 sm:grid-cols-4 gap-3 items-end"
            >
              <div>
                <label htmlFor="bulk-room-scrim" className="block text-[11px] font-medium text-zinc-500 mb-1">
                  Push Scrim ID &amp; Pass to All Teams
                </label>
                <select
                  id="bulk-room-scrim"
                  value={teamScrimFilter !== 'all' ? teamScrimFilter : bulkScrimId}
                  onChange={(e) => {
                    setBulkScrimId(e.target.value);
                    setTeamScrimFilter(e.target.value);
                  }}
                  className="w-full min-h-[38px] px-3 py-1.5 rounded-xl bg-zinc-50 dark:bg-[#0A0A0F] border border-zinc-200 dark:border-white/10 text-xs font-semibold"
                >
                  {scrims.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.title}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label htmlFor="bulk-room-id" className="block text-[11px] font-medium text-zinc-500 mb-1">
                  Scrim Room ID Code
                </label>
                <input
                  id="bulk-room-id"
                  value={bulkRoomId}
                  onChange={(e) => setBulkRoomId(e.target.value)}
                  placeholder="88912045"
                  className="w-full min-h-[38px] px-3 py-1.5 rounded-xl bg-zinc-50 dark:bg-[#0A0A0F] border border-zinc-200 dark:border-white/10 font-mono text-xs"
                />
              </div>
              <div>
                <label htmlFor="bulk-room-pass" className="block text-[11px] font-medium text-zinc-500 mb-1">
                  Scrim Passcode
                </label>
                <input
                  id="bulk-room-pass"
                  value={bulkRoomPass}
                  onChange={(e) => setBulkRoomPass(e.target.value)}
                  placeholder="SX2026"
                  className="w-full min-h-[38px] px-3 py-1.5 rounded-xl bg-zinc-50 dark:bg-[#0A0A0F] border border-zinc-200 dark:border-white/10 font-mono text-xs"
                />
              </div>
              <button
                type="submit"
                className="min-h-[38px] px-4 py-1.5 rounded-xl bg-[#FF6A00] hover:bg-[#e55f00] text-white text-xs font-semibold inline-flex items-center justify-center gap-1.5"
              >
                <Send className="w-3.5 h-3.5" /> Place ID &amp; Pass on Scrim Teams
              </button>
            </form>
          )}

          <div className="rounded-2xl bg-white dark:bg-[#14141C] border border-zinc-200 dark:border-white/10 overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-zinc-200 dark:border-white/10 text-zinc-500">
                  <th className="py-3 px-4">Team</th>
                  <th className="py-3 px-4">Scrim</th>
                  <th className="py-3 px-4">Players &amp; UIDs</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4">Scrim ID &amp; Pass</th>
                  <th className="py-3 px-4">Pass Lock</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-200 dark:divide-white/8">
                {filteredTeams.map((r) => (
                  <tr key={r.id}>
                    <td className="py-3 px-4 font-semibold text-zinc-900 dark:text-white">{r.teamName}</td>
                    <td className="py-3 px-4 text-zinc-500">{r.scrimTitle || r.scrimId}</td>
                    <td className="py-3 px-4 font-mono text-[11px] text-zinc-400">
                      {r.players.map((p) => `${p.ign}:${p.uid}`).join(' · ')}
                    </td>
                    <td className="py-3 px-4 capitalize font-semibold">{r.status.replace('_', ' ')}</td>
                    <td className="py-3 px-4">
                      {editingRoomRegId === r.id ? (
                        <div className="flex flex-wrap items-center gap-1.5">
                          <input
                            type="text"
                            value={adminRoomIdInput}
                            maxLength={40}
                            onChange={(e) => setAdminRoomIdInput(e.target.value)}
                            placeholder="Room ID"
                            aria-label={`Scrim Room ID for ${r.teamName}`}
                            className="w-24 min-h-[30px] px-2 py-1 rounded-lg bg-zinc-50 dark:bg-[#0A0A0F] border border-zinc-200 dark:border-white/15 font-mono text-[11px]"
                          />
                          <input
                            type="text"
                            value={adminRoomPassInput}
                            maxLength={40}
                            onChange={(e) => setAdminRoomPassInput(e.target.value)}
                            placeholder="Passcode"
                            aria-label={`Scrim Passcode for ${r.teamName}`}
                            className="w-20 min-h-[30px] px-2 py-1 rounded-lg bg-zinc-50 dark:bg-[#0A0A0F] border border-zinc-200 dark:border-white/15 font-mono text-[11px]"
                          />
                          <button
                            type="button"
                            onClick={() => handleSaveTeamRoomCredentials(r)}
                            className="min-h-[30px] px-2 py-1 rounded-lg bg-[#FF6A00] text-white text-[11px] font-semibold"
                          >
                            Place
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              setEditingRoomRegId(null);
                              setAdminRoomIdInput('');
                              setAdminRoomPassInput('');
                            }}
                            className="min-h-[30px] px-2 py-1 rounded-lg border border-zinc-200 dark:border-white/10 text-[11px]"
                          >
                            Cancel
                          </button>
                        </div>
                      ) : (
                        <div className="flex flex-wrap items-center gap-2">
                          {r.assignedRoomId ? (
                            <span className="font-mono text-[11px] text-emerald-500 font-semibold">
                              {r.assignedRoomId} / {r.assignedRoomPassword || '—'}
                            </span>
                          ) : (
                            <span className="text-zinc-500">Not Placed</span>
                          )}
                          <button
                            type="button"
                            onClick={() => handleOpenTeamRoomEditor(r)}
                            className="text-[11px] font-semibold text-[#FF6A00] hover:underline"
                          >
                            {r.assignedRoomId ? 'Edit ID/Pass' : 'Place ID/Pass'}
                          </button>
                          {r.assignedRoomId && (
                            <button
                              type="button"
                              onClick={() => handleClearTeamRoomCredentials(r)}
                              className="text-[11px] font-semibold text-zinc-400 hover:text-[#FF2A2A]"
                            >
                              Clear
                            </button>
                          )}
                        </div>
                      )}
                    </td>
                    <td className="py-3 px-4">
                      {editingPwRegId === r.id ? (
                        <div className="flex items-center gap-1.5">
                          <input
                            type="text"
                            value={adminPwInput}
                            maxLength={SCHEMA_LIMITS.TEAM_PASSWORD_MAX}
                            onChange={(e) => setAdminPwInput(e.target.value)}
                            placeholder="4–32 chars"
                            aria-label={`Set password for ${r.teamName}`}
                            className="w-28 min-h-[30px] px-2 py-1 rounded-lg bg-zinc-50 dark:bg-[#0A0A0F] border border-zinc-200 dark:border-white/15 font-mono text-[11px]"
                          />
                          <button
                            type="button"
                            onClick={() => handleAdminSetTeamPassword(r)}
                            className="min-h-[30px] px-2 py-1 rounded-lg bg-[#FF6A00] text-white text-[11px] font-semibold"
                          >
                            Save
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              setEditingPwRegId(null);
                              setAdminPwInput('');
                            }}
                            className="min-h-[30px] px-2 py-1 rounded-lg border border-zinc-200 dark:border-white/10 text-[11px]"
                          >
                            Cancel
                          </button>
                        </div>
                      ) : (
                        <div className="flex items-center gap-2">
                          <span
                            className={`inline-flex items-center gap-1 font-semibold ${
                              r.hasTeamPassword ? 'text-emerald-500' : 'text-zinc-500'
                            }`}
                          >
                            {r.hasTeamPassword ? <Lock className="w-3 h-3" /> : <Unlock className="w-3 h-3" />}
                            {r.hasTeamPassword ? 'Protected' : 'Open'}
                          </span>
                          <button
                            type="button"
                            onClick={() => {
                              setEditingPwRegId(r.id);
                              setAdminPwInput('');
                            }}
                            className="text-[11px] font-semibold text-[#FF6A00] hover:underline"
                          >
                            {r.hasTeamPassword ? 'Reset' : 'Set'}
                          </button>
                          {r.hasTeamPassword && (
                            <button
                              type="button"
                              onClick={() => handleAdminClearTeamPassword(r)}
                              className="text-[11px] font-semibold text-zinc-400 hover:text-[#FF2A2A]"
                            >
                              Clear
                            </button>
                          )}
                        </div>
                      )}
                    </td>
                    <td className="py-3 px-4 text-right">
                      <button
                        type="button"
                        onClick={() => adminRemoveRegistration(r, scrimsMap[r.scrimId])}
                        className="text-xs font-semibold text-[#FF2A2A] hover:underline"
                      >
                        Remove
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 6. Transactions Ledger */}
      {section === 'ledger' && (
        <div className="space-y-5">
          <form
            onSubmit={handleAddManualLedger}
            className="rounded-2xl bg-white dark:bg-[#14141C] border border-zinc-200 dark:border-white/10 p-5 grid grid-cols-1 sm:grid-cols-5 gap-3 items-end"
          >
            <div>
              <label className="block text-xs text-zinc-500 mb-1">Scrim</label>
              <select
                value={ledgerScrimId}
                onChange={(e) => setLedgerScrimId(e.target.value)}
                className="w-full min-h-[40px] px-3 py-2 rounded-xl bg-zinc-50 dark:bg-[#0A0A0F] border border-zinc-200 dark:border-white/10 text-xs"
              >
                {scrims.map((s) => (
                  <option key={s.id} value={s.id}>{s.title}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs text-zinc-500 mb-1">Team Name</label>
              <input
                value={ledgerTeamName}
                onChange={(e) => setLedgerTeamName(e.target.value)}
                placeholder="Manual Squad"
                className="w-full min-h-[40px] px-3 py-2 rounded-xl bg-zinc-50 dark:bg-[#0A0A0F] border border-zinc-200 dark:border-white/10 text-xs"
              />
            </div>
            <div>
              <label className="block text-xs text-zinc-500 mb-1">Amount</label>
              <input
                type="number"
                value={ledgerAmount}
                onChange={(e) => setLedgerAmount(Number(e.target.value))}
                className="w-full min-h-[40px] px-3 py-2 rounded-xl bg-zinc-50 dark:bg-[#0A0A0F] border border-zinc-200 dark:border-white/10 font-mono text-xs"
              />
            </div>
            <div>
              <label className="block text-xs text-zinc-500 mb-1">Method</label>
              <input
                value={ledgerMethod}
                onChange={(e) => setLedgerMethod(e.target.value)}
                className="w-full min-h-[40px] px-3 py-2 rounded-xl bg-zinc-50 dark:bg-[#0A0A0F] border border-zinc-200 dark:border-white/10 text-xs"
              />
            </div>
            <button type="submit" className="min-h-[40px] px-4 py-2 rounded-xl bg-[#FF6A00] text-white text-xs font-semibold inline-flex items-center justify-center gap-1">
              <Plus className="w-3.5 h-3.5" /> Add Manual
            </button>
          </form>

          <div className="flex items-center gap-2">
            <select
              value={ledgerFilterStatus}
              onChange={(e) => setLedgerFilterStatus(e.target.value)}
              className="min-h-[38px] px-3 py-1.5 rounded-xl bg-white dark:bg-[#14141C] border border-zinc-200 dark:border-white/10 text-xs font-semibold"
            >
              <option value="all">All Statuses</option>
              <option value="verified">Verified</option>
              <option value="manual">Manual</option>
              <option value="pending">Pending</option>
              <option value="refunded">Refunded</option>
              <option value="rejected">Rejected</option>
            </select>
          </div>

          <div className="rounded-2xl bg-white dark:bg-[#14141C] border border-zinc-200 dark:border-white/10 overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-zinc-200 dark:border-white/10 text-zinc-500">
                  <th className="py-3 px-4">Scrim / Team</th>
                  <th className="py-3 px-4">Method / Txn ID</th>
                  <th className="py-3 px-4 text-right">Amount</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-200 dark:divide-white/8">
                {transactions
                  .filter((t) => ledgerFilterStatus === 'all' || t.status === ledgerFilterStatus)
                  .map((t) => (
                    <tr key={t.id}>
                      <td className="py-3 px-4 font-semibold">{t.scrimTitle} · {t.teamName}</td>
                      <td className="py-3 px-4 font-mono">{t.method} · {t.transactionId}</td>
                      <td className="py-3 px-4 font-mono font-bold text-right">{t.currency} {t.amount}</td>
                      <td className="py-3 px-4 capitalize font-semibold">{t.status}</td>
                      <td className="py-3 px-4 text-right space-x-2">
                        {t.status !== 'refunded' && (
                          <button
                            type="button"
                            onClick={() => adminSaveTransaction({ ...t, status: 'refunded', notes: 'Refunded by admin' }, false)}
                            className="text-sky-400 font-semibold hover:underline"
                          >
                            Mark Refunded
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 7. Fraud Log & Banned Users */}
      {section === 'fraud' && (
        <div className="space-y-6">
          <div className="rounded-2xl bg-white dark:bg-[#14141C] border border-zinc-200 dark:border-white/10 p-5 space-y-3">
            <h2 className="font-display text-xl font-bold text-zinc-900 dark:text-white flex items-center gap-2">
              <ShieldAlert className="w-5 h-5 text-[#FF2A2A]" /> Duplicate &amp; Tampering Fraud Log
            </h2>
            {fraudLogs.length === 0 ? (
              <p className="text-xs text-zinc-500">No duplicate or fraud attempts logged.</p>
            ) : (
              <div className="divide-y divide-zinc-200 dark:divide-white/8">
                {fraudLogs.map((log) => (
                  <div key={log.id} className="py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
                    <div>
                      <span className="font-mono font-bold text-[#FF2A2A] uppercase mr-2">[{log.layer}]</span>
                      <span className="font-semibold text-zinc-900 dark:text-white">{log.userEmail || log.userId}</span>
                      <p className="text-zinc-500 mt-0.5">{log.reason} · {log.details}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="rounded-2xl bg-white dark:bg-[#14141C] border border-zinc-200 dark:border-white/10 p-5 space-y-3">
            <h2 className="font-display text-xl font-bold text-zinc-900 dark:text-white">User Strikes &amp; Ban Controls</h2>
            <div className="divide-y divide-zinc-200 dark:divide-white/8">
              {allUsers.map((u) => (
                <div key={u.uid} className="py-3 flex items-center justify-between gap-4 text-xs">
                  <div>
                    <div className="font-semibold text-zinc-900 dark:text-white">{u.email}</div>
                    <div className="text-zinc-500 font-mono">Strikes: {u.strikes} · {u.isBanned ? 'BANNED' : 'Active'}</div>
                  </div>
                  <button
                    type="button"
                    onClick={() => adminToggleUserBan(u.uid, !u.isBanned)}
                    className={`min-h-[34px] px-3 rounded-lg font-semibold inline-flex items-center gap-1 ${
                      u.isBanned ? 'bg-emerald-500/15 text-emerald-500' : 'bg-[#FF2A2A]/15 text-[#FF2A2A]'
                    }`}
                  >
                    <Ban className="w-3.5 h-3.5" />
                    {u.isBanned ? 'Unban' : 'Ban User'}
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* 8. Announcements */}
      {section === 'announcements' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <form
            onSubmit={handlePushAnnouncement}
            className="lg:col-span-5 rounded-2xl bg-white dark:bg-[#14141C] border border-zinc-200 dark:border-white/10 p-6 space-y-4"
          >
            <h2 className="font-display text-xl font-bold text-zinc-900 dark:text-white flex items-center gap-2">
              <Megaphone className="w-5 h-5 text-[#FF6A00]" /> Push Notice to Captains
            </h2>
            <input
              required
              value={annTitle}
              onChange={(e) => setAnnTitle(e.target.value)}
              placeholder="Notice headline"
              className="w-full min-h-[40px] px-3 py-2 rounded-xl bg-zinc-50 dark:bg-[#0A0A0F] border border-zinc-200 dark:border-white/10 text-sm"
            />
            <textarea
              required
              rows={3}
              value={annMsg}
              onChange={(e) => setAnnMsg(e.target.value)}
              placeholder="Details for all captains..."
              className="w-full px-3 py-2 rounded-xl bg-zinc-50 dark:bg-[#0A0A0F] border border-zinc-200 dark:border-white/10 text-sm"
            />
            <select
              value={annPriority}
              onChange={(e) => setAnnPriority(e.target.value as 'normal' | 'urgent')}
              className="w-full min-h-[40px] px-3 py-2 rounded-xl bg-zinc-50 dark:bg-[#0A0A0F] border border-zinc-200 dark:border-white/10 text-sm"
            >
              <option value="normal">Normal Notice</option>
              <option value="urgent">Urgent Notice</option>
            </select>
            <button type="submit" className="w-full min-h-[42px] rounded-xl bg-[#FF6A00] text-white text-xs font-semibold">
              Broadcast Notice
            </button>
          </form>

          <div className="lg:col-span-7 space-y-3">
            {announcements.map((a) => (
              <div key={a.id} className="rounded-2xl bg-white dark:bg-[#14141C] border border-zinc-200 dark:border-white/10 p-4">
                <div className="text-xs font-semibold text-[#FF6A00] uppercase">{a.priority}</div>
                <h3 className="text-sm font-bold text-zinc-900 dark:text-white">{a.title}</h3>
                <p className="text-xs text-zinc-500 mt-1">{a.message}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 9. Results & Prize Payouts */}
      {section === 'results' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <form
            onSubmit={handleSaveResult}
            className="lg:col-span-5 rounded-2xl bg-white dark:bg-[#14141C] border border-zinc-200 dark:border-white/10 p-6 space-y-4"
          >
            <h2 className="font-display text-xl font-bold text-zinc-900 dark:text-white">Enter Match Result</h2>
            <select
              value={resScrimId}
              onChange={(e) => setResScrimId(e.target.value)}
              className="w-full min-h-[40px] px-3 py-2 rounded-xl bg-zinc-50 dark:bg-[#0A0A0F] border border-zinc-200 dark:border-white/10 text-xs"
            >
              {scrims.map((s) => (
                <option key={s.id} value={s.id}>{s.title}</option>
              ))}
            </select>
            <input
              required
              value={resTeamName}
              onChange={(e) => setResTeamName(e.target.value)}
              placeholder="Team Name"
              className="w-full min-h-[40px] px-3 py-2 rounded-xl bg-zinc-50 dark:bg-[#0A0A0F] border border-zinc-200 dark:border-white/10 text-sm"
            />
            <div className="grid grid-cols-3 gap-3">
              <div>
                <label className="block text-xs text-zinc-500 mb-1">Placement</label>
                <input
                  type="number"
                  min={1}
                  value={resPlacement}
                  onChange={(e) => setResPlacement(Number(e.target.value))}
                  className="w-full min-h-[40px] px-3 py-2 rounded-xl bg-zinc-50 dark:bg-[#0A0A0F] border border-zinc-200 dark:border-white/10 font-mono text-xs"
                />
              </div>
              <div>
                <label className="block text-xs text-zinc-500 mb-1">Kills</label>
                <input
                  type="number"
                  min={0}
                  value={resKills}
                  onChange={(e) => setResKills(Number(e.target.value))}
                  className="w-full min-h-[40px] px-3 py-2 rounded-xl bg-zinc-50 dark:bg-[#0A0A0F] border border-zinc-200 dark:border-white/10 font-mono text-xs"
                />
              </div>
              <div>
                <label className="block text-xs text-zinc-500 mb-1">Prize</label>
                <input
                  type="number"
                  min={0}
                  value={resPrize}
                  onChange={(e) => setResPrize(Number(e.target.value))}
                  className="w-full min-h-[40px] px-3 py-2 rounded-xl bg-zinc-50 dark:bg-[#0A0A0F] border border-zinc-200 dark:border-white/10 font-mono text-xs"
                />
              </div>
            </div>
            <input
              value={resPayoutRef}
              onChange={(e) => setResPayoutRef(e.target.value)}
              placeholder="Payout Reference (leave blank if unpaid)"
              className="w-full min-h-[40px] px-3 py-2 rounded-xl bg-zinc-50 dark:bg-[#0A0A0F] border border-zinc-200 dark:border-white/10 font-mono text-xs"
            />
            <button type="submit" className="w-full min-h-[42px] rounded-xl bg-[#FF6A00] text-white text-xs font-semibold">
              Save &amp; Calculate Points
            </button>
          </form>

          <div className="lg:col-span-7 rounded-2xl bg-white dark:bg-[#14141C] border border-zinc-200 dark:border-white/10 overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-zinc-200 dark:border-white/10 text-zinc-500">
                  <th className="py-3 px-4">Team</th>
                  <th className="py-3 px-4 text-right">Rank</th>
                  <th className="py-3 px-4 text-right">Kills</th>
                  <th className="py-3 px-4 text-right">Pts</th>
                  <th className="py-3 px-4">Payout</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-200 dark:divide-white/8">
                {sortLeaderboard(results.filter((r) => r.scrimId === resScrimId)).map((row) => (
                  <tr key={row.id}>
                    <td className="py-3 px-4 font-semibold">{row.teamName}</td>
                    <td className="py-3 px-4 font-mono text-right">#{row.placement}</td>
                    <td className="py-3 px-4 font-mono text-right">{row.kills}</td>
                    <td className="py-3 px-4 font-mono font-bold text-right text-[#FF6A00]">{row.totalPoints}</td>
                    <td className="py-3 px-4">
                      {row.prizePaid ? (
                        <span className="text-emerald-500 font-semibold">Paid ({row.payoutReference})</span>
                      ) : (
                        <button
                          type="button"
                          onClick={() =>
                            adminSaveResult({ ...row, prizePaid: true, payoutReference: `PAID-${Date.now().toString().slice(-5)}` })
                          }
                          className="text-[#FF6A00] font-semibold hover:underline"
                        >
                          Mark Paid
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Screenshot Zoom Modal */}
      {zoomImg && (
        <div
          className="fixed inset-0 z-50 bg-black/85 flex items-center justify-center p-4"
          onClick={() => setZoomImg(null)}
        >
          <img src={zoomImg} alt="Zoomed receipt" className="max-h-[90vh] max-w-full rounded-xl object-contain" />
        </div>
      )}
    </div>
  );
};

const StatCard: React.FC<{ label: string; value: string; accent?: boolean; danger?: boolean }> = ({
  label,
  value,
  accent,
  danger,
}) => (
  <div className="rounded-2xl bg-white dark:bg-[#14141C] border border-zinc-200 dark:border-white/10 p-4">
    <div className="text-xs text-zinc-500 dark:text-zinc-400">{label}</div>
    <div
      className={`font-mono text-2xl font-bold tabular-nums mt-1 ${
        danger ? 'text-[#FF2A2A]' : accent ? 'text-[#FF6A00]' : 'text-zinc-900 dark:text-white'
      }`}
    >
      {value}
    </div>
  </div>
);
