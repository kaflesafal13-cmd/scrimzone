import React, { useMemo, useState } from 'react';
import { motion } from 'motion/react';
import {
  ArrowLeft,
  CheckCircle2,
  Copy,
  Download,
  Eye,
  EyeOff,
  ImagePlus,
  Loader2,
  Lock,
  ShieldAlert,
  Sparkles,
  UploadCloud,
  XCircle,
} from 'lucide-react';
import { AIPaymentAnalysis, PlayerEntry, Registration, SCHEMA_LIMITS, Scrim } from '../types';
import { useApp } from '../context/AppContext';
import { normalizeTeamName, requiredMainPlayersForMode, validateTeamRoster } from '../utils/validation';
import { hashTeamPassword, validateTeamPassword } from '../utils/teamPassword';
import { compressImageToDataUrl, computeDHashHex, computeSha256Hex, renderTeamCardPng } from '../utils/imageProcessing';
import { checkDuplicatePayment, evaluateAutoApproval, normalizeTransactionId } from '../utils/fraud';
import { makeSafeId, persistRegistrationAndHashes, recordFraudIncident } from '../lib/db';
import { triggerDownload } from '../lib/exportUtils';
import { TeamCardPreview } from './TeamCardPreview';

interface RegistrationWizardProps {
  scrim: Scrim;
  existingRejectedReg?: Registration;
  onBack: () => void;
  onOpenAuth: () => void;
  onComplete: () => void;
}

export const RegistrationWizard: React.FC<RegistrationWizardProps> = ({
  scrim,
  existingRejectedReg,
  onBack,
  onOpenAuth,
  onComplete,
}) => {
  const { user, profile, paymentMethods, rosters, paymentHashes, registrations, pushToast } = useApp();

  const requiredMain = requiredMainPlayersForMode(scrim.mode);
  const initialPlayers: PlayerEntry[] = existingRejectedReg
    ? existingRejectedReg.players
    : Array.from({ length: requiredMain + 1 }, (_, i) => ({
        ign: i === 0 ? profile?.inGameName || '' : '',
        uid: i === 0 ? profile?.gameUid || '' : '',
        role: i === 0 ? 'Captain' : i === requiredMain ? 'Substitute' : 'Rusher',
      }));

  const [step, setStep] = useState<'roster' | 'payment' | 'result'>(existingRejectedReg ? 'payment' : 'roster');
  const [teamName, setTeamName] = useState(existingRejectedReg?.teamName || '');
  const [teamLogoUrl, setTeamLogoUrl] = useState(existingRejectedReg?.teamLogoUrl || '');
  const [captainName, setCaptainName] = useState(existingRejectedReg?.captainName || profile?.inGameName || '');
  const [captainUid, setCaptainUid] = useState(existingRejectedReg?.captainUid || profile?.gameUid || '');
  const [captainPhone, setCaptainPhone] = useState(existingRejectedReg?.captainPhone || profile?.whatsapp || '');
  const [teamPassword, setTeamPassword] = useState('');
  const [showTeamPassword, setShowTeamPassword] = useState(false);
  const [players, setPlayers] = useState<PlayerEntry[]>(initialPlayers);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const clearError = (keys: string[]) => {
    setErrors((prev) => {
      if (!keys.some((k) => k in prev)) return prev;
      const next = { ...prev };
      keys.forEach((k) => delete next[k]);
      return next;
    });
  };

  const activeMethods = useMemo(() => paymentMethods.filter((m) => m.enabled), [paymentMethods]);
  const [selectedMethodId, setSelectedMethodId] = useState(activeMethods[0]?.id || '');
  const selectedMethod = activeMethods.find((m) => m.id === selectedMethodId) || activeMethods[0];

  const [screenshotFile, setScreenshotFile] = useState<File | null>(null);
  const [screenshotPreview, setScreenshotPreview] = useState('');
  const [uploadProgress, setUploadProgress] = useState(0);
  const [verifyingPhase, setVerifyingPhase] = useState<'idle' | 'hashing' | 'ai' | 'saving'>('idle');
  const [verificationOutcome, setVerificationOutcome] = useState<{
    status: 'slot_confirmed' | 'pending_review' | 'rejected' | 'fraud_blocked';
    reason: string;
    ai?: AIPaymentAnalysis;
    registration?: Registration;
  } | null>(null);

  const attemptCount = existingRejectedReg ? existingRejectedReg.attemptCount + 1 : 1;
  const isLockedOut = existingRejectedReg ? existingRejectedReg.attemptCount >= SCHEMA_LIMITS.MAX_ATTEMPTS : false;

  const scrimRosters = useMemo(() => rosters.filter((r) => r.scrimId === scrim.id), [rosters, scrim.id]);

  const applySavedTeam = (savedId: string) => {
    const saved = profile?.savedTeams?.find((t) => t.id === savedId);
    if (!saved) return;
    setTeamName(saved.teamName);
    setTeamLogoUrl(saved.teamLogoUrl || '');
    setCaptainName(saved.captainName);
    setCaptainUid(saved.captainUid);
    setCaptainPhone(saved.captainPhone);
    setPlayers(saved.players);
    setErrors({});
    pushToast({ type: 'info', title: `Loaded saved team "${saved.teamName}"` });
  };

  const handleLogoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 2 * 1024 * 1024) {
      setErrors((prev) => ({ ...prev, teamLogo: 'Team logo must be under 2 MB.' }));
      return;
    }
    try {
      const compressed = await compressImageToDataUrl(file, {
        maxWidth: 256,
        maxHeight: 256,
        squareCrop: true,
        quality: 0.85,
      });
      setTeamLogoUrl(compressed.dataUrl);
      setErrors((prev) => {
        const next = { ...prev };
        delete next.teamLogo;
        return next;
      });
    } catch {
      setErrors((prev) => ({ ...prev, teamLogo: 'Could not process logo image. Try PNG, JPG, or WebP.' }));
    }
  };

  const handlePlayerPhotoUpload = async (idx: number, e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 2 * 1024 * 1024) return;
    try {
      const compressed = await compressImageToDataUrl(file, {
        maxWidth: 128,
        maxHeight: 128,
        squareCrop: true,
        quality: 0.78,
      });
      setPlayers((prev) => prev.map((p, i) => (i === idx ? { ...p, photoUrl: compressed.dataUrl } : p)));
    } catch {
      // ignore invalid player photo
    }
  };

  const handleProceedToPayment = (e: React.FormEvent) => {
    e.preventDefault();
    const validation = validateTeamRoster({
      teamName,
      captainName,
      captainUid,
      captainPhone,
      players,
      mode: scrim.mode,
      existingRosters: scrimRosters,
      editingRegistrationId: existingRejectedReg?.id,
    });
    if (!validation.valid) {
      setErrors(validation.errors);
      pushToast({ type: 'error', title: 'Roster Check Failed', description: validation.generalError });
      return;
    }
    if (teamPassword.trim()) {
      const pwCheck = validateTeamPassword(teamPassword);
      if (!pwCheck.valid) {
        setErrors({ teamPassword: pwCheck.error || 'Invalid team password.' });
        pushToast({ type: 'error', title: 'Password Check Failed', description: pwCheck.error });
        return;
      }
    }
    setErrors({});
    setStep('payment');
  };

  const handleScreenshotSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) {
      pushToast({ type: 'error', title: 'File too large', description: 'Screenshot must be under 5 MB.' });
      return;
    }
    setScreenshotFile(file);
    const reader = new FileReader();
    reader.onload = () => setScreenshotPreview(String(reader.result));
    reader.readAsDataURL(file);
  };

  const handleVerifyAndSubmit = async () => {
    if (!user) {
      onOpenAuth();
      return;
    }
    if (!user.emailVerified) {
      pushToast({
        type: 'error',
        title: 'Email verification required',
        description: 'Please verify your email address before submitting payments.',
      });
      return;
    }
    if (profile?.isBanned) {
      pushToast({
        type: 'error',
        title: 'Account flagged',
        description: 'Your account has been flagged for repeated duplicate submissions. Contact admin.',
      });
      return;
    }
    if (isLockedOut) {
      pushToast({
        type: 'error',
        title: 'Maximum attempts reached',
        description: 'You reached 3 upload attempts. Contact an organizer for manual help.',
      });
      return;
    }
    if (!screenshotFile) {
      pushToast({ type: 'error', title: 'Upload receipt required', description: 'Select a payment screenshot first.' });
      return;
    }

    try {
      setVerifyingPhase('hashing');
      setUploadProgress(25);

      const [sha256, dHash, compressed] = await Promise.all([
        computeSha256Hex(screenshotFile),
        computeDHashHex(screenshotFile),
        compressImageToDataUrl(screenshotFile, { maxWidth: 1080, maxHeight: 1600, quality: 0.78 }),
      ]);

      setUploadProgress(50);

      const recentAttemptTimes = registrations
        .filter((r) => r.userId === user.uid)
        .map((r) => (typeof r.updatedAt === 'number' ? r.updatedAt : Date.now() - 60_000));

      const preDup = checkDuplicatePayment({
        sha256,
        dHash,
        existingHashes: paymentHashes,
        recentUserAttemptTimestampsMs: recentAttemptTimes,
      });

      if (preDup.blocked && preDup.layer) {
        await recordFraudIncident({
          userId: user.uid,
          userEmail: user.email || '',
          scrimId: scrim.id,
          layer: preDup.layer,
          reason: preDup.reason || 'This screenshot or transaction was already used.',
          details: `SHA256:${sha256.slice(0, 12)} dHash:${dHash}`,
          currentStrikes: profile?.strikes ?? 0,
        });
        setVerificationOutcome({
          status: 'fraud_blocked',
          reason: preDup.reason || 'This screenshot or transaction was already used.',
        });
        setStep('result');
        setVerifyingPhase('idle');
        return;
      }

      setVerifyingPhase('ai');
      setUploadProgress(75);

      const resp = await fetch('/api/verify-payment', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageBase64: compressed.base64,
          mimeType: compressed.mimeType,
          expectedAmount: scrim.entryFee,
          currency: scrim.currency,
          configuredAccounts: activeMethods.map((m) => `${m.type}: ${m.accountName} (${m.accountNumber})`),
          scrimTitle: scrim.title,
          currentTimeISO: new Date().toISOString(),
        }),
      });

      const payload = await resp.json();
      if (!resp.ok || !payload.analysis) {
        throw new Error(payload.error || 'AI receipt verification service unavailable.');
      }

      const ai: AIPaymentAnalysis = payload.analysis;
      setUploadProgress(90);

      const decision = evaluateAutoApproval({
        ai,
        expectedAmount: scrim.entryFee,
        configuredMethods: paymentMethods,
        registrationOpensAtISO: scrim.registrationOpensAtISO,
        uploadTimestampMs: Date.now(),
        existingHashes: paymentHashes,
        sha256,
        dHash,
      });

      if (decision.decision === 'fraud_duplicate') {
        await recordFraudIncident({
          userId: user.uid,
          userEmail: user.email || '',
          scrimId: scrim.id,
          layer: decision.layer,
          reason: decision.reason,
          details: `TxnID:${ai.transaction_id} Sender:${ai.sender_name}`,
          currentStrikes: profile?.strikes ?? 0,
        });
        setVerificationOutcome({
          status: 'fraud_blocked',
          reason: decision.reason,
          ai,
        });
        setStep('result');
        setVerifyingPhase('idle');
        return;
      }

      setVerifyingPhase('saving');
      const finalStatus: 'slot_confirmed' | 'pending_review' | 'rejected' =
        decision.decision === 'auto_approved'
          ? 'slot_confirmed'
          : decision.decision === 'manual_review'
            ? 'pending_review'
            : 'rejected';

      const activePlayers = players.filter((p) => p.ign.trim() && p.uid.trim());
      const regId = existingRejectedReg?.id || makeSafeId('reg');
      const shareCode = existingRejectedReg?.shareCode || `SX-${Math.random().toString(36).slice(2, 6).toUpperCase()}`;
      const hasTeamPassword = Boolean(teamPassword.trim()) || Boolean(existingRejectedReg?.hasTeamPassword);
      const teamPasswordHash = teamPassword.trim()
        ? await hashTeamPassword(teamPassword)
        : existingRejectedReg?.teamPasswordHash || '';

      const regDoc: Registration = {
        id: regId,
        scrimId: scrim.id,
        scrimTitle: scrim.title,
        userId: user.uid,
        teamName: teamName.trim(),
        teamNameNormalized: normalizeTeamName(teamName),
        teamLogoUrl,
        captainName: captainName.trim(),
        captainUid: captainUid.trim(),
        captainPhone: captainPhone.trim(),
        players: activePlayers,
        status: finalStatus,
        paymentMethod: selectedMethod?.name || 'Wallet',
        paymentAmount: ai.amount || scrim.entryFee,
        transactionId: ai.transaction_id,
        transactionIdNormalized: normalizeTransactionId(ai.transaction_id),
        screenshotHashSha256: sha256,
        screenshotDHash: dHash,
        screenshotDataUrl: compressed.dataUrl,
        aiResult: ai,
        reviewNotes: decision.reason,
        attemptCount,
        shareCode,
        hasTeamPassword,
        teamPasswordHash,
      };

      await persistRegistrationAndHashes({
        registration: regDoc,
        isReupload: Boolean(existingRejectedReg),
        scrim,
        aiAnalysis: ai,
        decisionStatus: finalStatus,
        decisionReason: decision.reason,
      });

      setUploadProgress(100);
      setVerificationOutcome({
        status: finalStatus,
        reason: decision.reason,
        ai,
        registration: regDoc,
      });
      setStep('result');
    } catch (err: unknown) {
      pushToast({
        type: 'error',
        title: 'Verification Error',
        description: err instanceof Error ? err.message : 'Unable to verify screenshot.',
      });
    } finally {
      setVerifyingPhase('idle');
    }
  };

  const handleDownloadCard = async () => {
    if (!verificationOutcome?.registration) return;
    const png = await renderTeamCardPng(verificationOutcome.registration, scrim);
    triggerDownload(png, `${verificationOutcome.registration.teamName.toLowerCase().replace(/\s+/g, '-')}-pass.png`);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-4">
        <button
          type="button"
          onClick={onBack}
          className="min-h-[40px] inline-flex items-center gap-2 text-sm font-medium text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Scrim
        </button>

        <div className="text-xs font-semibold text-zinc-500 dark:text-zinc-400">
          {step === 'roster' ? 'Step 1 of 2 · Team Roster' : step === 'payment' ? 'Step 2 of 2 · Payment & AI Verify' : 'Verification Summary'}
        </div>
      </div>

      {/* Step 1: Team Registration Form + Live Esports Card */}
      {step === 'roster' && (
        <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">
          <form
            onSubmit={handleProceedToPayment}
            className="xl:col-span-7 rounded-2xl bg-white dark:bg-[#14141C] border border-zinc-200 dark:border-white/10 p-6 space-y-6"
          >
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-zinc-200 dark:border-white/10 pb-4">
              <div>
                <h1 className="font-display text-2xl font-bold text-zinc-900 dark:text-white">
                  Register for {scrim.title}
                </h1>
                <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-0.5">
                  {scrim.mode} Mode · {requiredMain} required player{requiredMain > 1 ? 's' : ''} + optional substitute
                </p>
              </div>

              {profile?.savedTeams && profile.savedTeams.length > 0 && (
                <div>
                  <label htmlFor="saved-team-select" className="sr-only">
                    Load Saved Team
                  </label>
                  <select
                    id="saved-team-select"
                    defaultValue=""
                    onChange={(e) => applySavedTeam(e.target.value)}
                    className="min-h-[38px] px-3 py-1.5 rounded-xl bg-zinc-50 dark:bg-[#0A0A0F] border border-zinc-200 dark:border-white/10 text-xs font-semibold text-zinc-900 dark:text-white"
                  >
                    <option value="" disabled>
                      Reuse Saved Team...
                    </option>
                    {profile.savedTeams.map((t) => (
                      <option key={t.id} value={t.id}>
                        {t.teamName}
                      </option>
                    ))}
                  </select>
                </div>
              )}
            </div>

            {/* Team Identity */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 items-center">
              <div className="sm:col-span-2">
                <label htmlFor="reg-team-name" className="block text-xs font-semibold text-zinc-700 dark:text-zinc-300 mb-1.5">
                  Team Name (Unique per scrim)
                </label>
                <input
                  id="reg-team-name"
                  type="text"
                  value={teamName}
                  onChange={(e) => {
                    setTeamName(e.target.value);
                    clearError(['teamName']);
                  }}
                  placeholder="e.g. Inferno Ravens"
                  className="w-full min-h-[44px] px-3.5 py-2.5 rounded-xl bg-zinc-50 dark:bg-[#0A0A0F] border border-zinc-200 dark:border-white/10 text-sm text-zinc-900 dark:text-white focus:outline-none focus:border-[#FF6A00]"
                />
                {errors.teamName && <p className="text-xs text-[#FF2A2A] mt-1">{errors.teamName}</p>}
              </div>

              <div>
                <label
                  htmlFor="reg-logo-upload"
                  className="block text-xs font-semibold text-zinc-700 dark:text-zinc-300 mb-1.5"
                >
                  Team Logo (max 2MB)
                </label>
                <label
                  htmlFor="reg-logo-upload"
                  className="min-h-[44px] px-3 py-2 rounded-xl border border-dashed border-zinc-300 dark:border-white/20 hover:border-[#FF6A00] flex items-center justify-center gap-2 text-xs font-semibold text-zinc-700 dark:text-zinc-300 cursor-pointer transition-colors"
                >
                  <ImagePlus className="w-4 h-4 text-[#FF6A00]" />
                  {teamLogoUrl ? 'Change Logo' : 'Upload Logo'}
                </label>
                <input
                  id="reg-logo-upload"
                  type="file"
                  accept="image/png,image/jpeg,image/webp"
                  onChange={handleLogoUpload}
                  className="sr-only"
                />
                {errors.teamLogo && <p className="text-xs text-[#FF2A2A] mt-1">{errors.teamLogo}</p>}
              </div>
            </div>

            {/* Captain Profile */}
            <div className="space-y-3">
              <h2 className="font-display text-lg font-bold text-zinc-900 dark:text-white">Captain Contact</h2>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
                <div>
                  <label htmlFor="cap-ign" className="block text-xs font-medium text-zinc-600 dark:text-zinc-400 mb-1">
                    Captain In-Game Name
                  </label>
                  <input
                    id="cap-ign"
                    type="text"
                    value={captainName}
                    onChange={(e) => {
                      setCaptainName(e.target.value);
                      setPlayers((prev) => prev.map((p, i) => (i === 0 ? { ...p, ign: e.target.value } : p)));
                      clearError(['captainName', 'player_0_ign', 'players']);
                    }}
                    placeholder="SX_Captain"
                    className="w-full min-h-[42px] px-3 py-2 rounded-xl bg-zinc-50 dark:bg-[#0A0A0F] border border-zinc-200 dark:border-white/10 text-sm text-zinc-900 dark:text-white focus:outline-none focus:border-[#FF6A00]"
                  />
                  {errors.captainName && <p className="text-xs text-[#FF2A2A] mt-1">{errors.captainName}</p>}
                </div>

                <div>
                  <label htmlFor="cap-uid" className="block text-xs font-medium text-zinc-600 dark:text-zinc-400 mb-1">
                    Captain UID (8–12 digits)
                  </label>
                  <input
                    id="cap-uid"
                    type="text"
                    inputMode="numeric"
                    value={captainUid}
                    onChange={(e) => {
                      const val = e.target.value.replace(/[^0-9]/g, '').slice(0, 12);
                      setCaptainUid(val);
                      setPlayers((prev) => prev.map((p, i) => (i === 0 ? { ...p, uid: val } : p)));
                      clearError(['captainUid', 'player_0_uid', 'players']);
                    }}
                    placeholder="1049283741"
                    className="w-full min-h-[42px] px-3 py-2 rounded-xl bg-zinc-50 dark:bg-[#0A0A0F] border border-zinc-200 dark:border-white/10 font-mono text-sm text-zinc-900 dark:text-white focus:outline-none focus:border-[#FF6A00]"
                  />
                  {errors.captainUid && <p className="text-xs text-[#FF2A2A] mt-1">{errors.captainUid}</p>}
                </div>

                <div>
                  <label htmlFor="cap-phone" className="block text-xs font-medium text-zinc-600 dark:text-zinc-400 mb-1">
                    WhatsApp / Phone
                  </label>
                  <input
                    id="cap-phone"
                    type="tel"
                    value={captainPhone}
                    onChange={(e) => {
                      setCaptainPhone(e.target.value);
                      clearError(['captainPhone']);
                    }}
                    placeholder="+9779800001111"
                    className="w-full min-h-[42px] px-3 py-2 rounded-xl bg-zinc-50 dark:bg-[#0A0A0F] border border-zinc-200 dark:border-white/10 text-sm text-zinc-900 dark:text-white focus:outline-none focus:border-[#FF6A00]"
                  />
                  {errors.captainPhone && <p className="text-xs text-[#FF2A2A] mt-1">{errors.captainPhone}</p>}
                </div>
              </div>

              {/* Optional Team Pass Password */}
              <div className="rounded-xl bg-zinc-50 dark:bg-[#0A0A0F] border border-zinc-200 dark:border-white/10 p-3.5">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="space-y-0.5">
                    <label
                      htmlFor="reg-team-password"
                      className="text-xs font-semibold text-zinc-800 dark:text-zinc-200 inline-flex items-center gap-1.5"
                    >
                      <Lock className="w-3.5 h-3.5 text-[#FF6A00]" />
                      Team Pass Password (Optional)
                    </label>
                    <p className="text-[11px] text-zinc-500 dark:text-zinc-400">
                      Protect your shareable Team Pass with a 4–32 character squad password. You can change it anytime in My Teams.
                    </p>
                  </div>
                  <div className="relative sm:w-64 shrink-0">
                    <input
                      id="reg-team-password"
                      type={showTeamPassword ? 'text' : 'password'}
                      value={teamPassword}
                      maxLength={SCHEMA_LIMITS.TEAM_PASSWORD_MAX}
                      onChange={(e) => {
                        setTeamPassword(e.target.value);
                        clearError(['teamPassword']);
                      }}
                      placeholder="Set squad passcode..."
                      className="w-full min-h-[40px] pl-3 pr-10 py-2 rounded-lg bg-white dark:bg-[#14141C] border border-zinc-200 dark:border-white/10 font-mono text-xs text-zinc-900 dark:text-white focus:outline-none focus:border-[#FF6A00]"
                    />
                    <button
                      type="button"
                      onClick={() => setShowTeamPassword((prev) => !prev)}
                      aria-label={showTeamPassword ? 'Hide team password' : 'Show team password'}
                      className="absolute right-2 top-1/2 -translate-y-1/2 p-1.5 text-zinc-400 hover:text-zinc-700 dark:hover:text-white"
                    >
                      {showTeamPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                </div>
                {errors.teamPassword && <p className="text-xs text-[#FF2A2A] mt-1.5">{errors.teamPassword}</p>}
              </div>
            </div>

            {/* Players Roster */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h2 className="font-display text-lg font-bold text-zinc-900 dark:text-white">Squad Roster</h2>
                {errors.players && <span className="text-xs text-[#FF2A2A]">{errors.players}</span>}
              </div>

              <div className="space-y-3">
                {players.map((p, idx) => {
                  const isSub = idx === requiredMain;
                  return (
                    <div
                      key={idx}
                      className="rounded-xl bg-zinc-50 dark:bg-[#0A0A0F] border border-zinc-200 dark:border-white/8 p-3.5 grid grid-cols-1 sm:grid-cols-12 gap-3 items-start"
                    >
                      <div className="sm:col-span-4">
                        <label
                          htmlFor={`p-${idx}-ign`}
                          className="block text-[11px] font-medium text-zinc-500 dark:text-zinc-400 mb-1"
                        >
                          {isSub ? 'Substitute IGN (Optional)' : `Player ${idx + 1} IGN`}
                        </label>
                        <input
                          id={`p-${idx}-ign`}
                          type="text"
                          value={p.ign}
                          onChange={(e) => {
                            setPlayers((prev) => prev.map((pl, i) => (i === idx ? { ...pl, ign: e.target.value } : pl)));
                            clearError([`player_${idx}_ign`, 'players']);
                          }}
                          placeholder={`Player ${idx + 1} IGN`}
                          className="w-full min-h-[40px] px-3 py-2 rounded-lg bg-white dark:bg-[#14141C] border border-zinc-200 dark:border-white/10 text-xs text-zinc-900 dark:text-white focus:outline-none focus:border-[#FF6A00]"
                        />
                        {errors[`player_${idx}_ign`] && (
                          <p className="text-[11px] text-[#FF2A2A] mt-1">{errors[`player_${idx}_ign`]}</p>
                        )}
                      </div>

                      <div className="sm:col-span-4">
                        <label
                          htmlFor={`p-${idx}-uid`}
                          className="block text-[11px] font-medium text-zinc-500 dark:text-zinc-400 mb-1"
                        >
                          Free Fire UID (8–12 digits)
                        </label>
                        <input
                          id={`p-${idx}-uid`}
                          type="text"
                          inputMode="numeric"
                          value={p.uid}
                          onChange={(e) => {
                            const val = e.target.value.replace(/[^0-9]/g, '').slice(0, 12);
                            setPlayers((prev) => prev.map((pl, i) => (i === idx ? { ...pl, uid: val } : pl)));
                            clearError([`player_${idx}_uid`, 'players']);
                          }}
                          placeholder="1234567890"
                          className="w-full min-h-[40px] px-3 py-2 rounded-lg bg-white dark:bg-[#14141C] border border-zinc-200 dark:border-white/10 font-mono text-xs text-zinc-900 dark:text-white focus:outline-none focus:border-[#FF6A00]"
                        />
                        {errors[`player_${idx}_uid`] && (
                          <p className="text-[11px] text-[#FF2A2A] mt-1">{errors[`player_${idx}_uid`]}</p>
                        )}
                      </div>

                      <div className="sm:col-span-4 flex items-end gap-2">
                        <div className="flex-1">
                          <label
                            htmlFor={`p-${idx}-role`}
                            className="block text-[11px] font-medium text-zinc-500 dark:text-zinc-400 mb-1"
                          >
                            Role
                          </label>
                          <select
                            id={`p-${idx}-role`}
                            value={p.role}
                            onChange={(e) =>
                              setPlayers((prev) =>
                                prev.map((pl, i) =>
                                  i === idx ? { ...pl, role: e.target.value as PlayerEntry['role'] } : pl
                                )
                              )
                            }
                            className="w-full min-h-[40px] px-2.5 py-2 rounded-lg bg-white dark:bg-[#14141C] border border-zinc-200 dark:border-white/10 text-xs text-zinc-900 dark:text-white"
                          >
                            <option value="Captain">Captain</option>
                            <option value="IGL">IGL</option>
                            <option value="Rusher">Rusher</option>
                            <option value="Sniper">Sniper</option>
                            <option value="Support">Support</option>
                            <option value="Substitute">Substitute</option>
                          </select>
                        </div>

                        <label
                          htmlFor={`p-${idx}-photo`}
                          className="min-h-[40px] px-2.5 rounded-lg border border-zinc-200 dark:border-white/10 hover:border-[#FF6A00] flex items-center justify-center text-[11px] font-medium text-zinc-600 dark:text-zinc-300 cursor-pointer shrink-0"
                          title="Optional player avatar"
                        >
                          {p.photoUrl ? 'Photo ✓' : 'Photo'}
                        </label>
                        <input
                          id={`p-${idx}-photo`}
                          type="file"
                          accept="image/png,image/jpeg,image/webp"
                          onChange={(e) => handlePlayerPhotoUpload(idx, e)}
                          className="sr-only"
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="pt-2 flex justify-end">
              <button
                type="submit"
                className="min-h-[46px] px-6 py-2.5 rounded-xl bg-[#FF6A00] hover:bg-[#e55f00] text-white font-semibold text-sm transition-colors"
              >
                Continue to Payment
              </button>
            </div>
          </form>

          {/* Live Esports Roster Card Preview */}
          <div className="xl:col-span-5 space-y-3 xl:sticky xl:top-20">
            <h2 className="font-display text-lg font-bold text-zinc-900 dark:text-white">Live Team Card Preview</h2>
            <TeamCardPreview
              teamName={teamName}
              teamLogoUrl={teamLogoUrl}
              scrimTitle={`${scrim.title} (${scrim.map})`}
              captainName={captainName}
              captainUid={captainUid}
              players={players}
              hasTeamPassword={Boolean(teamPassword.trim())}
            />
          </div>
        </div>
      )}

      {/* Step 2: Payment & Gemini Vision Verification */}
      {step === 'payment' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          <div className="lg:col-span-7 rounded-2xl bg-white dark:bg-[#14141C] border border-zinc-200 dark:border-white/10 p-6 space-y-5">
            <div className="flex items-center justify-between border-b border-zinc-200 dark:border-white/10 pb-4">
              <div>
                <h1 className="font-display text-2xl font-bold text-zinc-900 dark:text-white">
                  Entry Fee Payment
                </h1>
                <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-0.5">
                  Send exact fee to an official account below and upload the uncropped receipt.
                </p>
              </div>
              <div className="text-right">
                <div className="text-[11px] text-zinc-500 dark:text-zinc-400">Amount Due</div>
                <div className="font-mono text-2xl font-bold text-[#FF6A00] tabular-nums">
                  {scrim.currency} {scrim.entryFee}
                </div>
              </div>
            </div>

            {/* Payment Method Selector */}
            <div className="flex flex-wrap gap-2">
              {activeMethods.map((m) => (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => setSelectedMethodId(m.id)}
                  className={`min-h-[40px] px-4 py-2 rounded-xl text-xs font-semibold border transition-colors ${
                    selectedMethod?.id === m.id
                      ? 'bg-[#FF6A00] text-white border-[#FF6A00]'
                      : 'bg-zinc-50 dark:bg-[#0A0A0F] text-zinc-700 dark:text-zinc-300 border-zinc-200 dark:border-white/10 hover:border-[#FF6A00]/50'
                  }`}
                >
                  {m.name}
                </button>
              ))}
            </div>

            {selectedMethod && (
              <div className="rounded-2xl bg-zinc-50 dark:bg-[#0A0A0F] border border-zinc-200 dark:border-white/10 p-4 flex flex-col sm:flex-row items-center gap-5">
                {selectedMethod.qrImageDataUrl && (
                  <img
                    src={selectedMethod.qrImageDataUrl}
                    alt={`${selectedMethod.name} QR Code`}
                    referrerPolicy="no-referrer"
                    className="w-36 h-36 rounded-xl bg-white p-1.5 object-contain shrink-0"
                  />
                )}
                <div className="space-y-2 min-w-0 flex-1 text-center sm:text-left">
                  <div className="text-xs font-semibold text-[#FF6A00]">{selectedMethod.type} Official Receiver</div>
                  <div className="text-sm font-bold text-zinc-900 dark:text-white">{selectedMethod.accountName}</div>
                  <div className="flex items-center justify-center sm:justify-start gap-2">
                    <span className="font-mono text-base font-semibold text-zinc-900 dark:text-white">
                      {selectedMethod.accountNumber}
                    </span>
                    <button
                      type="button"
                      onClick={() => {
                        navigator.clipboard.writeText(selectedMethod.accountNumber);
                        pushToast({ type: 'success', title: 'Account number copied' });
                      }}
                      aria-label="Copy account number"
                      className="min-h-[34px] px-2.5 py-1 rounded-lg bg-[#FF6A00]/15 text-[#FF6A00] text-xs font-semibold inline-flex items-center gap-1 hover:bg-[#FF6A00]/25"
                    >
                      <Copy className="w-3.5 h-3.5" />
                      Copy
                    </button>
                  </div>
                  {selectedMethod.instructions && (
                    <p className="text-xs text-zinc-500 dark:text-zinc-400">{selectedMethod.instructions}</p>
                  )}
                </div>
              </div>
            )}

            {/* Receipt Upload Zone */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <label htmlFor="receipt-upload" className="text-xs font-semibold text-zinc-700 dark:text-zinc-300">
                  Upload Payment Screenshot (Attempt {attemptCount} of {SCHEMA_LIMITS.MAX_ATTEMPTS})
                </label>
                {existingRejectedReg && (
                  <span className="text-xs text-[#FF2A2A]">Previous attempt rejected — upload clear receipt</span>
                )}
              </div>

              <label
                htmlFor="receipt-upload"
                className="block rounded-2xl border-2 border-dashed border-zinc-300 dark:border-white/15 hover:border-[#FF6A00] p-6 text-center cursor-pointer transition-colors"
              >
                {screenshotPreview ? (
                  <img
                    src={screenshotPreview}
                    alt="Uploaded payment screenshot preview"
                    className="max-h-64 mx-auto rounded-xl object-contain"
                  />
                ) : (
                  <div className="space-y-2">
                    <UploadCloud className="w-8 h-8 text-[#FF6A00] mx-auto" />
                    <p className="text-sm font-semibold text-zinc-900 dark:text-white">
                      Click to select payment screenshot
                    </p>
                    <p className="text-xs text-zinc-500 dark:text-zinc-400">
                      PNG, JPG, or WebP · Must show Transaction ID, Amount, Receiver &amp; Time
                    </p>
                  </div>
                )}
              </label>
              <input
                id="receipt-upload"
                type="file"
                accept="image/png,image/jpeg,image/webp"
                onChange={handleScreenshotSelect}
                className="sr-only"
              />

              {/* Progress / AI Verifying State */}
              {verifyingPhase !== 'idle' && (
                <div className="rounded-xl bg-[#FF6A00]/10 border border-[#FF6A00]/30 p-4 space-y-2.5">
                  <div className="flex items-center justify-between text-xs font-semibold text-[#FF6A00]">
                    <span className="inline-flex items-center gap-2">
                      <Loader2 className="w-4 h-4 animate-spin" />
                      {verifyingPhase === 'hashing'
                        ? 'Running SHA-256 & perceptual anti-fraud scan...'
                        : verifyingPhase === 'ai'
                          ? 'AI verifying payment screenshot with Gemini Vision...'
                          : 'Confirming squad slot & writing ledger...'}
                    </span>
                    <span className="font-mono tabular-nums">{uploadProgress}%</span>
                  </div>
                  <div className="h-2 rounded-full bg-zinc-200 dark:bg-white/10 overflow-hidden">
                    <div
                      className="h-full bg-[#FF6A00] transition-all duration-300"
                      style={{ width: `${uploadProgress}%` }}
                    />
                  </div>
                </div>
              )}

              <div className="flex items-center justify-between gap-3 pt-2">
                {!existingRejectedReg ? (
                  <button
                    type="button"
                    onClick={() => setStep('roster')}
                    disabled={verifyingPhase !== 'idle'}
                    className="min-h-[44px] px-4 py-2 rounded-xl border border-zinc-200 dark:border-white/12 text-xs font-semibold text-zinc-700 dark:text-zinc-300"
                  >
                    Edit Roster
                  </button>
                ) : (
                  <span />
                )}

                {user ? (
                  <button
                    type="button"
                    onClick={handleVerifyAndSubmit}
                    disabled={verifyingPhase !== 'idle' || !screenshotFile || isLockedOut}
                    className="min-h-[46px] px-6 py-2.5 rounded-xl bg-[#FF6A00] hover:bg-[#e55f00] disabled:opacity-50 text-white font-semibold text-sm inline-flex items-center gap-2 transition-colors"
                  >
                    <Sparkles className="w-4 h-4" />
                    {verifyingPhase !== 'idle' ? 'AI Verifying...' : 'Verify & Confirm Slot'}
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={onOpenAuth}
                    className="min-h-[46px] px-6 py-2.5 rounded-xl bg-[#FF6A00] hover:bg-[#e55f00] text-white font-semibold text-sm transition-colors"
                  >
                    Sign In to Submit Payment
                  </button>
                )}
              </div>
            </div>
          </div>

          <div className="lg:col-span-5">
            <TeamCardPreview
              teamName={teamName}
              teamLogoUrl={teamLogoUrl}
              scrimTitle={scrim.title}
              captainName={captainName}
              captainUid={captainUid}
              players={players}
              hasTeamPassword={Boolean(teamPassword.trim())}
            />
          </div>
        </div>
      )}

      {/* Step 3: Verification Outcome */}
      {step === 'result' && verificationOutcome && (
        <motion.div
          initial={{ opacity: 0, scale: 0.97 }}
          animate={{ opacity: 1, scale: 1 }}
          className="max-w-2xl mx-auto rounded-2xl bg-white dark:bg-[#14141C] border border-zinc-200 dark:border-white/10 p-6 sm:p-8 space-y-6"
        >
          <div className="text-center space-y-3">
            <div
              className={`mx-auto w-14 h-14 rounded-2xl flex items-center justify-center ${
                verificationOutcome.status === 'slot_confirmed'
                  ? 'bg-emerald-500/15 text-emerald-500'
                  : verificationOutcome.status === 'pending_review'
                    ? 'bg-amber-500/15 text-amber-500'
                    : 'bg-[#FF2A2A]/15 text-[#FF2A2A]'
              }`}
            >
              {verificationOutcome.status === 'slot_confirmed' ? (
                <CheckCircle2 className="w-8 h-8" />
              ) : verificationOutcome.status === 'pending_review' ? (
                <ShieldAlert className="w-8 h-8" />
              ) : (
                <XCircle className="w-8 h-8" />
              )}
            </div>

            <h2 className="font-display text-3xl font-bold text-zinc-900 dark:text-white">
              {verificationOutcome.status === 'slot_confirmed'
                ? 'Slot Confirmed Automatically'
                : verificationOutcome.status === 'pending_review'
                  ? 'Sent to Organizer Review'
                  : verificationOutcome.status === 'fraud_blocked'
                    ? 'Duplicate / Fraud Block Triggered'
                    : 'Payment Auto-Rejected'}
            </h2>
            <p className="text-sm text-zinc-600 dark:text-zinc-300">{verificationOutcome.reason}</p>
          </div>

          {verificationOutcome.ai && (
            <div className="rounded-xl bg-zinc-50 dark:bg-[#0A0A0F] border border-zinc-200 dark:border-white/10 p-4 grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
              <div>
                <span className="text-zinc-500 block">Extracted Amount</span>
                <span className="font-mono font-bold text-zinc-900 dark:text-white">
                  {verificationOutcome.ai.currency} {verificationOutcome.ai.amount}
                </span>
              </div>
              <div>
                <span className="text-zinc-500 block">Transaction ID</span>
                <span className="font-mono font-bold text-zinc-900 dark:text-white">
                  {verificationOutcome.ai.transaction_id || '—'}
                </span>
              </div>
              <div>
                <span className="text-zinc-500 block">AI Confidence</span>
                <span className="font-mono font-bold text-[#FF6A00]">{verificationOutcome.ai.confidence}%</span>
              </div>
            </div>
          )}

          {verificationOutcome.registration && (
            <TeamCardPreview
              teamName={verificationOutcome.registration.teamName}
              teamLogoUrl={verificationOutcome.registration.teamLogoUrl}
              scrimTitle={scrim.title}
              captainName={verificationOutcome.registration.captainName}
              captainUid={verificationOutcome.registration.captainUid}
              players={verificationOutcome.registration.players}
              status={verificationOutcome.registration.status}
              shareCode={verificationOutcome.registration.shareCode}
              hasTeamPassword={verificationOutcome.registration.hasTeamPassword}
            />
          )}

          <div className="flex flex-wrap items-center justify-center gap-3">
            {verificationOutcome.status === 'rejected' && attemptCount < SCHEMA_LIMITS.MAX_ATTEMPTS && (
              <button
                type="button"
                onClick={() => {
                  setScreenshotFile(null);
                  setScreenshotPreview('');
                  setVerificationOutcome(null);
                  setStep('payment');
                }}
                className="min-h-[44px] px-5 py-2.5 rounded-xl bg-[#FF6A00] hover:bg-[#e55f00] text-white text-sm font-semibold"
              >
                Re-upload Receipt ({SCHEMA_LIMITS.MAX_ATTEMPTS - attemptCount} left)
              </button>
            )}

            {verificationOutcome.registration && (
              <button
                type="button"
                onClick={handleDownloadCard}
                className="min-h-[44px] px-5 py-2.5 rounded-xl border border-zinc-200 dark:border-white/15 text-sm font-semibold text-zinc-900 dark:text-white inline-flex items-center gap-2 hover:bg-zinc-100 dark:hover:bg-white/5"
              >
                <Download className="w-4 h-4 text-[#FF6A00]" />
                Download Team Card PNG
              </button>
            )}

            <button
              type="button"
              onClick={onComplete}
              className="min-h-[44px] px-5 py-2.5 rounded-xl bg-zinc-900 dark:bg-white text-white dark:text-zinc-900 text-sm font-semibold"
            >
              View My Teams
            </button>
          </div>
        </motion.div>
      )}
    </div>
  );
};
