import React, { useEffect, useState } from 'react';
import {
  Bell,
  Check,
  Copy,
  Download,
  Eye,
  EyeOff,
  KeyRound,
  Lock,
  LogOut,
  Plus,
  Receipt,
  RefreshCw,
  Save,
  Share2,
  ShieldCheck,
  Trash2,
  Trophy,
  Unlock,
  Users,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { PlayerEntry, Registration, SavedTeam, SCHEMA_LIMITS, Scrim, ScrimMode, ScrimRoom } from '../types';
import { EMPTY_STATE_IMAGE_URL } from '../data/seedData';
import { renderTeamCardPng } from '../utils/imageProcessing';
import { triggerDownload } from '../lib/exportUtils';
import {
  fetchScrimRoomCredentials,
  makeSafeId,
  markNotificationRead,
  updateRegisteredTeamPassword,
  updateUserProfileFields,
} from '../lib/db';
import { hashTeamPassword, validateTeamPassword, verifyTeamPassword } from '../utils/teamPassword';
import { sortLeaderboard } from '../utils/scoring';
import { TeamCardPreview } from './TeamCardPreview';

export const MyTeamsView: React.FC<{
  onReupload: (scrim: Scrim, reg: Registration) => void;
  onBrowseScrims: () => void;
  onOpenAuth: () => void;
}> = ({ onReupload, onBrowseScrims, onOpenAuth }) => {
  const { user, registrations, scrims, pushToast } = useApp();

  if (!user) {
    return (
      <EmptySignInCard
        title="Sign in to view your registered teams"
        description="Access your squad passes, PNG team cards, shareable links, and slot confirmation status."
        onOpenAuth={onOpenAuth}
      />
    );
  }

  if (registrations.length === 0) {
    return (
      <div className="rounded-2xl bg-white dark:bg-[#14141C] border border-zinc-200 dark:border-white/10 p-8 text-center max-w-lg mx-auto space-y-4">
        <img
          src={EMPTY_STATE_IMAGE_URL}
          alt="No teams registered yet"
          referrerPolicy="no-referrer"
          className="w-48 h-36 object-cover rounded-xl mx-auto"
        />
        <h2 className="font-display text-2xl font-bold text-zinc-900 dark:text-white">No Teams Registered Yet</h2>
        <p className="text-xs text-zinc-500 dark:text-zinc-400">
          Pick an open Free Fire scrim and build your squad roster card to lock in your slot.
        </p>
        <button
          type="button"
          onClick={onBrowseScrims}
          className="min-h-[44px] px-5 py-2.5 rounded-xl bg-[#FF6A00] text-white text-xs font-semibold hover:bg-[#e55f00]"
        >
          Browse Active Scrims
        </button>
      </div>
    );
  }

  const handleDownload = async (reg: Registration) => {
    const scrim = scrims.find((s) => s.id === reg.scrimId);
    const png = await renderTeamCardPng(reg, scrim);
    triggerDownload(png, `${reg.teamName.toLowerCase().replace(/\s+/g, '-')}-pass.png`);
    pushToast({ type: 'success', title: 'Team Card PNG downloaded' });
  };

  const handleCopyShare = (reg: Registration) => {
    const url = `${window.location.origin}/?team=${encodeURIComponent(reg.shareCode)}`;
    navigator.clipboard.writeText(url);
    pushToast({ type: 'success', title: 'Shareable Team Card link copied' });
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-3xl font-bold text-zinc-900 dark:text-white">My Teams &amp; Registrations</h1>
        <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-0.5">
          Download official PNG roster passes, copy share links, or re-upload rejected receipts.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {registrations.map((reg) => {
          const scrim = scrims.find((s) => s.id === reg.scrimId);
          return (
            <div
              key={reg.id}
              className="rounded-2xl bg-white dark:bg-[#14141C] border border-zinc-200 dark:border-white/10 p-5 space-y-4"
            >
              <TeamCardPreview
                teamName={reg.teamName}
                teamLogoUrl={reg.teamLogoUrl}
                scrimTitle={reg.scrimTitle || scrim?.title}
                captainName={reg.captainName}
                captainUid={reg.captainUid}
                players={reg.players}
                status={reg.status}
                shareCode={reg.shareCode}
                hasTeamPassword={reg.hasTeamPassword}
              />

              {reg.reviewNotes && (
                <div className="rounded-xl bg-zinc-50 dark:bg-[#0A0A0F] border border-zinc-200 dark:border-white/8 px-3.5 py-2.5 text-xs text-zinc-700 dark:text-zinc-300">
                  <span className="font-semibold">Status Note:</span> {reg.reviewNotes}
                </div>
              )}

              {/* Registered Team Password & Scrim ID/Pass Access */}
              <RegisteredTeamPasswordBox reg={reg} />
              {scrim && reg.status !== 'rejected' && <RegisteredTeamRoomBox reg={reg} scrim={scrim} />}

              <div className="flex flex-wrap items-center gap-2.5">
                <button
                  type="button"
                  onClick={() => handleDownload(reg)}
                  className="min-h-[40px] px-4 py-2 rounded-xl bg-[#FF6A00] hover:bg-[#e55f00] text-white text-xs font-semibold inline-flex items-center gap-2"
                >
                  <Download className="w-3.5 h-3.5" />
                  Download PNG
                </button>
                <button
                  type="button"
                  onClick={() => handleCopyShare(reg)}
                  className="min-h-[40px] px-4 py-2 rounded-xl border border-zinc-200 dark:border-white/12 text-xs font-semibold text-zinc-900 dark:text-white inline-flex items-center gap-2 hover:bg-zinc-100 dark:hover:bg-white/5"
                >
                  <Share2 className="w-3.5 h-3.5 text-[#FF6A00]" />
                  Share Link
                </button>

                {reg.status === 'rejected' && scrim && reg.attemptCount < SCHEMA_LIMITS.MAX_ATTEMPTS && (
                  <button
                    type="button"
                    onClick={() => onReupload(scrim, reg)}
                    className="min-h-[40px] px-4 py-2 rounded-xl bg-amber-500/15 text-amber-500 text-xs font-semibold inline-flex items-center gap-1.5"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    Re-upload Receipt ({SCHEMA_LIMITS.MAX_ATTEMPTS - reg.attemptCount} left)
                  </button>
                )}

                {reg.status === 'rejected' && reg.attemptCount >= SCHEMA_LIMITS.MAX_ATTEMPTS && (
                  <span className="text-xs font-semibold text-[#FF2A2A]">
                    Locked (3/3 attempts used) — Contact Admin
                  </span>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

const RegisteredTeamPasswordBox: React.FC<{ reg: Registration }> = ({ reg }) => {
  const { pushToast } = useApp();
  const [editing, setEditing] = useState(false);
  const [newPass, setNewPass] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [saving, setSaving] = useState(false);

  const handleSavePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    const check = validateTeamPassword(newPass);
    if (!check.valid) {
      pushToast({ type: 'error', title: 'Invalid Team Password', description: check.error });
      return;
    }
    setSaving(true);
    try {
      const hash = await hashTeamPassword(newPass);
      await updateRegisteredTeamPassword({
        registrationId: reg.id,
        scrimId: reg.scrimId,
        hasTeamPassword: true,
        teamPasswordHash: hash,
      });
      setNewPass('');
      setEditing(false);
      pushToast({ type: 'success', title: `Team password updated for ${reg.teamName}` });
    } catch (err: unknown) {
      pushToast({
        type: 'error',
        title: 'Failed to update password',
        description: err instanceof Error ? err.message : '',
      });
    } finally {
      setSaving(false);
    }
  };

  const handleClearPassword = async () => {
    setSaving(true);
    try {
      await updateRegisteredTeamPassword({
        registrationId: reg.id,
        scrimId: reg.scrimId,
        hasTeamPassword: false,
        teamPasswordHash: '',
      });
      setEditing(false);
      setNewPass('');
      pushToast({ type: 'info', title: `Password lock removed from ${reg.teamName}` });
    } catch (err: unknown) {
      pushToast({
        type: 'error',
        title: 'Failed to remove password',
        description: err instanceof Error ? err.message : '',
      });
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="rounded-xl bg-zinc-50 dark:bg-[#0A0A0F] border border-zinc-200 dark:border-white/8 p-3.5 space-y-2.5">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2 text-xs">
          {reg.hasTeamPassword ? (
            <Lock className="w-3.5 h-3.5 text-[#FF6A00]" />
          ) : (
            <Unlock className="w-3.5 h-3.5 text-zinc-400" />
          )}
          <span className="font-semibold text-zinc-900 dark:text-white">Team Pass Password:</span>
          <span className={reg.hasTeamPassword ? 'text-emerald-500 font-semibold' : 'text-zinc-500'}>
            {reg.hasTeamPassword ? 'Protected' : 'Open (No Password)'}
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setEditing((prev) => !prev)}
            className="min-h-[32px] px-2.5 py-1 rounded-lg border border-zinc-200 dark:border-white/12 text-[11px] font-semibold text-zinc-800 dark:text-zinc-200 hover:border-[#FF6A00]"
          >
            {editing ? 'Cancel' : reg.hasTeamPassword ? 'Change Password' : 'Set Password'}
          </button>
          {reg.hasTeamPassword && !editing && (
            <button
              type="button"
              disabled={saving}
              onClick={handleClearPassword}
              className="min-h-[32px] px-2.5 py-1 rounded-lg text-[11px] font-semibold text-[#FF2A2A] hover:bg-[#FF2A2A]/10"
            >
              Remove
            </button>
          )}
        </div>
      </div>

      {editing && (
        <form onSubmit={handleSavePassword} className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
          <div className="relative flex-1">
            <input
              type={showPass ? 'text' : 'password'}
              value={newPass}
              maxLength={SCHEMA_LIMITS.TEAM_PASSWORD_MAX}
              onChange={(e) => setNewPass(e.target.value)}
              placeholder="New password (4–32 chars)"
              aria-label={`New team password for ${reg.teamName}`}
              className="w-full min-h-[36px] pl-3 pr-9 py-1.5 rounded-lg bg-white dark:bg-[#14141C] border border-zinc-200 dark:border-white/10 font-mono text-xs text-zinc-900 dark:text-white focus:outline-none focus:border-[#FF6A00]"
            />
            <button
              type="button"
              onClick={() => setShowPass((p) => !p)}
              aria-label={showPass ? 'Hide password' : 'Show password'}
              className="absolute right-2 top-1/2 -translate-y-1/2 p-1 text-zinc-400 hover:text-zinc-700 dark:hover:text-white"
            >
              {showPass ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
            </button>
          </div>
          <button
            type="submit"
            disabled={saving}
            className="min-h-[36px] px-4 py-1.5 rounded-lg bg-[#FF6A00] hover:bg-[#e55f00] disabled:opacity-50 text-white text-xs font-semibold whitespace-nowrap"
          >
            {saving ? 'Saving...' : 'Save Password'}
          </button>
        </form>
      )}
    </div>
  );
};

const RegisteredTeamRoomBox: React.FC<{ reg: Registration; scrim: Scrim }> = ({ reg, scrim }) => {
  const { pushToast } = useApp();
  const [room, setRoom] = useState<ScrimRoom | null>(null);
  const [showRoomPass, setShowRoomPass] = useState(false);

  const directRoomId = reg.assignedRoomId?.trim() || '';
  const directRoomPass = reg.assignedRoomPassword?.trim() || '';
  const hasDirectRoom = Boolean(directRoomId);

  const releaseMs = new Date(scrim.roomReleaseAtISO).getTime();
  const isReleased = Date.now() >= releaseMs || Boolean(scrim.roomReleased);
  const minsLeft = Math.max(0, Math.ceil((releaseMs - Date.now()) / 60000));

  useEffect(() => {
    if (hasDirectRoom || reg.status !== 'slot_confirmed' || !isReleased) return;
    fetchScrimRoomCredentials(scrim.id).then(setRoom);
  }, [scrim.id, hasDirectRoom, reg.status, isReleased]);

  const activeRoomId = directRoomId || (isReleased && reg.status === 'slot_confirmed' ? room?.roomId || '' : '');
  const activeRoomPass = directRoomId
    ? directRoomPass
    : isReleased && reg.status === 'slot_confirmed'
      ? room?.roomPassword || ''
      : '';

  const copy = (val: string, label: string) => {
    navigator.clipboard.writeText(val);
    pushToast({ type: 'success', title: `${label} copied` });
  };

  return (
    <div className="rounded-xl bg-[#FF6A00]/8 border border-[#FF6A00]/25 p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 text-xs">
      <div className="flex items-center gap-2">
        <KeyRound className="w-4 h-4 text-[#FF6A00] shrink-0" />
        {activeRoomId ? (
          <span className="font-semibold text-zinc-900 dark:text-white">
            {hasDirectRoom ? 'Scrim ID & Passcode Assigned' : 'Custom Room Credentials Ready'}
          </span>
        ) : reg.status === 'slot_confirmed' ? (
          <span className="text-zinc-600 dark:text-zinc-300">
            Scrim ID &amp; Passcode unlock in ~{minsLeft}m (or when placed by admin)
          </span>
        ) : (
          <span className="text-zinc-600 dark:text-zinc-300">
            Scrim ID &amp; Passcode will appear here once placed by admin
          </span>
        )}
      </div>

      {activeRoomId && (
        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => copy(activeRoomId, 'Scrim ID')}
            className="min-h-[32px] px-2.5 py-1 rounded-lg bg-white dark:bg-[#14141C] border border-zinc-200 dark:border-white/10 font-mono text-[11px] font-semibold inline-flex items-center gap-1.5"
          >
            ID: {activeRoomId}
            <Copy className="w-3 h-3 text-[#FF6A00]" />
          </button>
          <button
            type="button"
            onClick={() => copy(activeRoomPass || '', 'Scrim Passcode')}
            className="min-h-[32px] px-2.5 py-1 rounded-lg bg-white dark:bg-[#14141C] border border-zinc-200 dark:border-white/10 font-mono text-[11px] font-semibold inline-flex items-center gap-1.5"
          >
            PASS: {showRoomPass ? activeRoomPass || 'None' : '••••••'}
            <Copy className="w-3 h-3 text-[#FF6A00]" />
          </button>
          <button
            type="button"
            onClick={() => setShowRoomPass((p) => !p)}
            aria-label={showRoomPass ? 'Hide scrim passcode' : 'Show scrim passcode'}
            className="min-h-[32px] px-2 py-1 rounded-lg border border-zinc-200 dark:border-white/10 text-zinc-500 hover:text-zinc-900 dark:hover:text-white"
          >
            {showRoomPass ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
          </button>
        </div>
      )}
    </div>
  );
};

export const TransactionsView: React.FC<{ onOpenAuth: () => void }> = ({ onOpenAuth }) => {
  const { user, transactions } = useApp();

  if (!user) {
    return (
      <EmptySignInCard
        title="Sign in to view transaction history"
        description="Track every scrim entry fee payment, transaction ID, and verification status."
        onOpenAuth={onOpenAuth}
      />
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-3xl font-bold text-zinc-900 dark:text-white">Transaction History</h1>
        <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-0.5">
          All entry fee receipts and organizer ledger updates.
        </p>
      </div>

      {transactions.length === 0 ? (
        <div className="rounded-2xl bg-white dark:bg-[#14141C] border border-zinc-200 dark:border-white/10 p-10 text-center space-y-2">
          <Receipt className="w-8 h-8 text-[#FF6A00] mx-auto" />
          <p className="text-sm font-semibold text-zinc-900 dark:text-white">No transactions yet</p>
          <p className="text-xs text-zinc-500 dark:text-zinc-400">
            Payments appear here automatically once you submit a scrim registration.
          </p>
        </div>
      ) : (
        <div className="rounded-2xl bg-white dark:bg-[#14141C] border border-zinc-200 dark:border-white/10 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-zinc-200 dark:border-white/10 text-zinc-500 dark:text-zinc-400">
                  <th className="py-3.5 px-4 font-semibold">Scrim / Team</th>
                  <th className="py-3.5 px-4 font-semibold">Method</th>
                  <th className="py-3.5 px-4 font-semibold">Transaction ID</th>
                  <th className="py-3.5 px-4 font-semibold text-right">Amount</th>
                  <th className="py-3.5 px-4 font-semibold">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-200 dark:divide-white/8">
                {transactions.map((t) => (
                  <tr key={t.id} className="hover:bg-zinc-50 dark:hover:bg-white/[0.02]">
                    <td className="py-3.5 px-4">
                      <div className="font-semibold text-zinc-900 dark:text-white">{t.scrimTitle || t.scrimId}</div>
                      <div className="text-[11px] text-zinc-500">{t.teamName || 'Squad'}</div>
                    </td>
                    <td className="py-3.5 px-4 text-zinc-700 dark:text-zinc-300">{t.method}</td>
                    <td className="py-3.5 px-4 font-mono text-zinc-700 dark:text-zinc-300">{t.transactionId || '—'}</td>
                    <td className="py-3.5 px-4 font-mono font-bold text-right tabular-nums text-zinc-900 dark:text-white">
                      {t.currency} {t.amount}
                    </td>
                    <td className="py-3.5 px-4">
                      <span
                        className={`font-semibold capitalize ${
                          t.status === 'verified'
                            ? 'text-emerald-500'
                            : t.status === 'rejected'
                              ? 'text-[#FF2A2A]'
                              : t.status === 'refunded'
                                ? 'text-sky-400'
                                : 'text-amber-500'
                        }`}
                      >
                        {t.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};

export const NotificationsView: React.FC<{ onOpenAuth: () => void }> = ({ onOpenAuth }) => {
  const { user, notifications, announcements } = useApp();

  if (!user) {
    return (
      <EmptySignInCard
        title="Sign in to view notifications"
        description="Receive instant confirmation alerts, rejection reasons, and room credentials 10 minutes before match time."
        onOpenAuth={onOpenAuth}
      />
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-3xl font-bold text-zinc-900 dark:text-white">Alerts &amp; Room Releases</h1>
        <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-0.5">
          Registration updates, organizer notices, and custom room unlock alerts.
        </p>
      </div>

      {announcements.length > 0 && (
        <section className="space-y-3">
          <h2 className="font-display text-lg font-bold text-zinc-900 dark:text-white">Organizer Broadcasts</h2>
          {announcements.map((a) => (
            <div
              key={a.id}
              className="rounded-2xl bg-white dark:bg-[#14141C] border border-[#FF6A00]/30 p-4 flex items-start justify-between gap-4"
            >
              <div>
                <div className="text-xs font-semibold text-[#FF6A00]">
                  {a.priority === 'urgent' ? 'Urgent Notice' : 'Announcement'}
                </div>
                <h3 className="text-sm font-bold text-zinc-900 dark:text-white mt-0.5">{a.title}</h3>
                <p className="text-xs text-zinc-600 dark:text-zinc-300 mt-1">{a.message}</p>
              </div>
            </div>
          ))}
        </section>
      )}

      <section className="space-y-3">
        <h2 className="font-display text-lg font-bold text-zinc-900 dark:text-white">Your Account Alerts</h2>
        {notifications.length === 0 ? (
          <div className="rounded-2xl bg-white dark:bg-[#14141C] border border-zinc-200 dark:border-white/10 p-8 text-center">
            <Bell className="w-7 h-7 text-zinc-400 mx-auto mb-2" />
            <p className="text-xs text-zinc-500">No personal notifications yet.</p>
          </div>
        ) : (
          notifications.map((n) => (
            <div
              key={n.id}
              className={`rounded-2xl bg-white dark:bg-[#14141C] border p-4 flex items-start justify-between gap-4 ${
                n.read ? 'border-zinc-200 dark:border-white/8 opacity-80' : 'border-[#FF6A00]/45'
              }`}
            >
              <div className="space-y-1">
                <h3 className="text-sm font-semibold text-zinc-900 dark:text-white">{n.title}</h3>
                <p className="text-xs text-zinc-600 dark:text-zinc-400">{n.message}</p>
              </div>
              {!n.read && (
                <button
                  type="button"
                  onClick={() => markNotificationRead(n.id)}
                  className="min-h-[34px] px-3 py-1.5 rounded-lg bg-zinc-100 dark:bg-white/5 text-xs font-semibold text-zinc-700 dark:text-zinc-200 inline-flex items-center gap-1 shrink-0"
                >
                  <Check className="w-3.5 h-3.5 text-[#FF6A00]" />
                  Mark Read
                </button>
              )}
            </div>
          ))
        )}
      </section>
    </div>
  );
};

export const LeaderboardView: React.FC = () => {
  const { scrims, results } = useApp();
  const [selectedScrimId, setSelectedScrimId] = useState('');

  const activeScrimId =
    selectedScrimId && scrims.some((s) => s.id === selectedScrimId)
      ? selectedScrimId
      : scrims.find((s) => results.some((r) => r.scrimId === s.id))?.id || scrims[0]?.id || '';

  const selectedScrim = scrims.find((s) => s.id === activeScrimId);
  const scrimResults = sortLeaderboard(results.filter((r) => r.scrimId === activeScrimId));

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-3xl font-bold text-zinc-900 dark:text-white">Match Standings &amp; Payouts</h1>
          <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-0.5">
            Placement + Kill points auto-calculated by SX tournament scoring.
          </p>
        </div>

        {scrims.length > 0 && (
          <>
            <label htmlFor="lb-scrim-select" className="sr-only">
              Select Scrim Standings
            </label>
            <select
              id="lb-scrim-select"
              value={activeScrimId}
              onChange={(e) => setSelectedScrimId(e.target.value)}
              className="min-h-[42px] px-3.5 py-2 rounded-xl bg-white dark:bg-[#14141C] border border-zinc-200 dark:border-white/10 text-xs font-semibold text-zinc-900 dark:text-white"
            >
              {scrims.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.title} ({s.map})
                </option>
              ))}
            </select>
          </>
        )}
      </div>

      {scrimResults.length === 0 ? (
        <div className="rounded-2xl bg-white dark:bg-[#14141C] border border-zinc-200 dark:border-white/10 p-10 text-center space-y-2">
          <Trophy className="w-8 h-8 text-[#FF6A00] mx-auto" />
          <p className="text-sm font-semibold text-zinc-900 dark:text-white">
            {scrims.length === 0 ? 'No Scrim Standings Yet' : 'Standings Pending Match Completion'}
          </p>
          <p className="text-xs text-zinc-500 dark:text-zinc-400">
            {selectedScrim
              ? `Results for ${selectedScrim.title} will appear here once the organizer enters match stats.`
              : 'Standings and prize payouts will appear here once the organizer publishes a scrim and enters match stats.'}
          </p>
        </div>
      ) : (
        <div className="rounded-2xl bg-white dark:bg-[#14141C] border border-zinc-200 dark:border-white/10 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-zinc-200 dark:border-white/10 text-zinc-500 dark:text-zinc-400">
                  <th className="py-3.5 px-4 font-semibold">Rank</th>
                  <th className="py-3.5 px-4 font-semibold">Team</th>
                  <th className="py-3.5 px-4 font-semibold text-right">Placement</th>
                  <th className="py-3.5 px-4 font-semibold text-right">Kills</th>
                  <th className="py-3.5 px-4 font-semibold text-right">Total Pts</th>
                  <th className="py-3.5 px-4 font-semibold text-right">Prize</th>
                  <th className="py-3.5 px-4 font-semibold">Payout</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-200 dark:divide-white/8">
                {scrimResults.map((row, idx) => (
                  <tr key={row.id} className="hover:bg-zinc-50 dark:hover:bg-white/[0.02]">
                    <td className="py-3.5 px-4 font-mono font-bold text-[#FF6A00] tabular-nums">#{idx + 1}</td>
                    <td className="py-3.5 px-4 font-semibold text-zinc-900 dark:text-white">{row.teamName}</td>
                    <td className="py-3.5 px-4 font-mono text-right tabular-nums">#{row.placement}</td>
                    <td className="py-3.5 px-4 font-mono text-right tabular-nums">{row.kills}</td>
                    <td className="py-3.5 px-4 font-mono font-bold text-right tabular-nums text-zinc-900 dark:text-white">
                      {row.totalPoints}
                    </td>
                    <td className="py-3.5 px-4 font-mono text-right tabular-nums text-[#FF6A00]">
                      {row.prizeAmount ? `${selectedScrim?.currency || 'NPR'} ${row.prizeAmount}` : '—'}
                    </td>
                    <td className="py-3.5 px-4">
                      {row.prizePaid ? (
                        <span className="text-emerald-500 font-semibold">Paid ({row.payoutReference || 'Ref'})</span>
                      ) : row.prizeAmount ? (
                        <span className="text-amber-500 font-semibold">Processing</span>
                      ) : (
                        <span className="text-zinc-500">—</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};

export const ProfileView: React.FC<{ onOpenAuth: () => void }> = ({ onOpenAuth }) => {
  const { user, profile, logout, refreshProfile, pushToast } = useApp();
  const [ign, setIgn] = useState(profile?.inGameName || '');
  const [uid, setUid] = useState(profile?.gameUid || '');
  const [whatsapp, setWhatsapp] = useState(profile?.whatsapp || '');
  const [saving, setSaving] = useState(false);

  // Saved team creation form
  const [newTeamName, setNewTeamName] = useState('');
  const [newTeamMode, setNewTeamMode] = useState<ScrimMode>('Squad');
  const [newPlayersText, setNewPlayersText] = useState('');

  useEffect(() => {
    if (!profile) return;
    setIgn(profile.inGameName || '');
    setUid(profile.gameUid || '');
    setWhatsapp(profile.whatsapp || '');
  }, [profile]);

  if (!user) {
    return (
      <EmptySignInCard
        title="Sign in to manage your Captain Profile"
        description="Save your Free Fire UID, WhatsApp contact, and reusable squad rosters for 1-click scrim registration."
        onOpenAuth={onOpenAuth}
      />
    );
  }

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (uid && !/^[0-9]{8,12}$/.test(uid)) {
      pushToast({ type: 'error', title: 'Invalid UID', description: 'Free Fire UID must be 8–12 digits.' });
      return;
    }
    setSaving(true);
    try {
      await updateUserProfileFields(user.uid, {
        inGameName: ign.trim(),
        gameUid: uid.trim(),
        whatsapp: whatsapp.trim(),
      });
      await refreshProfile();
      pushToast({ type: 'success', title: 'Captain profile saved' });
    } catch (err: unknown) {
      pushToast({ type: 'error', title: 'Failed to save', description: err instanceof Error ? err.message : '' });
    } finally {
      setSaving(false);
    }
  };

  const handleAddSavedTeam = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTeamName.trim()) return;
    const lines = newPlayersText
      .split('\n')
      .map((l) => l.trim())
      .filter(Boolean);
    const parsedPlayers: PlayerEntry[] = lines.map((line, i) => {
      const [pIgn, pUid] = line.split(/[:,|\s]+/);
      return {
        ign: (pIgn || `Player${i + 1}`).slice(0, 40),
        uid: (pUid || '10000000').replace(/[^0-9]/g, '').slice(0, 12),
        role: i === 0 ? 'Captain' : 'Rusher',
      };
    });
    if (parsedPlayers.length === 0) {
      parsedPlayers.push({
        ign: ign || user.displayName || 'Captain',
        uid: uid || '10000000',
        role: 'Captain',
      });
    }
    const newSaved: SavedTeam = {
      id: makeSafeId('team'),
      teamName: newTeamName.trim(),
      captainName: ign || user.displayName || 'Captain',
      captainUid: uid || parsedPlayers[0].uid,
      captainPhone: whatsapp || '+9779800000000',
      mode: newTeamMode,
      players: parsedPlayers,
    };
    const nextList = [...(profile?.savedTeams || []), newSaved].slice(0, 10);
    await updateUserProfileFields(user.uid, { savedTeams: nextList });
    await refreshProfile();
    setNewTeamName('');
    setNewPlayersText('');
    pushToast({ type: 'success', title: 'Saved team added for quick reuse' });
  };

  const handleRemoveSavedTeam = async (teamId: string) => {
    const nextList = (profile?.savedTeams || []).filter((t) => t.id !== teamId);
    await updateUserProfileFields(user.uid, { savedTeams: nextList });
    await refreshProfile();
  };

  return (
    <div className="space-y-6 max-w-4xl">
      <div className="flex items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-3xl font-bold text-zinc-900 dark:text-white">Captain Profile</h1>
          <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-0.5">
            {user.email} · {user.emailVerified ? 'Email Verified' : 'Email Unverified'} · Strikes:{' '}
            <span className="font-mono font-bold">{profile?.strikes ?? 0} / 3</span>
          </p>
        </div>

        <button
          type="button"
          onClick={logout}
          className="min-h-[42px] px-4 py-2 rounded-xl border border-zinc-200 dark:border-white/12 text-xs font-semibold text-zinc-900 dark:text-white inline-flex items-center gap-2 hover:bg-zinc-100 dark:hover:bg-white/5"
        >
          <LogOut className="w-4 h-4 text-[#FF2A2A]" />
          Sign Out
        </button>
      </div>

      <form
        onSubmit={handleSaveProfile}
        className="rounded-2xl bg-white dark:bg-[#14141C] border border-zinc-200 dark:border-white/10 p-6 space-y-4"
      >
        <h2 className="font-display text-xl font-bold text-zinc-900 dark:text-white">Default Captain Details</h2>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div>
            <label htmlFor="prof-ign" className="block text-xs font-medium text-zinc-500 mb-1">
              In-Game Name
            </label>
            <input
              id="prof-ign"
              type="text"
              value={ign}
              onChange={(e) => setIgn(e.target.value)}
              placeholder="SX_Captain"
              className="w-full min-h-[42px] px-3 py-2 rounded-xl bg-zinc-50 dark:bg-[#0A0A0F] border border-zinc-200 dark:border-white/10 text-sm text-zinc-900 dark:text-white"
            />
          </div>
          <div>
            <label htmlFor="prof-uid" className="block text-xs font-medium text-zinc-500 mb-1">
              Free Fire UID
            </label>
            <input
              id="prof-uid"
              type="text"
              value={uid}
              onChange={(e) => setUid(e.target.value.replace(/[^0-9]/g, '').slice(0, 12))}
              placeholder="1049283741"
              className="w-full min-h-[42px] px-3 py-2 rounded-xl bg-zinc-50 dark:bg-[#0A0A0F] border border-zinc-200 dark:border-white/10 font-mono text-sm text-zinc-900 dark:text-white"
            />
          </div>
          <div>
            <label htmlFor="prof-wa" className="block text-xs font-medium text-zinc-500 mb-1">
              WhatsApp / Phone
            </label>
            <input
              id="prof-wa"
              type="tel"
              value={whatsapp}
              onChange={(e) => setWhatsapp(e.target.value)}
              placeholder="+9779800001111"
              className="w-full min-h-[42px] px-3 py-2 rounded-xl bg-zinc-50 dark:bg-[#0A0A0F] border border-zinc-200 dark:border-white/10 text-sm text-zinc-900 dark:text-white"
            />
          </div>
        </div>
        <button
          type="submit"
          disabled={saving}
          className="min-h-[42px] px-5 py-2 rounded-xl bg-[#FF6A00] hover:bg-[#e55f00] text-white text-xs font-semibold inline-flex items-center gap-2"
        >
          <Save className="w-4 h-4" />
          {saving ? 'Saving...' : 'Save Captain Details'}
        </button>
      </form>

      {/* Saved Teams Section */}
      <div className="rounded-2xl bg-white dark:bg-[#14141C] border border-zinc-200 dark:border-white/10 p-6 space-y-5">
        <div>
          <h2 className="font-display text-xl font-bold text-zinc-900 dark:text-white">Saved Teams (Quick Reuse)</h2>
          <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-0.5">
            Store rosters here to auto-fill any future scrim registration.
          </p>
        </div>

        {(profile?.savedTeams || []).length > 0 && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {profile?.savedTeams?.map((t) => (
              <div
                key={t.id}
                className="rounded-xl bg-zinc-50 dark:bg-[#0A0A0F] border border-zinc-200 dark:border-white/8 p-3.5 flex items-center justify-between gap-3"
              >
                <div>
                  <div className="text-sm font-bold text-zinc-900 dark:text-white">{t.teamName}</div>
                  <div className="text-xs text-zinc-500">
                    {t.mode} · {t.players.length} players
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => handleRemoveSavedTeam(t.id)}
                  aria-label={`Delete saved team ${t.teamName}`}
                  className="p-2 text-zinc-400 hover:text-[#FF2A2A]"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        )}

        <form onSubmit={handleAddSavedTeam} className="space-y-3 pt-2 border-t border-zinc-200 dark:border-white/10">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label htmlFor="new-team-name" className="block text-xs font-medium text-zinc-500 mb-1">
                New Saved Team Name
              </label>
              <input
                id="new-team-name"
                type="text"
                value={newTeamName}
                onChange={(e) => setNewTeamName(e.target.value)}
                placeholder="e.g. Garuda Fang"
                className="w-full min-h-[40px] px-3 py-2 rounded-xl bg-zinc-50 dark:bg-[#0A0A0F] border border-zinc-200 dark:border-white/10 text-sm text-zinc-900 dark:text-white"
              />
            </div>
            <div>
              <label htmlFor="new-team-mode" className="block text-xs font-medium text-zinc-500 mb-1">
                Default Mode
              </label>
              <select
                id="new-team-mode"
                value={newTeamMode}
                onChange={(e) => setNewTeamMode(e.target.value as ScrimMode)}
                className="w-full min-h-[40px] px-3 py-2 rounded-xl bg-zinc-50 dark:bg-[#0A0A0F] border border-zinc-200 dark:border-white/10 text-sm text-zinc-900 dark:text-white"
              >
                <option value="Squad">Squad</option>
                <option value="Duo">Duo</option>
                <option value="Solo">Solo</option>
              </select>
            </div>
          </div>

          <div>
            <label htmlFor="new-team-players" className="block text-xs font-medium text-zinc-500 mb-1">
              Players (one per line: IGN, UID)
            </label>
            <textarea
              id="new-team-players"
              rows={3}
              value={newPlayersText}
              onChange={(e) => setNewPlayersText(e.target.value)}
              placeholder={'SX_Alpha, 1049283741\nSX_Bravo, 1049283742'}
              className="w-full px-3 py-2 rounded-xl bg-zinc-50 dark:bg-[#0A0A0F] border border-zinc-200 dark:border-white/10 font-mono text-xs text-zinc-900 dark:text-white"
            />
          </div>

          <button
            type="submit"
            className="min-h-[40px] px-4 py-2 rounded-xl border border-[#FF6A00] text-[#FF6A00] hover:bg-[#FF6A00]/10 text-xs font-semibold inline-flex items-center gap-1.5"
          >
            <Plus className="w-4 h-4" />
            Add Saved Team
          </button>
        </form>
      </div>
    </div>
  );
};

export const ShareTeamPassModal: React.FC<{
  shareCode: string;
  onClose: () => void;
}> = ({ shareCode, onClose }) => {
  const { rosters, scrims, user, isAdmin } = useApp();
  const roster = rosters.find((r) => r.shareCode === shareCode);

  const [passwordInput, setPasswordInput] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [unlocked, setUnlocked] = useState(false);
  const [verifying, setVerifying] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  if (!roster) return null;
  const scrim = scrims.find((s) => s.id === roster.scrimId);
  const isLocked = Boolean(roster.hasTeamPassword && roster.teamPasswordHash && !unlocked);
  const isOwnerOrAdmin = Boolean((user && user.uid === roster.userId) || isAdmin);

  const handleUnlock = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!roster.teamPasswordHash) {
      setUnlocked(true);
      return;
    }
    setVerifying(true);
    setErrorMsg('');
    try {
      const ok = await verifyTeamPassword(passwordInput, roster.teamPasswordHash);
      if (ok) {
        setUnlocked(true);
      } else {
        setErrorMsg('Incorrect team password. Check with your team captain and try again.');
      }
    } finally {
      setVerifying(false);
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Shared Team Pass"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4"
    >
      <div className="max-w-lg w-full space-y-4">
        {isLocked ? (
          <div className="rounded-2xl bg-[#14141C] border border-[#FF6A00]/40 p-6 text-white space-y-4 shadow-[0_16px_48px_rgba(0,0,0,0.6)]">
            <div className="flex items-start gap-3">
              <div className="w-11 h-11 rounded-xl bg-[#FF6A00]/15 text-[#FF6A00] flex items-center justify-center shrink-0">
                <Lock className="w-5 h-5" />
              </div>
              <div className="min-w-0">
                <div className="text-[11px] font-semibold tracking-wider text-[#FF6A00] uppercase">
                  Password-Protected Team Pass
                </div>
                <h2 className="font-display text-2xl font-bold text-white truncate mt-0.5">{roster.teamName}</h2>
                <p className="text-xs text-zinc-400 truncate">
                  {scrim?.title || 'Free Fire Scrim'} · PASS {roster.shareCode}
                </p>
              </div>
            </div>

            <form onSubmit={handleUnlock} className="space-y-3">
              <div>
                <label htmlFor="share-pass-input" className="block text-xs font-medium text-zinc-300 mb-1.5">
                  Enter Team Password to view full roster card
                </label>
                <div className="relative">
                  <input
                    id="share-pass-input"
                    type={showPass ? 'text' : 'password'}
                    value={passwordInput}
                    onChange={(e) => {
                      setPasswordInput(e.target.value);
                      if (errorMsg) setErrorMsg('');
                    }}
                    placeholder="Enter squad passcode..."
                    className="w-full min-h-[44px] pl-3.5 pr-10 py-2 rounded-xl bg-[#0A0A0F] border border-white/15 font-mono text-sm text-white focus:outline-none focus:border-[#FF6A00]"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPass((p) => !p)}
                    aria-label={showPass ? 'Hide password' : 'Show password'}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 p-1.5 text-zinc-400 hover:text-white"
                  >
                    {showPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
                {errorMsg && <p className="text-xs text-[#FF2A2A] mt-1.5">{errorMsg}</p>}
              </div>

              <div className="flex flex-wrap items-center gap-2.5">
                <button
                  type="submit"
                  disabled={verifying || !passwordInput.trim()}
                  className="flex-1 min-h-[44px] px-5 py-2.5 rounded-xl bg-[#FF6A00] hover:bg-[#e55f00] disabled:opacity-50 text-white font-semibold text-sm inline-flex items-center justify-center gap-2"
                >
                  <ShieldCheck className="w-4 h-4" />
                  {verifying ? 'Verifying...' : 'Unlock Team Pass'}
                </button>
                {isOwnerOrAdmin && (
                  <button
                    type="button"
                    onClick={() => setUnlocked(true)}
                    className="min-h-[44px] px-4 py-2.5 rounded-xl border border-white/15 text-xs font-semibold text-zinc-200 hover:bg-white/5"
                  >
                    Captain Bypass
                  </button>
                )}
              </div>
            </form>
          </div>
        ) : (
          <TeamCardPreview
            teamName={roster.teamName}
            teamLogoUrl={roster.teamLogoUrl}
            scrimTitle={scrim?.title}
            captainName={roster.captainName || 'Captain'}
            captainUid={roster.captainUid || ''}
            players={roster.players}
            status={roster.status}
            shareCode={roster.shareCode}
            hasTeamPassword={roster.hasTeamPassword}
          />
        )}

        <button
          type="button"
          onClick={onClose}
          className="w-full min-h-[44px] rounded-xl bg-zinc-900 border border-white/15 hover:border-[#FF6A00] text-white font-semibold text-sm"
        >
          Close Pass &amp; Browse Scrims
        </button>
      </div>
    </div>
  );
};

const EmptySignInCard: React.FC<{ title: string; description: string; onOpenAuth: () => void }> = ({
  title,
  description,
  onOpenAuth,
}) => (
  <div className="rounded-2xl bg-white dark:bg-[#14141C] border border-zinc-200 dark:border-white/10 p-8 text-center max-w-md mx-auto space-y-4">
    <Users className="w-10 h-10 text-[#FF6A00] mx-auto" />
    <h2 className="font-display text-2xl font-bold text-zinc-900 dark:text-white">{title}</h2>
    <p className="text-xs text-zinc-500 dark:text-zinc-400">{description}</p>
    <button
      type="button"
      onClick={onOpenAuth}
      className="min-h-[44px] px-6 py-2.5 rounded-xl bg-[#FF6A00] text-white text-sm font-semibold hover:bg-[#e55f00]"
    >
      Sign In / Create Account
    </button>
  </div>
);
