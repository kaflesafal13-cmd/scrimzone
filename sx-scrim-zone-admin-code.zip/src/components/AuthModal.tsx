import React, { useState } from 'react';
import { X, Mail, Lock, User, Loader2, ArrowLeft, CheckCircle2, ShieldAlert, KeyRound } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

type AuthMode = 'login' | 'signup' | 'reset';

interface AuthCardProps {
  onSuccess?: () => void;
  onClose?: () => void;
  titleId: string;
  intendedPath?: string | null;
}

const AuthCard: React.FC<AuthCardProps> = ({ onSuccess, onClose, titleId, intendedPath }) => {
  const { signInWithEmail, signUpWithEmail, resetPassword, authActionPending } = useAuth();
  const [mode, setMode] = useState<AuthMode>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [localPending, setLocalPending] = useState<'form' | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [resetSent, setResetSent] = useState(false);

  const isBusy = authActionPending || localPending !== null;

  const switchMode = (nextMode: AuthMode) => {
    if (isBusy) return;
    setMode(nextMode);
    setError(null);
    setResetSent(false);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isBusy) return;
    setError(null);
    setResetSent(false);

    const trimmedEmail = email.trim();
    if (!trimmedEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(trimmedEmail)) {
      setError('Enter a valid email address.');
      return;
    }

    if (mode !== 'reset' && password.length < 6) {
      setError('Password must be at least 6 characters.');
      return;
    }

    setLocalPending('form');
    try {
      if (mode === 'reset') {
        await resetPassword(trimmedEmail);
        setResetSent(true);
      } else if (mode === 'login') {
        await signInWithEmail(trimmedEmail, password);
        onSuccess?.();
      } else {
        await signUpWithEmail(trimmedEmail, password, displayName);
        onSuccess?.();
      }
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Authentication failed.');
    } finally {
      setLocalPending(null);
    }
  };

  const heading =
    mode === 'login'
      ? 'Sign In to SX SCRIM ZONE'
      : mode === 'signup'
        ? 'Create Captain Account'
        : 'Reset Your Password';

  const subtitle =
    mode === 'reset'
      ? 'Enter your account email and we will send a password recovery link.'
      : intendedPath
        ? `Sign in to continue to ${intendedPath}`
        : 'Register squads, verify entry fees, and unlock custom rooms.';

  return (
    <div className="w-full max-w-md rounded-2xl bg-white dark:bg-[#14141C] border border-zinc-200 dark:border-white/10 p-4 sm:p-6 shadow-2xl">
      <div className="flex items-start justify-between gap-3 mb-5">
        <div className="min-w-0">
          <h2 id={titleId} className="font-display text-xl sm:text-2xl font-bold text-zinc-900 dark:text-white leading-tight">
            {heading}
          </h2>
          <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-1 break-words">{subtitle}</p>
        </div>
        {onClose && (
          <button
            type="button"
            disabled={isBusy}
            onClick={onClose}
            aria-label="Close sign-in modal"
            className="min-w-[40px] min-h-[40px] shrink-0 rounded-xl flex items-center justify-center text-zinc-500 hover:text-zinc-900 dark:hover:text-white hover:bg-zinc-100 dark:hover:bg-white/5 disabled:opacity-50 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        )}
      </div>

      {mode !== 'reset' && (
        <>
          <div className="flex gap-1 p-1 rounded-xl bg-zinc-100 dark:bg-[#0A0A0F] mb-4">
            <button
              type="button"
              disabled={isBusy}
              onClick={() => switchMode('login')}
              className={`flex-1 min-h-[38px] py-2 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap disabled:opacity-60 ${
                mode === 'login'
                  ? 'bg-white dark:bg-[#1E1E2A] text-zinc-900 dark:text-white shadow-sm'
                  : 'text-zinc-500 hover:text-zinc-900 dark:hover:text-white'
              }`}
            >
              Sign In
            </button>
            <button
              type="button"
              disabled={isBusy}
              onClick={() => switchMode('signup')}
              className={`flex-1 min-h-[38px] py-2 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap disabled:opacity-60 ${
                mode === 'signup'
                  ? 'bg-white dark:bg-[#1E1E2A] text-zinc-900 dark:text-white shadow-sm'
                  : 'text-zinc-500 hover:text-zinc-900 dark:hover:text-white'
              }`}
            >
              Sign Up
            </button>
          </div>
        </>
      )}

      <form onSubmit={handleSubmit} className="space-y-3.5" noValidate>
        {mode === 'signup' && (
          <div>
            <label htmlFor={`${titleId}-name`} className="block text-xs font-medium text-zinc-600 dark:text-zinc-300 mb-1">
              Captain Display Name
            </label>
            <div className="relative">
              <User className="w-4 h-4 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                id={`${titleId}-name`}
                type="text"
                autoComplete="name"
                disabled={isBusy}
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                placeholder="e.g. SX_Phoenix"
                className="w-full min-h-[44px] pl-9 pr-3 py-2.5 rounded-xl bg-zinc-50 dark:bg-[#0A0A0F] border border-zinc-200 dark:border-white/10 text-sm text-zinc-900 dark:text-white focus:outline-none focus:border-[#FF6A00] disabled:opacity-60"
              />
            </div>
          </div>
        )}

        <div>
          <label htmlFor={`${titleId}-email`} className="block text-xs font-medium text-zinc-600 dark:text-zinc-300 mb-1">
            Email Address
          </label>
          <div className="relative">
            <Mail className="w-4 h-4 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              id={`${titleId}-email`}
              type="email"
              required
              autoComplete="email"
              disabled={isBusy}
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="captain@example.com"
              className="w-full min-h-[44px] pl-9 pr-3 py-2.5 rounded-xl bg-zinc-50 dark:bg-[#0A0A0F] border border-zinc-200 dark:border-white/10 text-sm text-zinc-900 dark:text-white focus:outline-none focus:border-[#FF6A00] disabled:opacity-60"
            />
          </div>
        </div>

        {mode !== 'reset' && (
          <div>
            <div className="flex items-center justify-between gap-2 mb-1">
              <label htmlFor={`${titleId}-password`} className="block text-xs font-medium text-zinc-600 dark:text-zinc-300">
                Password
              </label>
              {mode === 'login' && (
                <button
                  type="button"
                  disabled={isBusy}
                  onClick={() => switchMode('reset')}
                  className="text-xs font-semibold text-[#FF6A00] hover:underline disabled:opacity-50"
                >
                  Forgot password?
                </button>
              )}
            </div>
            <div className="relative">
              <Lock className="w-4 h-4 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                id={`${titleId}-password`}
                type="password"
                required
                minLength={6}
                autoComplete={mode === 'login' ? 'current-password' : 'new-password'}
                disabled={isBusy}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Minimum 6 characters"
                className="w-full min-h-[44px] pl-9 pr-3 py-2.5 rounded-xl bg-zinc-50 dark:bg-[#0A0A0F] border border-zinc-200 dark:border-white/10 text-sm text-zinc-900 dark:text-white focus:outline-none focus:border-[#FF6A00] disabled:opacity-60"
              />
            </div>
          </div>
        )}

        {error && (
          <div
            role="alert"
            className="rounded-xl bg-[#FF2A2A]/10 border border-[#FF2A2A]/35 px-3 py-2.5 text-xs text-[#FF2A2A] break-words"
          >
            {error}
          </div>
        )}

        {resetSent && (
          <div
            role="status"
            className="rounded-xl bg-emerald-500/10 border border-emerald-500/35 px-3 py-2.5 text-xs text-emerald-500 flex items-start gap-2"
          >
            <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />
            <span>Password reset email sent to {email.trim()}. Check your inbox and spam folder.</span>
          </div>
        )}

        <button
          type="submit"
          disabled={isBusy}
          className="w-full min-h-[46px] py-2.5 px-4 rounded-xl bg-[#FF6A00] hover:bg-[#e55f00] disabled:opacity-60 disabled:cursor-not-allowed text-white font-semibold text-sm flex items-center justify-center gap-2 transition-colors shadow-[0_0_20px_rgba(255,106,0,0.28)]"
        >
          {localPending === 'form' ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin shrink-0" />
              <span>
                {mode === 'login'
                  ? 'Signing in...'
                  : mode === 'signup'
                    ? 'Creating account...'
                    : 'Sending reset link...'}
              </span>
            </>
          ) : mode === 'login' ? (
            'Sign In'
          ) : mode === 'signup' ? (
            'Create Account'
          ) : (
            'Send Password Reset Link'
          )}
        </button>

        {mode === 'reset' && (
          <button
            type="button"
            disabled={isBusy}
            onClick={() => switchMode('login')}
            className="w-full min-h-[42px] py-2 px-4 rounded-xl border border-zinc-200 dark:border-white/10 text-xs font-semibold text-zinc-700 dark:text-zinc-200 hover:bg-zinc-100 dark:hover:bg-white/5 flex items-center justify-center gap-2 disabled:opacity-50"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            Back to Sign In
          </button>
        )}
      </form>
    </div>
  );
};

interface AuthModalProps {
  open: boolean;
  onClose: () => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({ open, onClose }) => {
  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-3 sm:p-4 overflow-y-auto"
      role="dialog"
      aria-modal="true"
      aria-labelledby="auth-modal-title"
    >
      <AuthCard titleId="auth-modal-title" onClose={onClose} onSuccess={onClose} />
    </div>
  );
};

interface LoginViewProps {
  intendedPath?: string | null;
  onBackHome: () => void;
  onAuthSuccess?: () => void;
}

export const LoginView: React.FC<LoginViewProps> = ({ intendedPath, onBackHome, onAuthSuccess }) => {
  return (
    <div className="min-h-[calc(100vh-10rem)] flex flex-col items-center justify-center py-6 px-1 sm:px-4">
      <div className="w-full max-w-md space-y-4">
        <button
          type="button"
          onClick={onBackHome}
          className="inline-flex items-center gap-1.5 text-xs font-semibold text-zinc-500 dark:text-zinc-400 hover:text-[#FF6A00] transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Scrims Lobby
        </button>
        <AuthCard
          titleId="login-page-title"
          intendedPath={intendedPath}
          onSuccess={onAuthSuccess}
        />
      </div>
    </div>
  );
};


interface AdminCodeGateProps {
  onBackHome?: () => void;
}

export const AdminCodeGate: React.FC<AdminCodeGateProps> = ({ onBackHome }) => {
  const { unlockAdmin } = useAuth();
  const [code, setCode] = useState('');
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (!code.trim()) {
      setError('Enter the admin code.');
      return;
    }
    if (!unlockAdmin(code)) {
      setError('Invalid admin code. Try again.');
      setCode('');
    }
  };

  return (
    <div className="min-h-[calc(100vh-10rem)] flex items-center justify-center py-6 px-1 sm:px-4">
      <form
        onSubmit={handleSubmit}
        noValidate
        className="w-full max-w-md rounded-2xl bg-white dark:bg-[#14141C] border border-zinc-200 dark:border-white/10 p-5 sm:p-6 shadow-2xl space-y-4"
      >
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-xl bg-[#FF6A00]/15 flex items-center justify-center">
            <ShieldAlert className="w-6 h-6 text-[#FF6A00]" />
          </div>
          <div className="min-w-0">
            <h1 className="font-display text-xl sm:text-2xl font-bold text-zinc-900 dark:text-white leading-tight">
              Admin Access
            </h1>
            <p className="text-xs text-zinc-500 dark:text-zinc-400">Enter the organizer code to open the Admin panel.</p>
          </div>
        </div>

        <div>
          <label htmlFor="admin-code" className="block text-xs font-medium text-zinc-600 dark:text-zinc-300 mb-1">
            Admin Code
          </label>
          <div className="relative">
            <KeyRound className="w-4 h-4 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              id="admin-code"
              type="password"
              autoComplete="off"
              autoCapitalize="characters"
              value={code}
              onChange={(e) => setCode(e.target.value)}
              placeholder="Enter admin code"
              className="w-full min-h-[44px] pl-9 pr-3 py-2.5 rounded-xl bg-zinc-50 dark:bg-[#0A0A0F] border border-zinc-200 dark:border-white/10 text-sm text-zinc-900 dark:text-white focus:outline-none focus:border-[#FF6A00]"
            />
          </div>
        </div>

        {error && (
          <div role="alert" className="rounded-xl bg-[#FF2A2A]/10 border border-[#FF2A2A]/35 px-3 py-2.5 text-xs text-[#FF2A2A]">
            {error}
          </div>
        )}

        <button
          type="submit"
          className="w-full min-h-[46px] py-2.5 px-4 rounded-xl bg-[#FF6A00] hover:bg-[#e55f00] text-white font-semibold text-sm transition-colors shadow-[0_0_20px_rgba(255,106,0,0.28)]"
        >
          Unlock Admin Panel
        </button>

        {onBackHome && (
          <button
            type="button"
            onClick={onBackHome}
            className="w-full min-h-[42px] py-2 px-4 rounded-xl border border-zinc-200 dark:border-white/10 text-xs font-semibold text-zinc-700 dark:text-zinc-200 hover:bg-zinc-100 dark:hover:bg-white/5 flex items-center justify-center gap-2"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            Back to Scrims Lobby
          </button>
        )}
      </form>
    </div>
  );
};
