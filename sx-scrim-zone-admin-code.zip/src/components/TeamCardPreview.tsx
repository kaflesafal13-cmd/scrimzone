import React from 'react';
import { Shield, CheckCircle2, Clock, XCircle, Lock } from 'lucide-react';
import { PlayerEntry, RegistrationStatus } from '../types';

interface TeamCardPreviewProps {
  teamName: string;
  teamLogoUrl?: string;
  scrimTitle?: string;
  captainName: string;
  captainUid: string;
  players: PlayerEntry[];
  status?: RegistrationStatus;
  shareCode?: string;
  hasTeamPassword?: boolean;
}

export const TeamCardPreview: React.FC<TeamCardPreviewProps> = ({
  teamName,
  teamLogoUrl,
  scrimTitle,
  captainName,
  captainUid,
  players,
  status = 'pending_review',
  shareCode = 'SX-PASS',
  hasTeamPassword = false,
}) => {
  const statusConfig = {
    slot_confirmed: { label: 'Slot Confirmed', icon: CheckCircle2, cls: 'text-emerald-400' },
    verified: { label: 'Verified', icon: CheckCircle2, cls: 'text-emerald-400' },
    pending_review: { label: 'Pending Review', icon: Clock, cls: 'text-amber-400' },
    rejected: { label: 'Rejected', icon: XCircle, cls: 'text-[#FF2A2A]' },
  }[status];

  const StatusIcon = statusConfig.icon;
  const activePlayers = players.filter((p) => p.ign.trim() || p.uid.trim());

  return (
    <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-[#0E0E15] via-[#14141C] to-[#1A1416] border border-[#FF6A00]/35 p-5 text-white shadow-[0_12px_36px_rgba(0,0,0,0.45)]">
      <div className="flex items-start justify-between gap-3 pb-4 border-b border-white/10">
        <div className="min-w-0">
          <div className="text-[11px] font-semibold tracking-widest text-[#FF6A00] uppercase">
            SX SCRIM ZONE · Team Pass
          </div>
          <p className="text-xs text-zinc-400 truncate mt-0.5">{scrimTitle || 'Free Fire Custom Room'}</p>
        </div>
        <div className={`inline-flex items-center gap-1.5 text-xs font-semibold shrink-0 ${statusConfig.cls}`}>
          <StatusIcon className="w-3.5 h-3.5" />
          <span>{statusConfig.label}</span>
        </div>
      </div>

      <div className="flex items-center gap-4 py-4">
        <div className="w-16 h-16 rounded-xl bg-[#0A0A0F] border border-white/15 overflow-hidden flex items-center justify-center shrink-0">
          {teamLogoUrl ? (
            <img src={teamLogoUrl} alt={`${teamName || 'Team'} logo`} referrerPolicy="no-referrer" className="w-full h-full object-cover" />
          ) : (
            <Shield className="w-7 h-7 text-[#FF6A00]" />
          )}
        </div>
        <div className="min-w-0">
          <h3 className="font-display text-2xl font-bold tracking-wide text-white truncate">
            {teamName.trim() || 'Your Squad Name'}
          </h3>
          <p className="text-xs text-zinc-400 mt-0.5 truncate">
            Captain: <span className="text-zinc-200 font-medium">{captainName.trim() || '—'}</span>
            {captainUid ? <span className="font-mono text-zinc-400"> · {captainUid}</span> : null}
          </p>
          <div className="flex items-center gap-2.5 mt-1">
            <span className="font-mono text-[11px] text-[#FF6A00]">PASS {shareCode}</span>
            {hasTeamPassword && (
              <span className="inline-flex items-center gap-1 text-[11px] font-medium text-zinc-300">
                <Lock className="w-3 h-3 text-[#FF6A00]" />
                Pass Protected
              </span>
            )}
          </div>
        </div>
      </div>

      <div className="space-y-2 pt-2">
        <div className="text-[11px] font-semibold tracking-wider text-zinc-400 uppercase">Active Roster</div>
        {activePlayers.length === 0 ? (
          <p className="text-xs text-zinc-500 py-2">Enter player IGNs and UIDs to preview your roster card.</p>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {activePlayers.map((p, idx) => (
              <div
                key={idx}
                className="flex items-center justify-between gap-2 rounded-xl bg-[#0A0A0F]/80 border border-white/8 px-3 py-2"
              >
                <div className="flex items-center gap-2 min-w-0">
                  {p.photoUrl ? (
                    <img
                      src={p.photoUrl}
                      alt={p.ign}
                      referrerPolicy="no-referrer"
                      className="w-6 h-6 rounded-md object-cover shrink-0"
                    />
                  ) : (
                    <span className="font-mono text-[11px] font-bold text-[#FF6A00] shrink-0">P{idx + 1}</span>
                  )}
                  <span className="text-xs font-medium text-white truncate">{p.ign || 'Player'}</span>
                </div>
                <span className="font-mono text-[11px] text-zinc-400 tabular-nums shrink-0">{p.uid || '—'}</span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
