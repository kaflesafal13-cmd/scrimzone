import React, { useCallback, useEffect, useState } from 'react';
import { Loader2 } from 'lucide-react';
import { AppProvider } from './context/AppContext';
import { useAuth } from './context/AuthContext';
import { ErrorBoundary } from './components/ErrorBoundary';
import { SplashScreen } from './components/SplashScreen';
import { Layout, NavTab } from './components/Layout';
import { AdminCodeGate, AuthModal, LoginView } from './components/AuthModal';
import { ScrimsHome } from './components/ScrimsHome';
import { ScrimDetail } from './components/ScrimDetail';
import { RegistrationWizard } from './components/RegistrationWizard';
import {
  LeaderboardView,
  MyTeamsView,
  NotificationsView,
  ProfileView,
  ShareTeamPassModal,
  TransactionsView,
} from './components/CaptainViews';
import { AdminPanel } from './components/AdminPanel';
import { Registration, Scrim } from './types';

const TAB_TO_PATH: Record<NavTab, string> = {
  home: '/',
  'my-teams': '/my-teams',
  transactions: '/transactions',
  notifications: '/notifications',
  leaderboard: '/leaderboard',
  profile: '/profile',
  admin: '/admin',
  login: '/login',
};

const PROTECTED_TABS = new Set<NavTab>(['my-teams', 'transactions', 'notifications', 'profile']);

function pathToTab(pathname: string): NavTab {
  const normalized = pathname.replace(/\/+$/, '') || '/';
  switch (normalized) {
    case '/login':
      return 'login';
    case '/my-teams':
      return 'my-teams';
    case '/transactions':
      return 'transactions';
    case '/notifications':
      return 'notifications';
    case '/leaderboard':
      return 'leaderboard';
    case '/profile':
      return 'profile';
    case '/admin':
      return 'admin';
    default:
      return 'home';
  }
}

function AppContent() {
  const { user, role, loading: authLoading, redirectPath, setRedirectPath, clearRedirectPath } = useAuth();
  const isAdmin = role === 'admin';

  const [splashDone, setSplashDone] = useState(false);
  const [activeTab, setActiveTab] = useState<NavTab>(() =>
    typeof window !== 'undefined' ? pathToTab(window.location.pathname) : 'home'
  );
  const [selectedScrim, setSelectedScrim] = useState<Scrim | null>(null);
  const [registerScrim, setRegisterScrim] = useState<Scrim | null>(null);
  const [reuploadReg, setReuploadReg] = useState<Registration | undefined>(undefined);
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [shareCode, setShareCode] = useState<string | null>(null);

  const navigateToTab = useCallback((tab: NavTab, replace = false) => {
    setActiveTab(tab);
    setSelectedScrim(null);
    setRegisterScrim(null);
    setReuploadReg(undefined);

    if (typeof window !== 'undefined') {
      const targetPath = TAB_TO_PATH[tab];
      const currentPath = window.location.pathname.replace(/\/+$/, '') || '/';
      if (currentPath !== targetPath) {
        const nextUrl = `${targetPath}${window.location.search}`;
        if (replace) {
          window.history.replaceState(null, '', nextUrl);
        } else {
          window.history.pushState(null, '', nextUrl);
        }
      }
    }
  }, []);

  useEffect(() => {
    if (typeof window === 'undefined') return;
    const params = new URLSearchParams(window.location.search);
    const teamParam = params.get('team');
    if (teamParam) setShareCode(teamParam);

    const onPopState = () => {
      setActiveTab(pathToTab(window.location.pathname));
      setSelectedScrim(null);
      setRegisterScrim(null);
      setReuploadReg(undefined);
    };
    window.addEventListener('popstate', onPopState);
    return () => window.removeEventListener('popstate', onPopState);
  }, []);

  // Protected route & role-based redirect guard — NEVER runs while authLoading is true
  useEffect(() => {
    if (authLoading) return;

    if (!user && PROTECTED_TABS.has(activeTab)) {
      setRedirectPath(TAB_TO_PATH[activeTab]);
      navigateToTab('login', true);
      return;
    }

    if (user && activeTab === 'login') {
      const targetTab = redirectPath ? pathToTab(redirectPath) : 'home';
      clearRedirectPath();
      navigateToTab(targetTab === 'login' ? 'home' : targetTab, true);
    }
  }, [authLoading, user, activeTab, redirectPath, setRedirectPath, clearRedirectPath, navigateToTab]);

  const handleSelectTab = (tab: NavTab) => {
    if (!authLoading && !user && PROTECTED_TABS.has(tab)) {
      setRedirectPath(TAB_TO_PATH[tab]);
      navigateToTab('login');
      return;
    }
    navigateToTab(tab);
  };

  if (authLoading) {
    return (
      <>
        {!splashDone && <SplashScreen onComplete={() => setSplashDone(true)} />}
        <div className="min-h-screen flex flex-col items-center justify-center bg-[#F6F6F9] text-[#0F1016] dark:bg-[#0A0A0F] dark:text-[#F4F4F7] p-6">
          <div className="rounded-2xl bg-white dark:bg-[#14141C] border border-zinc-200 dark:border-white/10 px-8 py-7 flex flex-col items-center gap-3 shadow-xl">
            <Loader2 className="w-7 h-7 text-[#FF6A00] animate-spin" />
            <div className="font-display text-xl font-bold tracking-wide">SX SCRIM ZONE</div>
            <p className="text-xs text-zinc-500 dark:text-zinc-400">Verifying captain session &amp; permissions...</p>
          </div>
        </div>
      </>
    );
  }

  return (
    <>
      {!splashDone && <SplashScreen onComplete={() => setSplashDone(true)} />}

      <Layout
        activeTab={activeTab}
        onSelectTab={handleSelectTab}
        onOpenAuth={() => {
          if (activeTab !== 'login') setAuthModalOpen(true);
        }}
      >
        {registerScrim ? (
          <RegistrationWizard
            scrim={registerScrim}
            existingRejectedReg={reuploadReg}
            onBack={() => {
              setRegisterScrim(null);
              setReuploadReg(undefined);
            }}
            onOpenAuth={() => setAuthModalOpen(true)}
            onComplete={() => {
              setRegisterScrim(null);
              setReuploadReg(undefined);
              setSelectedScrim(null);
              navigateToTab('my-teams');
            }}
          />
        ) : selectedScrim ? (
          <ScrimDetail
            scrim={selectedScrim}
            onBack={() => setSelectedScrim(null)}
            onRegister={() => setRegisterScrim(selectedScrim)}
          />
        ) : activeTab === 'login' ? (
          <LoginView
            intendedPath={redirectPath}
            onBackHome={() => {
              clearRedirectPath();
              navigateToTab('home');
            }}
          />
        ) : activeTab === 'home' ? (
          <ScrimsHome
            onSelectScrim={(scrim) => setSelectedScrim(scrim)}
            onQuickRegister={(scrim) => setRegisterScrim(scrim)}
          />
        ) : activeTab === 'my-teams' ? (
          <MyTeamsView
            onReupload={(scrim, reg) => {
              setReuploadReg(reg);
              setRegisterScrim(scrim);
            }}
            onBrowseScrims={() => handleSelectTab('home')}
            onOpenAuth={() => setAuthModalOpen(true)}
          />
        ) : activeTab === 'transactions' ? (
          <TransactionsView onOpenAuth={() => setAuthModalOpen(true)} />
        ) : activeTab === 'notifications' ? (
          <NotificationsView onOpenAuth={() => setAuthModalOpen(true)} />
        ) : activeTab === 'leaderboard' ? (
          <LeaderboardView />
        ) : activeTab === 'profile' ? (
          <ProfileView onOpenAuth={() => setAuthModalOpen(true)} />
        ) : activeTab === 'admin' ? (
          isAdmin ? <AdminPanel /> : <AdminCodeGate onBackHome={() => navigateToTab('home')} />
        ) : (
          <ScrimsHome
            onSelectScrim={(scrim) => setSelectedScrim(scrim)}
            onQuickRegister={(scrim) => setRegisterScrim(scrim)}
          />
        )}
      </Layout>

      <AuthModal open={authModalOpen} onClose={() => setAuthModalOpen(false)} />
      {shareCode && <ShareTeamPassModal shareCode={shareCode} onClose={() => setShareCode(null)} />}
    </>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <AppProvider>
        <AppContent />
      </AppProvider>
    </ErrorBoundary>
  );
}
