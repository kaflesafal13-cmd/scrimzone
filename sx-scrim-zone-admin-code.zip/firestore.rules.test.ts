import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const rules = fs.readFileSync('firestore.rules', 'utf8');

test('Dirty Dozen security invariants are enforced in firestore.rules', () => {
  // 1. Global deny-all fallback
  assert.match(rules, /match \/\{document=\*\*\}\s*\{\s*allow read, write: if false;\s*\}/);
  // 2. Email verification required for bootstrapped admin & writes
  assert.match(rules, /request\.auth\.token\.email_verified == true/);
  // 3. Self-admin escalation blocked on user create
  assert.match(rules, /incoming\(\)\.role == 'captain'/);
  // 4. Strike reset blocked for non-admin updates
  assert.match(rules, /affectedKeys\(\)\.hasOnly\(\['displayName', 'inGameName', 'gameUid', 'whatsapp', 'savedTeams', 'updatedAt'\]\)/);
  // 5. Room credentials isolated and gated by scrimAccess + releaseAt
  assert.match(rules, /match \/scrimRooms\/\{scrimId\}[\s\S]*scrimAccess[\s\S]*request\.time >= existing\(\)\.releaseAt/);
  // 6. No list queries on room credentials
  assert.match(rules, /match \/scrimRooms\/\{scrimId\}[\s\S]*allow list: if false;/);
  // 7. Payment hashes cannot be deleted or updated by captains
  assert.match(rules, /match \/paymentHashes\/\{hashId\}[\s\S]*allow update: if false;[\s\S]*allow delete: if isValidId\(hashId\) && isAdmin\(\);/);
  // 8. Terminal state locking on confirmed registrations
  assert.match(rules, /existing\(\)\.status != 'slot_confirmed'/);
  // 9. Strict ID regex guard
  assert.match(rules, /id\.matches\('\^\[a-zA-Z0-9_\\\\-\]\+\$'\)/);
  // 10. Server timestamp enforcement
  assert.match(rules, /incoming\(\)\.createdAt == request\.time/);
  assert.match(rules, /incoming\(\)\.updatedAt == request\.time/);
  // 11. Orphan registration guard
  assert.match(rules, /exists\(\/databases\/\$\(database\)\/documents\/scrims\/\$\(incoming\(\)\.scrimId\)\)/);
  // 12. No blanket isSignedIn() list rules
  assert.doesNotMatch(rules, /allow list:\s*if isSignedIn\(\)\s*;/);
  // 13. Team password updates keep status immutable and only touch password fields
  assert.match(rules, /teamPasswordHash is string && data\.teamPasswordHash\.size\(\) <= 160/);
  assert.match(rules, /affectedKeys\(\)\.hasOnly\(\['hasTeamPassword', 'teamPasswordHash', 'updatedAt'\]\)/);
  // 14. Admin-assigned room ID & password validated with <= 40 bounds and excluded from captain update branches
  assert.match(rules, /assignedRoomId is string && data\.assignedRoomId\.size\(\) <= 40/);
  assert.match(rules, /assignedRoomPassword is string && data\.assignedRoomPassword\.size\(\) <= 40/);
});

