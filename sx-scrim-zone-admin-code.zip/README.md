# SX SCRIM ZONE

Free Fire custom room scrim registration, AI-powered payment verification, anti-fraud deduplication, and tournament management platform built with React, TypeScript, Tailwind CSS, Express, Gemini Vision (`gemini-2.5-flash`), and Firebase.

## Features
- **Esports Lobby & Scrim Detail**: Browse upcoming/live Free Fire scrims (Squad / Duo / Solo), search and filter by map/status, inspect rules, points system, prize tiers, and 10-minute pre-match room credential release.
- **Team Registration & Live Team Card**: Enforce 8–12 digit UIDs, block duplicate UIDs within a team or across the same scrim, crop/compress team logos, preview an esports roster card live, and export passes as PNG or shareable links.
- **AI Auto-Verification (`/api/verify-payment`)**: Server-side Gemini 2.5 Flash Vision extracts receipt fields (`amount`, `transaction_id`, `receiver_name_or_number`, `sender_name`, `date_time`, `status`, `tampering_suspected`, `confidence`) and routes to Auto-Confirm, Admin Manual Review (confidence 60–84), or Auto-Reject (up to 3 re-upload attempts).
- **5-Layer Duplicate & Fraud Protection**: Exact SHA-256 hash, perceptual 64-bit dHash Hamming distance, normalized unique Transaction ID, `amount + sender + timestamp` combo check, and per-user rate limiting with strike tracking.
- **Organizer Admin Panel**: Recharts analytics dashboard, Scrim CRUD & Room ID auto-release, Payment Methods manager, Manual Review Queue with screenshot zoom, CSV/Excel/PDF & batch PNG Team Card exports, Transactions Ledger, Fraud Log with ban/unban, Announcements, and Points Leaderboard / Prize Payouts.
- **PWA Ready**: Installable on Windows desktop browsers and Android/iOS phones with offline shell and Service Worker caching.

## Environment Variables
Create `.env` (see `.env.example`):
```env
GEMINI_API_KEY="YOUR_GEMINI_API_KEY"
APP_URL="https://your-deployment-url"
PORT=3000
```

## Local Development
```bash
npm install
npm run dev
```
The Express + Vite full-stack server runs on `http://localhost:3000`.

## Running Tests & Linting
```bash
npm run lint
npx --yes tsx --test src/utils/validation.test.ts src/utils/fraud.test.ts src/utils/scoring.test.ts firestore.rules.test.ts
npx eslint firestore.rules
```

## Firestore Security Rules
Security rules are defined in `firestore.rules` (modeled in `firebase-blueprint.json` and `security_spec.md`):
- User profiles and registrations isolate PII to document owners and verified admins.
- Room credentials (`/scrimRooms/{scrimId}`) are isolated from public scrim listings and only readable by verified admins or confirmed captains after `releaseAt`.
- Payment deduplication hashes (`/paymentHashes/{hashId}`) are append-only for verified users and immutable/undeletable by non-admins.
- Deploy rules via Firebase CLI: `firebase deploy --only firestore:rules`

## Deployment
### Production Node / Cloud Run / Render / Railway
```bash
npm run build
npm start
```
### Firebase Hosting + Backend / Vercel
- Build the frontend with `npm run build` (outputs to `dist/`).
- Set `GEMINI_API_KEY` in your server environment / hosting secrets panel (never expose it in client-side `VITE_*` variables).
- For Firebase Auth Email/Password login enable **Email/Password** under **Firebase Console > Authentication > Sign-in method**.
