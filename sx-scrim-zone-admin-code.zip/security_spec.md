# SX SCRIM ZONE — Security Specification & Threat Model

## 1. Data Invariants
1. A user cannot assign themselves `role: 'admin'`, clear `strikes`, or clear `isBanned` on their own `/users/{userId}` document.
2. PII (`email`, `whatsapp`/`captainPhone`, `screenshotDataUrl`) is strictly isolated to `/users/{userId}` and `/registrations/{regId}`, readable only by the document owner or a verified admin.
3. Custom room credentials (`/scrimRooms/{scrimId}`) are isolated from public `/scrims/{scrimId}` and readable only by admins or confirmed captains after `releaseAt` (`request.time >= resource.data.releaseAt`).
4. Confirmed or verified registration status cannot be self-granted by a non-admin unless accompanied by a valid payment hash & transaction record created by the verified owner, and once `slot_confirmed` is reached, a captain cannot mutate team status or payment fields.
5. `paymentHashes` are append-only by authenticated users (tagged with `request.auth.uid`) and cannot be deleted or forged by non-admins to bypass duplicate detection.
6. Every document ID matches `^[a-zA-Z0-9_\-]+$` (<= 128 chars), every string has explicit `.size()` bounds, and every `createdAt` / `updatedAt` equals `request.time`.

## 2. The "Dirty Dozen" Attack Payloads
1. **Self-Admin Escalation**: Creating `/users/u1` with `{ role: 'admin', strikes: 0, isBanned: false }` -> Rejected (`role == 'captain'` enforced).
2. **Strike Evasion**: Updating `/users/u1` with `{ strikes: 0, isBanned: false }` -> Rejected (`affectedKeys().hasOnly(['displayName', 'inGameName', 'gameUid', 'whatsapp', 'savedTeams', 'updatedAt'])`).
3. **Unverified Email Spoofing**: Admin check with `email: 'kaflesafal13@gmail.com'` and `email_verified: false` -> Rejected (`email_verified == true` required).
4. **Shadow Field Injection on Registration**: Creating `/registrations/r1` with an extra key `isAdminBypass: true` -> Rejected (`keys().hasOnly(...)`).
5. **Identity Spoofing on Registration**: Creating `/registrations/r1` with `userId: 'victim_uid'` -> Rejected (`incoming().userId == request.auth.uid`).
6. **Early Room Credential Scraping**: Reading `/scrimRooms/s1` before `releaseAt` or without `/scrimAccess/s1_u1` -> Rejected.
7. **PII Scraping via List Query**: Calling `list` on `/registrations` without filtering `userId == request.auth.uid` as a non-admin -> Rejected (`resource.data.userId == request.auth.uid || isAdmin()`).
8. **Duplicate Hash Deletion**: Non-admin attempting `delete` on `/paymentHashes/h1` to reuse a screenshot -> Rejected (`isAdmin()` only).
9. **Terminal State Mutation**: Captain updating `/registrations/r1` when existing status is `slot_confirmed` -> Rejected.
10. **ID Poisoning**: Creating `/scrims/../../bad` or a 500-char ID -> Rejected (`isValidId()`).
11. **Timestamp Forgery**: Creating `/transactions/t1` with a backdated `createdAt` (`!= request.time`) -> Rejected.
12. **Orphan Registration**: Creating `/registrations/r1` referencing a nonexistent `scrimId` -> Rejected (`exists(/databases/$(database)/documents/scrims/$(incoming().scrimId))`).
13. **Team Password Status Escalation**: Captain updating `hasTeamPassword`/`teamPasswordHash` on `/registrations/r1` or `/scrimRosters/sr1` while changing `status: 'slot_confirmed'` -> Rejected (`incoming().status == existing().status` and `affectedKeys().hasOnly(['hasTeamPassword', 'teamPasswordHash', 'updatedAt'])`).
14. **Captain Forging Scrim ID/Pass Placement**: Non-admin attempting to update `assignedRoomId`, `assignedRoomPassword`, or `roomAssignedAtISO` on `/registrations/r1` -> Rejected (only `isAdmin()` can write those fields; captain update branches exclude them).
