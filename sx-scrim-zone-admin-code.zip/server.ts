import 'dotenv/config';
import express from 'express';
import http from 'node:http';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { GoogleGenAI, Type } from '@google/genai';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT) || 3000;
const IS_PROD = process.env.NODE_ENV === 'production';

const app = express();
app.use(express.json({ limit: '10mb' }));

const ALLOWED_MIME_TYPES = new Set(['image/png', 'image/jpeg', 'image/webp']);

app.get('/api/health', (_req, res) => {
  res.json({
    ok: true,
    geminiConfigured: Boolean(process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY.trim().length > 0),
  });
});

app.post('/api/verify-payment', async (req, res) => {
  try {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey || !apiKey.trim()) {
      res.status(503).json({
        error: 'Gemini API key is not configured on the server.',
        code: 'MISSING_API_KEY',
      });
      return;
    }

    const {
      imageBase64,
      mimeType,
      expectedAmount,
      currency,
      configuredAccounts,
      scrimTitle,
      currentTimeISO,
    } = req.body ?? {};

    if (typeof imageBase64 !== 'string' || imageBase64.length < 32 || imageBase64.length > 8_000_000) {
      res.status(400).json({ error: 'Invalid or missing payment screenshot image payload.' });
      return;
    }

    if (typeof mimeType !== 'string' || !ALLOWED_MIME_TYPES.has(mimeType)) {
      res.status(400).json({ error: 'Unsupported image MIME type. Use PNG, JPG, or WebP.' });
      return;
    }

    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });

    const accountsText = Array.isArray(configuredAccounts) && configuredAccounts.length > 0
      ? configuredAccounts.map((a: unknown) => String(a)).join(' | ')
      : 'No configured accounts provided';

    const prompt = [
      'Analyze this uploaded payment screenshot for an esports tournament registration.',
      `Scrim: ${typeof scrimTitle === 'string' ? scrimTitle : 'Free Fire Scrim'}`,
      `Expected Entry Fee: ${Number(expectedAmount) || 0} ${typeof currency === 'string' ? currency : 'NPR'}`,
      `Configured Receiver Accounts: ${accountsText}`,
      `Reference Upload Timestamp (ISO): ${typeof currentTimeISO === 'string' ? currentTimeISO : new Date().toISOString()}`,
      'Extract exact fields strictly as JSON:',
      '- is_payment_screenshot: true only if this is a genuine digital wallet, UPI, mobile banking, or payment confirmation receipt.',
      '- amount: numeric amount paid (0 if unreadable).',
      '- currency: currency code or symbol found (e.g. NPR, INR, BDT, USD).',
      '- transaction_id: exact transaction/reference/UTR ID string (empty string if missing).',
      '- receiver_name_or_number: recipient name, merchant name, phone, or UPI ID shown on the receipt.',
      '- sender_name: payer name or number if visible (empty string if hidden).',
      '- date_time: exact ISO-8601 timestamp or verbatim date and time text from receipt.',
      '- status: "success", "failed", "pending", or "unknown".',
      '- tampering_suspected: true if fonts look mismatched, pixels around amount/ID/date are edited or pasted, or screenshot looks fabricated.',
      '- confidence: integer 0-100 representing certainty of genuine successful payment extraction.',
      '- analysis_summary: 1 concise sentence explaining what was detected or any discrepancy.',
    ].join('\n');

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: {
        parts: [
          {
            inlineData: {
              mimeType,
              data: imageBase64,
            },
          },
          { text: prompt },
        ],
      },
      config: {
        systemInstruction:
          'You are a strict financial receipt verification engine for SX SCRIM ZONE. Be conservative about tampering and blurred or mismatched transaction details.',
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            is_payment_screenshot: { type: Type.BOOLEAN },
            amount: { type: Type.NUMBER },
            currency: { type: Type.STRING },
            transaction_id: { type: Type.STRING },
            receiver_name_or_number: { type: Type.STRING },
            sender_name: { type: Type.STRING },
            date_time: { type: Type.STRING },
            status: { type: Type.STRING },
            tampering_suspected: { type: Type.BOOLEAN },
            confidence: { type: Type.INTEGER },
            analysis_summary: { type: Type.STRING },
          },
          required: [
            'is_payment_screenshot',
            'amount',
            'currency',
            'transaction_id',
            'receiver_name_or_number',
            'sender_name',
            'date_time',
            'status',
            'tampering_suspected',
            'confidence',
            'analysis_summary',
          ],
        },
      },
    });

    const rawText = (response.text ?? '').trim();
    if (!rawText) {
      res.status(502).json({ error: 'Empty response returned by Gemini verification model.' });
      return;
    }

    const parsed = JSON.parse(rawText);
    const normalizedStatus = ['success', 'failed', 'pending', 'unknown'].includes(String(parsed.status).toLowerCase())
      ? String(parsed.status).toLowerCase()
      : 'unknown';

    res.json({
      analysis: {
        is_payment_screenshot: Boolean(parsed.is_payment_screenshot),
        amount: Number(parsed.amount) || 0,
        currency: String(parsed.currency || ''),
        transaction_id: String(parsed.transaction_id || '').trim(),
        receiver_name_or_number: String(parsed.receiver_name_or_number || '').trim(),
        sender_name: String(parsed.sender_name || '').trim(),
        date_time: String(parsed.date_time || '').trim(),
        status: normalizedStatus,
        tampering_suspected: Boolean(parsed.tampering_suspected),
        confidence: Math.max(0, Math.min(100, Math.round(Number(parsed.confidence) || 0))),
        analysis_summary: String(parsed.analysis_summary || '').trim(),
      },
    });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Payment verification failed.';
    console.error('Error in /api/verify-payment:', message);
    res.status(500).json({ error: message });
  }
});

async function startServer() {
  const httpServer = http.createServer(app);

  if (!IS_PROD) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: false,
        ws: { server: httpServer },
        allowedHosts: true,
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  httpServer.listen(PORT, '0.0.0.0', () => {
    console.log(`SX SCRIM ZONE server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
